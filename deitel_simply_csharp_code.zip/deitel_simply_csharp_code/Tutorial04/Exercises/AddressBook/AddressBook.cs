using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace AddressBook
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Label lblFirstName;
      private System.Windows.Forms.TextBox txtFirstName;
      private System.Windows.Forms.Label lblLastName;
      private System.Windows.Forms.TextBox txtLastName;
      private System.Windows.Forms.TextBox txtAddress;
      private System.Windows.Forms.TextBox txtCity;
      private System.Windows.Forms.Label lblState;
      private System.Windows.Forms.TextBox txtState;
      private System.Windows.Forms.Label lblZip;
      private System.Windows.Forms.TextBox txtZip;
      private System.Windows.Forms.Label lblEmail;
      private System.Windows.Forms.Label lblPhone;
      private System.Windows.Forms.Label lblMobile;
      private System.Windows.Forms.Label lblBeeper;
      private System.Windows.Forms.TextBox txtEmail;
      private System.Windows.Forms.TextBox txtPhone;
      private System.Windows.Forms.TextBox txtMobile;
      private System.Windows.Forms.TextBox txtBeeper;
      private System.Windows.Forms.Button btnSave;
      private System.Windows.Forms.Button btnClear;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblFirstName = new System.Windows.Forms.Label();
         this.txtFirstName = new System.Windows.Forms.TextBox();
         this.lblLastName = new System.Windows.Forms.Label();
         this.txtLastName = new System.Windows.Forms.TextBox();
         this.txtAddress = new System.Windows.Forms.TextBox();
         this.txtCity = new System.Windows.Forms.TextBox();
         this.lblState = new System.Windows.Forms.Label();
         this.txtState = new System.Windows.Forms.TextBox();
         this.lblZip = new System.Windows.Forms.Label();
         this.txtZip = new System.Windows.Forms.TextBox();
         this.lblEmail = new System.Windows.Forms.Label();
         this.lblPhone = new System.Windows.Forms.Label();
         this.lblMobile = new System.Windows.Forms.Label();
         this.lblBeeper = new System.Windows.Forms.Label();
         this.txtEmail = new System.Windows.Forms.TextBox();
         this.txtPhone = new System.Windows.Forms.TextBox();
         this.txtMobile = new System.Windows.Forms.TextBox();
         this.txtBeeper = new System.Windows.Forms.TextBox();
         this.btnSave = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblFirstName
         // 
         this.lblFirstName.Location = new System.Drawing.Point(16, 16);
         this.lblFirstName.Name = "lblFirstName";
         this.lblFirstName.Size = new System.Drawing.Size(64, 21);
         this.lblFirstName.TabIndex = 0;
         this.lblFirstName.Text = "First Name";
         this.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtFirstName
         // 
         this.txtFirstName.Location = new System.Drawing.Point(88, 16);
         this.txtFirstName.Name = "txtFirstName";
         this.txtFirstName.Size = new System.Drawing.Size(128, 21);
         this.txtFirstName.TabIndex = 1;
         this.txtFirstName.Text = "John";
         this.txtFirstName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblLastName
         // 
         this.lblLastName.Location = new System.Drawing.Point(224, 16);
         this.lblLastName.Name = "lblLastName";
         this.lblLastName.Size = new System.Drawing.Size(64, 21);
         this.lblLastName.TabIndex = 2;
         this.lblLastName.Text = "Last Name:";
         this.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtLastName
         // 
         this.txtLastName.Location = new System.Drawing.Point(296, 16);
         this.txtLastName.Name = "txtLastName";
         this.txtLastName.Size = new System.Drawing.Size(128, 21);
         this.txtLastName.TabIndex = 3;
         this.txtLastName.Text = "Doe";
         this.txtLastName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtAddress
         // 
         this.txtAddress.Location = new System.Drawing.Point(88, 56);
         this.txtAddress.Name = "txtAddress";
         this.txtAddress.Size = new System.Drawing.Size(336, 21);
         this.txtAddress.TabIndex = 4;
         this.txtAddress.Text = "123 Read Street";
         this.txtAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtCity
         // 
         this.txtCity.Location = new System.Drawing.Point(88, 96);
         this.txtCity.Name = "txtCity";
         this.txtCity.Size = new System.Drawing.Size(104, 21);
         this.txtCity.TabIndex = 5;
         this.txtCity.Text = "Some town";
         this.txtCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblState
         // 
         this.lblState.Location = new System.Drawing.Point(208, 96);
         this.lblState.Name = "lblState";
         this.lblState.Size = new System.Drawing.Size(40, 21);
         this.lblState.TabIndex = 6;
         this.lblState.Text = "State:";
         this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtState
         // 
         this.txtState.Location = new System.Drawing.Point(264, 96);
         this.txtState.Name = "txtState";
         this.txtState.Size = new System.Drawing.Size(32, 21);
         this.txtState.TabIndex = 7;
         this.txtState.Text = "MA";
         this.txtState.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblZip
         // 
         this.lblZip.Location = new System.Drawing.Point(312, 96);
         this.lblZip.Name = "lblZip";
         this.lblZip.Size = new System.Drawing.Size(24, 21);
         this.lblZip.TabIndex = 8;
         this.lblZip.Text = "Zip:";
         this.lblZip.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtZip
         // 
         this.txtZip.Location = new System.Drawing.Point(352, 96);
         this.txtZip.Name = "txtZip";
         this.txtZip.Size = new System.Drawing.Size(72, 21);
         this.txtZip.TabIndex = 9;
         this.txtZip.Text = "021849735";
         this.txtZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblEmail
         // 
         this.lblEmail.Location = new System.Drawing.Point(36, 136);
         this.lblEmail.Name = "lblEmail";
         this.lblEmail.Size = new System.Drawing.Size(40, 21);
         this.lblEmail.TabIndex = 10;
         this.lblEmail.Text = "E-mail:";
         this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPhone
         // 
         this.lblPhone.Location = new System.Drawing.Point(256, 136);
         this.lblPhone.Name = "lblPhone";
         this.lblPhone.Size = new System.Drawing.Size(40, 21);
         this.lblPhone.TabIndex = 11;
         this.lblPhone.Text = "Phone:";
         this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblMobile
         // 
         this.lblMobile.Location = new System.Drawing.Point(34, 176);
         this.lblMobile.Name = "lblMobile";
         this.lblMobile.Size = new System.Drawing.Size(48, 21);
         this.lblMobile.TabIndex = 12;
         this.lblMobile.Text = "Mobile:";
         this.lblMobile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblBeeper
         // 
         this.lblBeeper.Location = new System.Drawing.Point(256, 176);
         this.lblBeeper.Name = "lblBeeper";
         this.lblBeeper.Size = new System.Drawing.Size(48, 21);
         this.lblBeeper.TabIndex = 13;
         this.lblBeeper.Text = "Beeper:";
         this.lblBeeper.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtEmail
         // 
         this.txtEmail.Location = new System.Drawing.Point(88, 136);
         this.txtEmail.Name = "txtEmail";
         this.txtEmail.Size = new System.Drawing.Size(152, 21);
         this.txtEmail.TabIndex = 14;
         this.txtEmail.Text = "John.Doe@not-a-domain.com";
         this.txtEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtPhone
         // 
         this.txtPhone.Location = new System.Drawing.Point(312, 136);
         this.txtPhone.Name = "txtPhone";
         this.txtPhone.Size = new System.Drawing.Size(112, 21);
         this.txtPhone.TabIndex = 15;
         this.txtPhone.Text = "781-555-4567";
         this.txtPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtMobile
         // 
         this.txtMobile.Location = new System.Drawing.Point(88, 176);
         this.txtMobile.Name = "txtMobile";
         this.txtMobile.Size = new System.Drawing.Size(152, 21);
         this.txtMobile.TabIndex = 16;
         this.txtMobile.Text = "978-555-6541";
         this.txtMobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtBeeper
         // 
         this.txtBeeper.Location = new System.Drawing.Point(312, 176);
         this.txtBeeper.Name = "txtBeeper";
         this.txtBeeper.Size = new System.Drawing.Size(112, 21);
         this.txtBeeper.TabIndex = 17;
         this.txtBeeper.Text = "508-555-7896";
         this.txtBeeper.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnSave
         // 
         this.btnSave.Location = new System.Drawing.Point(260, 216);
         this.btnSave.Name = "btnSave";
         this.btnSave.TabIndex = 18;
         this.btnSave.Text = "save";
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(349, 216);
         this.btnClear.Name = "btnClear";
         this.btnClear.TabIndex = 19;
         this.btnClear.Text = "clear";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(440, 253);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.btnSave);
         this.Controls.Add(this.txtBeeper);
         this.Controls.Add(this.txtMobile);
         this.Controls.Add(this.txtPhone);
         this.Controls.Add(this.txtEmail);
         this.Controls.Add(this.lblBeeper);
         this.Controls.Add(this.lblMobile);
         this.Controls.Add(this.lblPhone);
         this.Controls.Add(this.lblEmail);
         this.Controls.Add(this.txtZip);
         this.Controls.Add(this.lblZip);
         this.Controls.Add(this.txtState);
         this.Controls.Add(this.lblState);
         this.Controls.Add(this.txtCity);
         this.Controls.Add(this.txtAddress);
         this.Controls.Add(this.txtLastName);
         this.Controls.Add(this.lblLastName);
         this.Controls.Add(this.txtFirstName);
         this.Controls.Add(this.lblFirstName);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "Form1";
         this.Text = "The Application";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run(new Form1());
      }
   }
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
