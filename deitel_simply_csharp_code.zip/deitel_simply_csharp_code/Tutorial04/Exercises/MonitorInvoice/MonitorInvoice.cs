using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace MonitorInvoice
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Label lblTitle;
      private System.Windows.Forms.Label lblInvoiceNumber;
      private System.Windows.Forms.TextBox txtInvoiceNumber;
      private System.Windows.Forms.Label lblInvoiceDate;
      private System.Windows.Forms.Label lblCompanyName;
      private System.Windows.Forms.Label lblAddress;
      private System.Windows.Forms.TextBox txtDate;
      private System.Windows.Forms.TextBox txtCompanyName;
      private System.Windows.Forms.TextBox txtAddress;
      private System.Windows.Forms.TextBox txtCityStateZip;
      private System.Windows.Forms.Label lblQuantity;
      private System.Windows.Forms.Label lblPrice;
      private System.Windows.Forms.Label lblTotals;
      private System.Windows.Forms.Label lblType;
      private System.Windows.Forms.Label lblFifteen;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.TextBox txt15Quantity;
      private System.Windows.Forms.TextBox txt19Quantity;
      private System.Windows.Forms.TextBox txt17Quantity;
      private System.Windows.Forms.TextBox txt15Price;
      private System.Windows.Forms.TextBox txt17Price;
      private System.Windows.Forms.TextBox txt19Price;
      private System.Windows.Forms.Label lbl17Totals;
      private System.Windows.Forms.Label lbl19Total;
      private System.Windows.Forms.Label lblSubtotalResult;
      private System.Windows.Forms.Label lblTaxResult;
      private System.Windows.Forms.Label lblTotalResult;
      private System.Windows.Forms.Label lblSubtotal;
      private System.Windows.Forms.Label lblTax;
      private System.Windows.Forms.Button btnSave;
      private System.Windows.Forms.Button btnClear;
      private System.Windows.Forms.Button btnPrint;
      private System.Windows.Forms.Label lblAddress2;
      private System.Windows.Forms.Label lbl15Total;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblTitle = new System.Windows.Forms.Label();
         this.lblInvoiceNumber = new System.Windows.Forms.Label();
         this.txtInvoiceNumber = new System.Windows.Forms.TextBox();
         this.lblInvoiceDate = new System.Windows.Forms.Label();
         this.lblCompanyName = new System.Windows.Forms.Label();
         this.lblAddress = new System.Windows.Forms.Label();
         this.lblAddress2 = new System.Windows.Forms.Label();
         this.txtDate = new System.Windows.Forms.TextBox();
         this.txtCompanyName = new System.Windows.Forms.TextBox();
         this.txtAddress = new System.Windows.Forms.TextBox();
         this.txtCityStateZip = new System.Windows.Forms.TextBox();
         this.lblQuantity = new System.Windows.Forms.Label();
         this.lblPrice = new System.Windows.Forms.Label();
         this.lblTotals = new System.Windows.Forms.Label();
         this.lblType = new System.Windows.Forms.Label();
         this.lblFifteen = new System.Windows.Forms.Label();
         this.label2 = new System.Windows.Forms.Label();
         this.label3 = new System.Windows.Forms.Label();
         this.txt15Quantity = new System.Windows.Forms.TextBox();
         this.txt17Quantity = new System.Windows.Forms.TextBox();
         this.txt19Quantity = new System.Windows.Forms.TextBox();
         this.txt15Price = new System.Windows.Forms.TextBox();
         this.txt17Price = new System.Windows.Forms.TextBox();
         this.txt19Price = new System.Windows.Forms.TextBox();
         this.lbl15Total = new System.Windows.Forms.Label();
         this.lbl17Totals = new System.Windows.Forms.Label();
         this.lbl19Total = new System.Windows.Forms.Label();
         this.lblSubtotalResult = new System.Windows.Forms.Label();
         this.lblTaxResult = new System.Windows.Forms.Label();
         this.lblTotalResult = new System.Windows.Forms.Label();
         this.lblSubtotal = new System.Windows.Forms.Label();
         this.lblTax = new System.Windows.Forms.Label();
         this.btnSave = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.btnPrint = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblTitle
         // 
         this.lblTitle.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblTitle.Location = new System.Drawing.Point(48, 13);
         this.lblTitle.Name = "lblTitle";
         this.lblTitle.Size = new System.Drawing.Size(280, 32);
         this.lblTitle.TabIndex = 0;
         this.lblTitle.Text = "Monitor Invoice Application";
         this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblInvoiceNumber
         // 
         this.lblInvoiceNumber.Location = new System.Drawing.Point(16, 53);
         this.lblInvoiceNumber.Name = "lblInvoiceNumber";
         this.lblInvoiceNumber.Size = new System.Drawing.Size(88, 16);
         this.lblInvoiceNumber.TabIndex = 1;
         this.lblInvoiceNumber.Text = "Invoice Number";
         this.lblInvoiceNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtInvoiceNumber
         // 
         this.txtInvoiceNumber.Location = new System.Drawing.Point(112, 53);
         this.txtInvoiceNumber.Name = "txtInvoiceNumber";
         this.txtInvoiceNumber.Size = new System.Drawing.Size(48, 23);
         this.txtInvoiceNumber.TabIndex = 2;
         this.txtInvoiceNumber.Text = "128";
         this.txtInvoiceNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblInvoiceDate
         // 
         this.lblInvoiceDate.Location = new System.Drawing.Point(176, 53);
         this.lblInvoiceDate.Name = "lblInvoiceDate";
         this.lblInvoiceDate.Size = new System.Drawing.Size(72, 16);
         this.lblInvoiceDate.TabIndex = 3;
         this.lblInvoiceDate.Text = "Invoice date";
         this.lblInvoiceDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblCompanyName
         // 
         this.lblCompanyName.Location = new System.Drawing.Point(16, 85);
         this.lblCompanyName.Name = "lblCompanyName";
         this.lblCompanyName.Size = new System.Drawing.Size(96, 17);
         this.lblCompanyName.TabIndex = 4;
         this.lblCompanyName.Text = "Company Name:";
         this.lblCompanyName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblAddress
         // 
         this.lblAddress.Location = new System.Drawing.Point(8, 118);
         this.lblAddress.Name = "lblAddress";
         this.lblAddress.Size = new System.Drawing.Size(88, 17);
         this.lblAddress.TabIndex = 5;
         this.lblAddress.Text = "Address (line 1)";
         this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblAddress2
         // 
         this.lblAddress2.Location = new System.Drawing.Point(24, 153);
         this.lblAddress2.Name = "lblAddress2";
         this.lblAddress2.Size = new System.Drawing.Size(88, 17);
         this.lblAddress2.TabIndex = 6;
         this.lblAddress2.Text = "Address (line 2)";
         this.lblAddress2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtDate
         // 
         this.txtDate.Location = new System.Drawing.Point(256, 53);
         this.txtDate.Name = "txtDate";
         this.txtDate.Size = new System.Drawing.Size(104, 23);
         this.txtDate.TabIndex = 7;
         this.txtDate.Text = "10/11/02";
         this.txtDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtCompanyName
         // 
         this.txtCompanyName.Location = new System.Drawing.Point(112, 85);
         this.txtCompanyName.Name = "txtCompanyName";
         this.txtCompanyName.Size = new System.Drawing.Size(248, 23);
         this.txtCompanyName.TabIndex = 8;
         this.txtCompanyName.Text = "Deitel & Associates";
         this.txtCompanyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtAddress
         // 
         this.txtAddress.Location = new System.Drawing.Point(112, 118);
         this.txtAddress.Name = "txtAddress";
         this.txtAddress.Size = new System.Drawing.Size(248, 23);
         this.txtAddress.TabIndex = 9;
         this.txtAddress.Text = "100 Application Drive";
         this.txtAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtCityStateZip
         // 
         this.txtCityStateZip.Location = new System.Drawing.Point(112, 151);
         this.txtCityStateZip.Name = "txtCityStateZip";
         this.txtCityStateZip.Size = new System.Drawing.Size(248, 23);
         this.txtCityStateZip.TabIndex = 10;
         this.txtCityStateZip.Text = "Books, MA, 01276";
         this.txtCityStateZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblQuantity
         // 
         this.lblQuantity.Location = new System.Drawing.Point(128, 177);
         this.lblQuantity.Name = "lblQuantity";
         this.lblQuantity.Size = new System.Drawing.Size(56, 17);
         this.lblQuantity.TabIndex = 11;
         this.lblQuantity.Text = "Quantity:";
         this.lblQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPrice
         // 
         this.lblPrice.Location = new System.Drawing.Point(232, 177);
         this.lblPrice.Name = "lblPrice";
         this.lblPrice.Size = new System.Drawing.Size(40, 17);
         this.lblPrice.TabIndex = 12;
         this.lblPrice.Text = "Price:";
         this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotals
         // 
         this.lblTotals.Location = new System.Drawing.Point(320, 177);
         this.lblTotals.Name = "lblTotals";
         this.lblTotals.Size = new System.Drawing.Size(40, 17);
         this.lblTotals.TabIndex = 13;
         this.lblTotals.Text = "Totals:";
         this.lblTotals.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblType
         // 
         this.lblType.Location = new System.Drawing.Point(64, 184);
         this.lblType.Name = "lblType";
         this.lblType.Size = new System.Drawing.Size(40, 17);
         this.lblType.TabIndex = 14;
         this.lblType.Text = "Type:";
         this.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblFifteen
         // 
         this.lblFifteen.Location = new System.Drawing.Point(72, 208);
         this.lblFifteen.Name = "lblFifteen";
         this.lblFifteen.Size = new System.Drawing.Size(26, 17);
         this.lblFifteen.TabIndex = 15;
         this.lblFifteen.Text = "15\":";
         this.lblFifteen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(72, 230);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(26, 17);
         this.label2.TabIndex = 16;
         this.label2.Text = "17\":";
         this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(72, 256);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(26, 17);
         this.label3.TabIndex = 17;
         this.label3.Text = "19\":";
         this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txt15Quantity
         // 
         this.txt15Quantity.Location = new System.Drawing.Point(112, 204);
         this.txt15Quantity.Name = "txt15Quantity";
         this.txt15Quantity.Size = new System.Drawing.Size(64, 23);
         this.txt15Quantity.TabIndex = 18;
         this.txt15Quantity.Text = "10";
         this.txt15Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txt17Quantity
         // 
         this.txt17Quantity.Location = new System.Drawing.Point(112, 230);
         this.txt17Quantity.Name = "txt17Quantity";
         this.txt17Quantity.Size = new System.Drawing.Size(64, 23);
         this.txt17Quantity.TabIndex = 19;
         this.txt17Quantity.Text = "0";
         this.txt17Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txt19Quantity
         // 
         this.txt19Quantity.Location = new System.Drawing.Point(112, 256);
         this.txt19Quantity.Name = "txt19Quantity";
         this.txt19Quantity.Size = new System.Drawing.Size(64, 23);
         this.txt19Quantity.TabIndex = 20;
         this.txt19Quantity.Text = "0";
         this.txt19Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txt15Price
         // 
         this.txt15Price.Location = new System.Drawing.Point(192, 204);
         this.txt15Price.Name = "txt15Price";
         this.txt15Price.Size = new System.Drawing.Size(80, 23);
         this.txt15Price.TabIndex = 21;
         this.txt15Price.Text = "150";
         this.txt15Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txt17Price
         // 
         this.txt17Price.Location = new System.Drawing.Point(192, 230);
         this.txt17Price.Name = "txt17Price";
         this.txt17Price.Size = new System.Drawing.Size(80, 23);
         this.txt17Price.TabIndex = 22;
         this.txt17Price.Text = "0";
         this.txt17Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txt19Price
         // 
         this.txt19Price.Location = new System.Drawing.Point(192, 256);
         this.txt19Price.Name = "txt19Price";
         this.txt19Price.Size = new System.Drawing.Size(80, 23);
         this.txt19Price.TabIndex = 23;
         this.txt19Price.Text = "0";
         this.txt19Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lbl15Total
         // 
         this.lbl15Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lbl15Total.Location = new System.Drawing.Point(288, 204);
         this.lbl15Total.Name = "lbl15Total";
         this.lbl15Total.Size = new System.Drawing.Size(72, 17);
         this.lbl15Total.TabIndex = 24;
         this.lbl15Total.Text = "1500";
         this.lbl15Total.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lbl17Totals
         // 
         this.lbl17Totals.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lbl17Totals.Location = new System.Drawing.Point(288, 230);
         this.lbl17Totals.Name = "lbl17Totals";
         this.lbl17Totals.Size = new System.Drawing.Size(72, 17);
         this.lbl17Totals.TabIndex = 25;
         this.lbl17Totals.Text = "0";
         this.lbl17Totals.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lbl19Total
         // 
         this.lbl19Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lbl19Total.Location = new System.Drawing.Point(288, 256);
         this.lbl19Total.Name = "lbl19Total";
         this.lbl19Total.Size = new System.Drawing.Size(72, 17);
         this.lbl19Total.TabIndex = 26;
         this.lbl19Total.Text = "0";
         this.lbl19Total.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lblSubtotalResult
         // 
         this.lblSubtotalResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblSubtotalResult.Location = new System.Drawing.Point(288, 283);
         this.lblSubtotalResult.Name = "lblSubtotalResult";
         this.lblSubtotalResult.Size = new System.Drawing.Size(72, 17);
         this.lblSubtotalResult.TabIndex = 27;
         this.lblSubtotalResult.Text = "0";
         this.lblSubtotalResult.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lblTaxResult
         // 
         this.lblTaxResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTaxResult.Location = new System.Drawing.Point(288, 309);
         this.lblTaxResult.Name = "lblTaxResult";
         this.lblTaxResult.Size = new System.Drawing.Size(72, 17);
         this.lblTaxResult.TabIndex = 28;
         this.lblTaxResult.Text = "0";
         this.lblTaxResult.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lblTotalResult
         // 
         this.lblTotalResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalResult.Location = new System.Drawing.Point(288, 335);
         this.lblTotalResult.Name = "lblTotalResult";
         this.lblTotalResult.Size = new System.Drawing.Size(72, 17);
         this.lblTotalResult.TabIndex = 29;
         this.lblTotalResult.Text = "0";
         this.lblTotalResult.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lblSubtotal
         // 
         this.lblSubtotal.Location = new System.Drawing.Point(216, 283);
         this.lblSubtotal.Name = "lblSubtotal";
         this.lblSubtotal.Size = new System.Drawing.Size(56, 17);
         this.lblSubtotal.TabIndex = 30;
         this.lblSubtotal.Text = "Subtotal";
         this.lblSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTax
         // 
         this.lblTax.Location = new System.Drawing.Point(240, 309);
         this.lblTax.Name = "lblTax";
         this.lblTax.Size = new System.Drawing.Size(32, 17);
         this.lblTax.TabIndex = 31;
         this.lblTax.Text = "Tax";
         this.lblTax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // btnSave
         // 
         this.btnSave.Location = new System.Drawing.Point(24, 289);
         this.btnSave.Name = "btnSave";
         this.btnSave.Size = new System.Drawing.Size(75, 19);
         this.btnSave.TabIndex = 32;
         this.btnSave.Text = "Save";
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(24, 360);
         this.btnClear.Name = "btnClear";
         this.btnClear.Size = new System.Drawing.Size(75, 20);
         this.btnClear.TabIndex = 33;
         this.btnClear.Text = "Clear";
         // 
         // btnPrint
         // 
         this.btnPrint.Location = new System.Drawing.Point(24, 322);
         this.btnPrint.Name = "btnPrint";
         this.btnPrint.Size = new System.Drawing.Size(75, 19);
         this.btnPrint.TabIndex = 34;
         this.btnPrint.Text = "Calculate";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
         this.ClientSize = new System.Drawing.Size(376, 383);
         this.Controls.Add(this.btnPrint);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.btnSave);
         this.Controls.Add(this.lblTax);
         this.Controls.Add(this.lblSubtotal);
         this.Controls.Add(this.lblTotalResult);
         this.Controls.Add(this.lblTaxResult);
         this.Controls.Add(this.lblSubtotalResult);
         this.Controls.Add(this.lbl19Total);
         this.Controls.Add(this.lbl17Totals);
         this.Controls.Add(this.lbl15Total);
         this.Controls.Add(this.txt19Price);
         this.Controls.Add(this.txt17Price);
         this.Controls.Add(this.txt15Price);
         this.Controls.Add(this.txt19Quantity);
         this.Controls.Add(this.txt17Quantity);
         this.Controls.Add(this.txt15Quantity);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.lblFifteen);
         this.Controls.Add(this.lblType);
         this.Controls.Add(this.lblTotals);
         this.Controls.Add(this.lblPrice);
         this.Controls.Add(this.lblQuantity);
         this.Controls.Add(this.txtCityStateZip);
         this.Controls.Add(this.txtAddress);
         this.Controls.Add(this.txtCompanyName);
         this.Controls.Add(this.txtDate);
         this.Controls.Add(this.lblAddress2);
         this.Controls.Add(this.lblAddress);
         this.Controls.Add(this.lblCompanyName);
         this.Controls.Add(this.lblInvoiceDate);
         this.Controls.Add(this.txtInvoiceNumber);
         this.Controls.Add(this.lblInvoiceNumber);
         this.Controls.Add(this.lblTitle);
         this.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "Form1";
         this.Text = "Monitor Invoice";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run(new Form1());
      }
   }
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/