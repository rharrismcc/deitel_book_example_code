using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace MortgageCalculator
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Label lblMonthlyPaymentResult;
      private System.Windows.Forms.Label lblMonthlyPayment;
      private System.Windows.Forms.TextBox txtHomeValue;
      private System.Windows.Forms.TextBox txtLoanAmount;
      private System.Windows.Forms.TextBox txtTerm;
      private System.Windows.Forms.TextBox txtInsurance;
      private System.Windows.Forms.TextBox txtPropertyTaxes;
      private System.Windows.Forms.TextBox txtInterest;
      private System.Windows.Forms.Label lblHomeValue;
      private System.Windows.Forms.Label lblLoanAmount;
      private System.Windows.Forms.Label lblTerm;
      private System.Windows.Forms.Label lblInsurance;
      private System.Windows.Forms.Label lblPropertyTaxes;
      private System.Windows.Forms.Label lblInterest;
      private System.Windows.Forms.Button btnClear;
      private System.Windows.Forms.Button btnCalculate;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblMonthlyPaymentResult = new System.Windows.Forms.Label();
         this.lblMonthlyPayment = new System.Windows.Forms.Label();
         this.txtHomeValue = new System.Windows.Forms.TextBox();
         this.txtLoanAmount = new System.Windows.Forms.TextBox();
         this.txtTerm = new System.Windows.Forms.TextBox();
         this.txtInsurance = new System.Windows.Forms.TextBox();
         this.txtPropertyTaxes = new System.Windows.Forms.TextBox();
         this.txtInterest = new System.Windows.Forms.TextBox();
         this.lblHomeValue = new System.Windows.Forms.Label();
         this.lblLoanAmount = new System.Windows.Forms.Label();
         this.lblTerm = new System.Windows.Forms.Label();
         this.lblInsurance = new System.Windows.Forms.Label();
         this.lblPropertyTaxes = new System.Windows.Forms.Label();
         this.lblInterest = new System.Windows.Forms.Label();
         this.btnClear = new System.Windows.Forms.Button();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblMonthlyPaymentResult
         // 
         this.lblMonthlyPaymentResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.lblMonthlyPaymentResult.Location = new System.Drawing.Point(16, 16);
         this.lblMonthlyPaymentResult.Name = "lblMonthlyPaymentResult";
         this.lblMonthlyPaymentResult.Size = new System.Drawing.Size(100, 21);
         this.lblMonthlyPaymentResult.TabIndex = 0;
         this.lblMonthlyPaymentResult.Text = "550";
         this.lblMonthlyPaymentResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblMonthlyPayment
         // 
         this.lblMonthlyPayment.Location = new System.Drawing.Point(128, 16);
         this.lblMonthlyPayment.Name = "lblMonthlyPayment";
         this.lblMonthlyPayment.Size = new System.Drawing.Size(96, 21);
         this.lblMonthlyPayment.TabIndex = 1;
         this.lblMonthlyPayment.Text = "Monthly payment:";
         this.lblMonthlyPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtHomeValue
         // 
         this.txtHomeValue.Location = new System.Drawing.Point(16, 56);
         this.txtHomeValue.Name = "txtHomeValue";
         this.txtHomeValue.TabIndex = 2;
         this.txtHomeValue.Text = "125000";
         this.txtHomeValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtLoanAmount
         // 
         this.txtLoanAmount.Location = new System.Drawing.Point(16, 96);
         this.txtLoanAmount.Name = "txtLoanAmount";
         this.txtLoanAmount.TabIndex = 3;
         this.txtLoanAmount.Text = "100000";
         this.txtLoanAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtTerm
         // 
         this.txtTerm.Location = new System.Drawing.Point(16, 136);
         this.txtTerm.Name = "txtTerm";
         this.txtTerm.TabIndex = 4;
         this.txtTerm.Text = "20";
         this.txtTerm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtInsurance
         // 
         this.txtInsurance.Location = new System.Drawing.Point(16, 176);
         this.txtInsurance.Name = "txtInsurance";
         this.txtInsurance.TabIndex = 5;
         this.txtInsurance.Text = "500";
         this.txtInsurance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtPropertyTaxes
         // 
         this.txtPropertyTaxes.Location = new System.Drawing.Point(16, 216);
         this.txtPropertyTaxes.Name = "txtPropertyTaxes";
         this.txtPropertyTaxes.TabIndex = 6;
         this.txtPropertyTaxes.Text = "2100";
         this.txtPropertyTaxes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtInterest
         // 
         this.txtInterest.Location = new System.Drawing.Point(16, 256);
         this.txtInterest.Name = "txtInterest";
         this.txtInterest.TabIndex = 7;
         this.txtInterest.Text = "5.5";
         this.txtInterest.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblHomeValue
         // 
         this.lblHomeValue.Location = new System.Drawing.Point(128, 56);
         this.lblHomeValue.Name = "lblHomeValue";
         this.lblHomeValue.Size = new System.Drawing.Size(72, 21);
         this.lblHomeValue.TabIndex = 8;
         this.lblHomeValue.Text = "Home value:";
         this.lblHomeValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblLoanAmount
         // 
         this.lblLoanAmount.Location = new System.Drawing.Point(128, 96);
         this.lblLoanAmount.Name = "lblLoanAmount";
         this.lblLoanAmount.Size = new System.Drawing.Size(80, 21);
         this.lblLoanAmount.TabIndex = 9;
         this.lblLoanAmount.Text = "Loan amount:";
         this.lblLoanAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTerm
         // 
         this.lblTerm.Location = new System.Drawing.Point(128, 136);
         this.lblTerm.Name = "lblTerm";
         this.lblTerm.Size = new System.Drawing.Size(80, 21);
         this.lblTerm.TabIndex = 10;
         this.lblTerm.Text = "Term (years):";
         this.lblTerm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblInsurance
         // 
         this.lblInsurance.Location = new System.Drawing.Point(128, 176);
         this.lblInsurance.Name = "lblInsurance";
         this.lblInsurance.Size = new System.Drawing.Size(176, 21);
         this.lblInsurance.TabIndex = 11;
         this.lblInsurance.Text = "Homeowner\'s insurance (yearly):";
         this.lblInsurance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPropertyTaxes
         // 
         this.lblPropertyTaxes.Location = new System.Drawing.Point(128, 216);
         this.lblPropertyTaxes.Name = "lblPropertyTaxes";
         this.lblPropertyTaxes.Size = new System.Drawing.Size(128, 21);
         this.lblPropertyTaxes.TabIndex = 12;
         this.lblPropertyTaxes.Text = "Property taxes (yearly):";
         this.lblPropertyTaxes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblInterest
         // 
         this.lblInterest.Location = new System.Drawing.Point(128, 256);
         this.lblInterest.Name = "lblInterest";
         this.lblInterest.Size = new System.Drawing.Size(120, 21);
         this.lblInterest.TabIndex = 13;
         this.lblInterest.Text = "Interest rate (percent):";
         this.lblInterest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(128, 296);
         this.btnClear.Name = "btnClear";
         this.btnClear.TabIndex = 14;
         this.btnClear.Text = "Clear";
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(216, 296);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.TabIndex = 15;
         this.btnCalculate.Text = "Calculate";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(304, 333);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.lblInterest);
         this.Controls.Add(this.lblPropertyTaxes);
         this.Controls.Add(this.lblInsurance);
         this.Controls.Add(this.lblTerm);
         this.Controls.Add(this.lblLoanAmount);
         this.Controls.Add(this.lblHomeValue);
         this.Controls.Add(this.txtInterest);
         this.Controls.Add(this.txtPropertyTaxes);
         this.Controls.Add(this.txtInsurance);
         this.Controls.Add(this.txtTerm);
         this.Controls.Add(this.txtLoanAmount);
         this.Controls.Add(this.txtHomeValue);
         this.Controls.Add(this.lblMonthlyPayment);
         this.Controls.Add(this.lblMonthlyPaymentResult);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "Form1";
         this.Text = "Mortgage Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run(new Form1());
      }
   }
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/