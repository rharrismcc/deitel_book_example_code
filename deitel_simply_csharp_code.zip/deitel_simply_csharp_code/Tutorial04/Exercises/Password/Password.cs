using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Password
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.TextBox txtUserName;
      private System.Windows.Forms.Label lblPassword;
      private System.Windows.Forms.Label lblPasswordAgain;
      private System.Windows.Forms.TextBox textBox2;
      private System.Windows.Forms.TextBox txtPassword;
      private System.Windows.Forms.Label frmUserName;
      private System.Windows.Forms.Button btnLogIn;
      private System.Windows.Forms.Label lblMessage;
      private System.Windows.Forms.TextBox txtMessage;
      private System.Windows.Forms.Button btnSave;
      private System.Windows.Forms.Button btnLogOut;
      private System.Windows.Forms.Button btnClear;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.frmUserName = new System.Windows.Forms.Label();
         this.txtUserName = new System.Windows.Forms.TextBox();
         this.lblPassword = new System.Windows.Forms.Label();
         this.lblPasswordAgain = new System.Windows.Forms.Label();
         this.txtPassword = new System.Windows.Forms.TextBox();
         this.textBox2 = new System.Windows.Forms.TextBox();
         this.btnLogIn = new System.Windows.Forms.Button();
         this.lblMessage = new System.Windows.Forms.Label();
         this.txtMessage = new System.Windows.Forms.TextBox();
         this.btnSave = new System.Windows.Forms.Button();
         this.btnLogOut = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // frmUserName
         // 
         this.frmUserName.Location = new System.Drawing.Point(16, 16);
         this.frmUserName.Name = "frmUserName";
         this.frmUserName.Size = new System.Drawing.Size(96, 21);
         this.frmUserName.TabIndex = 0;
         this.frmUserName.Text = "Enter your name:";
         this.frmUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtUserName
         // 
         this.txtUserName.Location = new System.Drawing.Point(152, 16);
         this.txtUserName.Name = "txtUserName";
         this.txtUserName.Size = new System.Drawing.Size(144, 21);
         this.txtUserName.TabIndex = 1;
         this.txtUserName.Text = "Joe Purple";
         this.txtUserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblPassword
         // 
         this.lblPassword.Location = new System.Drawing.Point(16, 40);
         this.lblPassword.Name = "lblPassword";
         this.lblPassword.Size = new System.Drawing.Size(112, 21);
         this.lblPassword.TabIndex = 2;
         this.lblPassword.Text = "Enter your password:";
         this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPasswordAgain
         // 
         this.lblPasswordAgain.Location = new System.Drawing.Point(16, 64);
         this.lblPasswordAgain.Name = "lblPasswordAgain";
         this.lblPasswordAgain.Size = new System.Drawing.Size(128, 21);
         this.lblPasswordAgain.TabIndex = 3;
         this.lblPasswordAgain.Text = "Re-enter your password:";
         this.lblPasswordAgain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtPassword
         // 
         this.txtPassword.Location = new System.Drawing.Point(152, 40);
         this.txtPassword.Name = "txtPassword";
         this.txtPassword.PasswordChar = '*';
         this.txtPassword.Size = new System.Drawing.Size(144, 21);
         this.txtPassword.TabIndex = 4;
         this.txtPassword.Text = "Hello2world";
         this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // textBox2
         // 
         this.textBox2.Location = new System.Drawing.Point(152, 64);
         this.textBox2.Name = "textBox2";
         this.textBox2.PasswordChar = '*';
         this.textBox2.Size = new System.Drawing.Size(144, 21);
         this.textBox2.TabIndex = 5;
         this.textBox2.Text = "Hello2world";
         this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnLogIn
         // 
         this.btnLogIn.Location = new System.Drawing.Point(176, 96);
         this.btnLogIn.Name = "btnLogIn";
         this.btnLogIn.Size = new System.Drawing.Size(120, 24);
         this.btnLogIn.TabIndex = 6;
         this.btnLogIn.Text = "Click here to log in";
         // 
         // lblMessage
         // 
         this.lblMessage.Location = new System.Drawing.Point(16, 104);
         this.lblMessage.Name = "lblMessage";
         this.lblMessage.Size = new System.Drawing.Size(144, 21);
         this.lblMessage.TabIndex = 7;
         this.lblMessage.Text = "Enter your secret message:";
         this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtMessage
         // 
         this.txtMessage.Location = new System.Drawing.Point(16, 136);
         this.txtMessage.Multiline = true;
         this.txtMessage.Name = "txtMessage";
         this.txtMessage.Size = new System.Drawing.Size(280, 72);
         this.txtMessage.TabIndex = 8;
         this.txtMessage.Text = "Welcome to Simply C#";
         // 
         // btnSave
         // 
         this.btnSave.Location = new System.Drawing.Point(40, 240);
         this.btnSave.Name = "btnSave";
         this.btnSave.Size = new System.Drawing.Size(72, 24);
         this.btnSave.TabIndex = 9;
         this.btnSave.Text = "Save";
         // 
         // btnLogOut
         // 
         this.btnLogOut.Location = new System.Drawing.Point(120, 240);
         this.btnLogOut.Name = "btnLogOut";
         this.btnLogOut.Size = new System.Drawing.Size(72, 24);
         this.btnLogOut.TabIndex = 10;
         this.btnLogOut.Text = "Log out";
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(224, 240);
         this.btnClear.Name = "btnClear";
         this.btnClear.Size = new System.Drawing.Size(72, 24);
         this.btnClear.TabIndex = 11;
         this.btnClear.Text = "Clear";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(296, 285);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.btnLogOut);
         this.Controls.Add(this.btnSave);
         this.Controls.Add(this.txtMessage);
         this.Controls.Add(this.lblMessage);
         this.Controls.Add(this.btnLogIn);
         this.Controls.Add(this.textBox2);
         this.Controls.Add(this.txtPassword);
         this.Controls.Add(this.lblPasswordAgain);
         this.Controls.Add(this.lblPassword);
         this.Controls.Add(this.txtUserName);
         this.Controls.Add(this.frmUserName);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "Form1";
         this.Text = "Password";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run(new Form1());
      }
   }
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
