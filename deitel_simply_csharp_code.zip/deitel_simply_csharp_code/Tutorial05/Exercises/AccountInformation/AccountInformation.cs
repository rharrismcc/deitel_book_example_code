using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace AccountInformation
{
   /// <summary>
   /// Summary description for FrmAccountInformation.
   /// </summary>
   public class FrmAccountInformation : System.Windows.Forms.Form
   {
      private System.Windows.Forms.GroupBox fraInput;
      private System.Windows.Forms.Label lblNameLabel1;
      private System.Windows.Forms.TextBox txtName;
      private System.Windows.Forms.Label lblAccountNumberLabel1;
      private System.Windows.Forms.TextBox txtAccountNumber;
      private System.Windows.Forms.Label lblDepositAmountLabel1;
      private System.Windows.Forms.TextBox txtDepositAmount;
      private System.Windows.Forms.Button btnEnter;
      private System.Windows.Forms.GroupBox fraOutput;
      private System.Windows.Forms.Label lblNameLabel2;
      private System.Windows.Forms.Label lblCopiedName;
      private System.Windows.Forms.Label lblAccountNumberLabel2;
      private System.Windows.Forms.Label lblCopiedAccountNumber;
      private System.Windows.Forms.Label lblDepositAmountLabel2;
      private System.Windows.Forms.Label lblBalance;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmAccountInformation()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.fraInput = new System.Windows.Forms.GroupBox();
         this.txtDepositAmount = new System.Windows.Forms.TextBox();
         this.txtAccountNumber = new System.Windows.Forms.TextBox();
         this.lblDepositAmountLabel1 = new System.Windows.Forms.Label();
         this.lblAccountNumberLabel1 = new System.Windows.Forms.Label();
         this.lblNameLabel1 = new System.Windows.Forms.Label();
         this.txtName = new System.Windows.Forms.TextBox();
         this.fraOutput = new System.Windows.Forms.GroupBox();
         this.lblBalance = new System.Windows.Forms.Label();
         this.lblCopiedAccountNumber = new System.Windows.Forms.Label();
         this.lblDepositAmountLabel2 = new System.Windows.Forms.Label();
         this.lblAccountNumberLabel2 = new System.Windows.Forms.Label();
         this.lblNameLabel2 = new System.Windows.Forms.Label();
         this.lblCopiedName = new System.Windows.Forms.Label();
         this.btnEnter = new System.Windows.Forms.Button();
         this.fraInput.SuspendLayout();
         this.fraOutput.SuspendLayout();
         this.SuspendLayout();
         // 
         // fraInput
         // 
         this.fraInput.Controls.Add(this.txtDepositAmount);
         this.fraInput.Controls.Add(this.txtAccountNumber);
         this.fraInput.Controls.Add(this.lblDepositAmountLabel1);
         this.fraInput.Controls.Add(this.lblAccountNumberLabel1);
         this.fraInput.Controls.Add(this.lblNameLabel1);
         this.fraInput.Controls.Add(this.txtName);
         this.fraInput.Location = new System.Drawing.Point(16, 16);
         this.fraInput.Name = "fraInput";
         this.fraInput.Size = new System.Drawing.Size(152, 200);
         this.fraInput.TabIndex = 0;
         this.fraInput.TabStop = false;
         this.fraInput.Text = "Enter information";
         // 
         // txtDepositAmount
         // 
         this.txtDepositAmount.Location = new System.Drawing.Point(16, 152);
         this.txtDepositAmount.Name = "txtDepositAmount";
         this.txtDepositAmount.Size = new System.Drawing.Size(120, 21);
         this.txtDepositAmount.TabIndex = 4;
         this.txtDepositAmount.Text = "";
         this.txtDepositAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtAccountNumber
         // 
         this.txtAccountNumber.Location = new System.Drawing.Point(16, 96);
         this.txtAccountNumber.Name = "txtAccountNumber";
         this.txtAccountNumber.Size = new System.Drawing.Size(120, 21);
         this.txtAccountNumber.TabIndex = 3;
         this.txtAccountNumber.Text = "";
         this.txtAccountNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblDepositAmountLabel1
         // 
         this.lblDepositAmountLabel1.Location = new System.Drawing.Point(16, 136);
         this.lblDepositAmountLabel1.Name = "lblDepositAmountLabel1";
         this.lblDepositAmountLabel1.Size = new System.Drawing.Size(100, 16);
         this.lblDepositAmountLabel1.TabIndex = 2;
         this.lblDepositAmountLabel1.Text = "Deposit amount:";
         this.lblDepositAmountLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblAccountNumberLabel1
         // 
         this.lblAccountNumberLabel1.Location = new System.Drawing.Point(16, 80);
         this.lblAccountNumberLabel1.Name = "lblAccountNumberLabel1";
         this.lblAccountNumberLabel1.Size = new System.Drawing.Size(100, 16);
         this.lblAccountNumberLabel1.TabIndex = 1;
         this.lblAccountNumberLabel1.Text = "Account number:";
         this.lblAccountNumberLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblNameLabel1
         // 
         this.lblNameLabel1.Location = new System.Drawing.Point(16, 24);
         this.lblNameLabel1.Name = "lblNameLabel1";
         this.lblNameLabel1.Size = new System.Drawing.Size(80, 16);
         this.lblNameLabel1.TabIndex = 0;
         this.lblNameLabel1.Text = "Name:";
         this.lblNameLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtName
         // 
         this.txtName.Location = new System.Drawing.Point(16, 40);
         this.txtName.Name = "txtName";
         this.txtName.Size = new System.Drawing.Size(120, 21);
         this.txtName.TabIndex = 1;
         this.txtName.Text = "";
         this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // fraOutput
         // 
         this.fraOutput.Controls.Add(this.lblBalance);
         this.fraOutput.Controls.Add(this.lblCopiedAccountNumber);
         this.fraOutput.Controls.Add(this.lblDepositAmountLabel2);
         this.fraOutput.Controls.Add(this.lblAccountNumberLabel2);
         this.fraOutput.Controls.Add(this.lblNameLabel2);
         this.fraOutput.Controls.Add(this.lblCopiedName);
         this.fraOutput.Location = new System.Drawing.Point(280, 16);
         this.fraOutput.Name = "fraOutput";
         this.fraOutput.Size = new System.Drawing.Size(144, 200);
         this.fraOutput.TabIndex = 1;
         this.fraOutput.TabStop = false;
         this.fraOutput.Text = "Account information";
         // 
         // lblBalance
         // 
         this.lblBalance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblBalance.Location = new System.Drawing.Point(16, 152);
         this.lblBalance.Name = "lblBalance";
         this.lblBalance.Size = new System.Drawing.Size(104, 21);
         this.lblBalance.TabIndex = 4;
         this.lblBalance.Text = "0";
         this.lblBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblCopiedAccountNumber
         // 
         this.lblCopiedAccountNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblCopiedAccountNumber.Location = new System.Drawing.Point(16, 96);
         this.lblCopiedAccountNumber.Name = "lblCopiedAccountNumber";
         this.lblCopiedAccountNumber.Size = new System.Drawing.Size(104, 21);
         this.lblCopiedAccountNumber.TabIndex = 3;
         this.lblCopiedAccountNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblDepositAmountLabel2
         // 
         this.lblDepositAmountLabel2.Location = new System.Drawing.Point(16, 136);
         this.lblDepositAmountLabel2.Name = "lblDepositAmountLabel2";
         this.lblDepositAmountLabel2.Size = new System.Drawing.Size(100, 16);
         this.lblDepositAmountLabel2.TabIndex = 2;
         this.lblDepositAmountLabel2.Text = "Deposit amount:";
         this.lblDepositAmountLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblAccountNumberLabel2
         // 
         this.lblAccountNumberLabel2.Location = new System.Drawing.Point(16, 80);
         this.lblAccountNumberLabel2.Name = "lblAccountNumberLabel2";
         this.lblAccountNumberLabel2.Size = new System.Drawing.Size(100, 16);
         this.lblAccountNumberLabel2.TabIndex = 1;
         this.lblAccountNumberLabel2.Text = "Account number:";
         this.lblAccountNumberLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblNameLabel2
         // 
         this.lblNameLabel2.Location = new System.Drawing.Point(16, 24);
         this.lblNameLabel2.Name = "lblNameLabel2";
         this.lblNameLabel2.Size = new System.Drawing.Size(80, 16);
         this.lblNameLabel2.TabIndex = 0;
         this.lblNameLabel2.Text = "Name:";
         this.lblNameLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblCopiedName
         // 
         this.lblCopiedName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblCopiedName.Location = new System.Drawing.Point(16, 40);
         this.lblCopiedName.Name = "lblCopiedName";
         this.lblCopiedName.Size = new System.Drawing.Size(104, 21);
         this.lblCopiedName.TabIndex = 2;
         this.lblCopiedName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnEnter
         // 
         this.btnEnter.Location = new System.Drawing.Point(184, 112);
         this.btnEnter.Name = "btnEnter";
         this.btnEnter.TabIndex = 2;
         this.btnEnter.Text = "Enter";
         // 
         // FrmAccountInformation
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(448, 237);
         this.Controls.Add(this.btnEnter);
         this.Controls.Add(this.fraOutput);
         this.Controls.Add(this.fraInput);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmAccountInformation";
         this.Text = "Account Information";
         this.fraInput.ResumeLayout(false);
         this.fraOutput.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmAccountInformation() );
      }

   } // end class FrmAccountInformation
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
