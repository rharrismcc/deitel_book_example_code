using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Inventory
{
   /// <summary>
   /// Summary description for FrmInventory.
   /// </summary>
   public class FrmInventory : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Label lblCartons;
      private System.Windows.Forms.Label lblItems;
      private System.Windows.Forms.Label lblTotal;
      private System.Windows.Forms.Label lblTotalResult;
      private System.Windows.Forms.TextBox txtCartons;
      private System.Windows.Forms.TextBox txtItems;
      private System.Windows.Forms.Button btnCalculate;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmInventory()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblCartons = new System.Windows.Forms.Label();
         this.lblItems = new System.Windows.Forms.Label();
         this.lblTotal = new System.Windows.Forms.Label();
         this.lblTotalResult = new System.Windows.Forms.Label();
         this.txtCartons = new System.Windows.Forms.TextBox();
         this.txtItems = new System.Windows.Forms.TextBox();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblCartons
         // 
         this.lblCartons.Location = new System.Drawing.Point(8, 18);
         this.lblCartons.Name = "lblCartons";
         this.lblCartons.Size = new System.Drawing.Size(120, 21);
         this.lblCartons.TabIndex = 0;
         this.lblCartons.Text = "Cartons per shipment:";
         this.lblCartons.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblItems
         // 
         this.lblItems.Location = new System.Drawing.Point(8, 48);
         this.lblItems.Name = "lblItems";
         this.lblItems.Size = new System.Drawing.Size(104, 21);
         this.lblItems.TabIndex = 1;
         this.lblItems.Text = "Items per carton:";
         this.lblItems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotal
         // 
         this.lblTotal.Location = new System.Drawing.Point(184, 16);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(40, 21);
         this.lblTotal.TabIndex = 2;
         this.lblTotal.Text = "Total:";
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotalResult
         // 
         this.lblTotalResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalResult.Location = new System.Drawing.Point(224, 16);
         this.lblTotalResult.Name = "lblTotalResult";
         this.lblTotalResult.Size = new System.Drawing.Size(48, 21);
         this.lblTotalResult.TabIndex = 3;
         this.lblTotalResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // txtCartons
         // 
         this.txtCartons.Location = new System.Drawing.Point(128, 16);
         this.txtCartons.Name = "txtCartons";
         this.txtCartons.Size = new System.Drawing.Size(40, 21);
         this.txtCartons.TabIndex = 4;
         this.txtCartons.Text = "0";
         this.txtCartons.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtItems
         // 
         this.txtItems.Location = new System.Drawing.Point(128, 48);
         this.txtItems.Name = "txtItems";
         this.txtItems.Size = new System.Drawing.Size(40, 21);
         this.txtItems.TabIndex = 5;
         this.txtItems.Text = "0";
         this.txtItems.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(184, 48);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(88, 24);
         this.btnCalculate.TabIndex = 6;
         this.btnCalculate.Text = "Calculate Total";
         this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
         // 
         // FrmInventory
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(288, 85);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.txtItems);
         this.Controls.Add(this.txtCartons);
         this.Controls.Add(this.lblTotalResult);
         this.Controls.Add(this.lblTotal);
         this.Controls.Add(this.lblItems);
         this.Controls.Add(this.lblCartons);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmInventory";
         this.Text = "Inventory";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmInventory() );
      }

      // handles Click event
      private void btnCalculate_Click(
         object sender, System.EventArgs e )
      {
         // multiply values input and display result in Label
         lblTotalResult.Text = Convert.ToString(
            Int32.Parse( txtCartons.Text ) *
            Int32.Parse( txtItems.Text ) );

      } // end method btnCalculate_Click

   } // end class FrmInventory
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
