using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Maximum
{
   /// <summary>
   /// Summary description for FrmAverageDebugging.
   /// </summary>
   public class FrmAverageDebugging : System.Windows.Forms.Form
   {
      // Labels and TextBoxes to input the three values
      private System.Windows.Forms.Label lblFirst;
      private System.Windows.Forms.TextBox txtFirst;

      private System.Windows.Forms.Label lblSecond;
      private System.Windows.Forms.TextBox txtSecond;

      private System.Windows.Forms.Label lblThird;
      private System.Windows.Forms.TextBox txtThird;

      // Labels to display the average value
      private System.Windows.Forms.Label lblAverage;
      private System.Windows.Forms.Label lblOutput;

      // Button to calculate the average value
      private System.Windows.Forms.Button btnCalculate;
      
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmAverageDebugging()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblFirst = new System.Windows.Forms.Label();
         this.lblSecond = new System.Windows.Forms.Label();
         this.lblThird = new System.Windows.Forms.Label();
         this.lblAverage = new System.Windows.Forms.Label();
         this.lblOutput = new System.Windows.Forms.Label();
         this.txtFirst = new System.Windows.Forms.TextBox();
         this.txtSecond = new System.Windows.Forms.TextBox();
         this.txtThird = new System.Windows.Forms.TextBox();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblFirst
         // 
         this.lblFirst.Location = new System.Drawing.Point(16, 16);
         this.lblFirst.Name = "lblFirst";
         this.lblFirst.Size = new System.Drawing.Size(100, 24);
         this.lblFirst.TabIndex = 0;
         this.lblFirst.Text = "Enter first value:";
         this.lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblSecond
         // 
         this.lblSecond.Location = new System.Drawing.Point(16, 56);
         this.lblSecond.Name = "lblSecond";
         this.lblSecond.Size = new System.Drawing.Size(120, 24);
         this.lblSecond.TabIndex = 1;
         this.lblSecond.Text = "Enter second value:";
         this.lblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblThird
         // 
         this.lblThird.Location = new System.Drawing.Point(16, 96);
         this.lblThird.Name = "lblThird";
         this.lblThird.Size = new System.Drawing.Size(120, 24);
         this.lblThird.TabIndex = 2;
         this.lblThird.Text = "Enter third value:";
         this.lblThird.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblAverage
         // 
         this.lblAverage.Location = new System.Drawing.Point(16, 152);
         this.lblAverage.Name = "lblAverage";
         this.lblAverage.Size = new System.Drawing.Size(100, 24);
         this.lblAverage.TabIndex = 3;
         this.lblAverage.Text = "Average is:";
         this.lblAverage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput
         // 
         this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput.Location = new System.Drawing.Point(144, 152);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(64, 24);
         this.lblOutput.TabIndex = 4;
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // txtFirst
         // 
         this.txtFirst.Location = new System.Drawing.Point(144, 16);
         this.txtFirst.Name = "txtFirst";
         this.txtFirst.Size = new System.Drawing.Size(64, 21);
         this.txtFirst.TabIndex = 5;
         this.txtFirst.Text = "";
         this.txtFirst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtSecond
         // 
         this.txtSecond.Location = new System.Drawing.Point(144, 56);
         this.txtSecond.Name = "txtSecond";
         this.txtSecond.Size = new System.Drawing.Size(64, 21);
         this.txtSecond.TabIndex = 6;
         this.txtSecond.Text = "";
         this.txtSecond.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtThird
         // 
         this.txtThird.Location = new System.Drawing.Point(144, 96);
         this.txtThird.Name = "txtThird";
         this.txtThird.Size = new System.Drawing.Size(64, 21);
         this.txtThird.TabIndex = 7;
         this.txtThird.Text = "";
         this.txtThird.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(144, 192);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.TabIndex = 8;
         this.btnCalculate.Text = "Calculate";
         this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
         // 
         // FrmAverageDebugging
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(240, 229);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.txtThird);
         this.Controls.Add(this.txtSecond);
         this.Controls.Add(this.txtFirst);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.lblAverage);
         this.Controls.Add(this.lblThird);
         this.Controls.Add(this.lblSecond);
         this.Controls.Add(this.lblFirst);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmAverageDebugging";
         this.Text = "Average Three Numbers";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmAverageDebugging() );
      }

      // handles Click event
      private void btnCalculate_Click(
         object sender, System.EventArgs e )
      {
         // variables to store user inputs
         int intNumber1;
         int intNumber2;
         int intNumber3;
         int intAverage;

         // obtain user inputs
         intNumber1 = Int32.Parse( txtFirst.Text );
         intNumber2 = Int32.Parse( txtSecond.Text );
         intNumber3 = Int32.Parse( txtThird.Text );

         // average numbers
         intAverage = intNumber1 + intNumber2 + intNumber3 / 3;

         // display result
         lblOutput.Text = Convert.ToString( intAverage );

      } // end method btnCalculateClick

   } // end class FrmAverageDebugging
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
