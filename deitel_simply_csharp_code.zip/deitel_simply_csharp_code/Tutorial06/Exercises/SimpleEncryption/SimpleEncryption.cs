using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SimpleEncryption
{
   /// <summary>
   /// Summary description for FrmEncryption.
   /// </summary>
   public class FrmEncryption : System.Windows.Forms.Form
   {
      // Label and TextBox to input number
      private System.Windows.Forms.Label lblInput;
      private System.Windows.Forms.TextBox txtInput;

      // Labels to display encrypted number
      private System.Windows.Forms.Label lblOutput;
      private System.Windows.Forms.Label lblResult;

      // Button to perform the encryption
      private System.Windows.Forms.Button btnEncrypt;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmEncryption()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblInput = new System.Windows.Forms.Label();
         this.txtInput = new System.Windows.Forms.TextBox();
         this.lblOutput = new System.Windows.Forms.Label();
         this.lblResult = new System.Windows.Forms.Label();
         this.btnEncrypt = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblInput
         // 
         this.lblInput.Location = new System.Drawing.Point(8, 16);
         this.lblInput.Name = "lblInput";
         this.lblInput.Size = new System.Drawing.Size(136, 23);
         this.lblInput.TabIndex = 0;
         this.lblInput.Text = "Enter number to encrypt:";
         this.lblInput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtInput
         // 
         this.txtInput.Location = new System.Drawing.Point(144, 16);
         this.txtInput.Name = "txtInput";
         this.txtInput.Size = new System.Drawing.Size(56, 21);
         this.txtInput.TabIndex = 1;
         this.txtInput.Text = "";
         this.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblOutput
         // 
         this.lblOutput.Location = new System.Drawing.Point(8, 48);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.TabIndex = 2;
         this.lblOutput.Text = "Encrypted number:";
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblResult
         // 
         this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblResult.Location = new System.Drawing.Point(144, 48);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(56, 23);
         this.lblResult.TabIndex = 3;
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnEncrypt
         // 
         this.btnEncrypt.Location = new System.Drawing.Point(216, 16);
         this.btnEncrypt.Name = "btnEncrypt";
         this.btnEncrypt.TabIndex = 4;
         this.btnEncrypt.Text = "Encrypt";
         // 
         // FrmEncryption
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(304, 85);
         this.Controls.Add(this.btnEncrypt);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.txtInput);
         this.Controls.Add(this.lblInput);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmEncryption";
         this.Text = "Simple Encryption";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmEncryption() );
      }

   } // end class FrmEncryption
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
