using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CreditChecker
{
   /// <summary>
   /// Summary description for FrmCreditChecker.
   /// </summary>
   public class FrmCreditChecker : System.Windows.Forms.Form
   {
      // Label and TextBox to input account number
      private System.Windows.Forms.Label lblAccountNumber;
      private System.Windows.Forms.TextBox txtAccountNumber;

      // Label and TextBox to input starting balance
      private System.Windows.Forms.Label lblStartBalance;
      private System.Windows.Forms.TextBox txtStartBalance;

      // Label and TextBox to input total charges
      private System.Windows.Forms.Label lblTotalCharges;
      private System.Windows.Forms.TextBox txtTotalCharges;

      // Label and TextBox to input total credits
      private System.Windows.Forms.Label lblTotalCredits;
      private System.Windows.Forms.TextBox txtTotalCredits;

      // Label and TextBox to input credit limit
      private System.Windows.Forms.Label lblCreditLimit;
      private System.Windows.Forms.TextBox txtCreditLimit;

      // Labels to display new balance amount
      private System.Windows.Forms.Label lblNewBalance;
      private System.Windows.Forms.Label lblNewBalanceNumber;

      // Label to display a message if the credit limit is
      // exceeded
      private System.Windows.Forms.Label lblError;

      // Button to calculate the new balance
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmCreditChecker()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblAccountNumber = new System.Windows.Forms.Label();
         this.txtAccountNumber = new System.Windows.Forms.TextBox();
         this.lblStartBalance = new System.Windows.Forms.Label();
         this.txtStartBalance = new System.Windows.Forms.TextBox();
         this.lblTotalCharges = new System.Windows.Forms.Label();
         this.txtTotalCharges = new System.Windows.Forms.TextBox();
         this.lblTotalCredits = new System.Windows.Forms.Label();
         this.txtTotalCredits = new System.Windows.Forms.TextBox();
         this.lblCreditLimit = new System.Windows.Forms.Label();
         this.txtCreditLimit = new System.Windows.Forms.TextBox();
         this.lblNewBalance = new System.Windows.Forms.Label();
         this.lblNewBalanceNumber = new System.Windows.Forms.Label();
         this.lblError = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblAccountNumber
         // 
         this.lblAccountNumber.Location = new System.Drawing.Point(16, 16);
         this.lblAccountNumber.Name = "lblAccountNumber";
         this.lblAccountNumber.TabIndex = 0;
         this.lblAccountNumber.Text = "Account number:";
         this.lblAccountNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtAccountNumber
         // 
         this.txtAccountNumber.Location = new System.Drawing.Point(120, 16);
         this.txtAccountNumber.Name = "txtAccountNumber";
         this.txtAccountNumber.Size = new System.Drawing.Size(96, 21);
         this.txtAccountNumber.TabIndex = 1;
         this.txtAccountNumber.Text = "";
         this.txtAccountNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblStartBalance
         // 
         this.lblStartBalance.Location = new System.Drawing.Point(16, 56);
         this.lblStartBalance.Name = "lblStartBalance";
         this.lblStartBalance.TabIndex = 2;
         this.lblStartBalance.Text = "Starting balance:";
         this.lblStartBalance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtStartBalance
         // 
         this.txtStartBalance.Location = new System.Drawing.Point(120, 56);
         this.txtStartBalance.Name = "txtStartBalance";
         this.txtStartBalance.Size = new System.Drawing.Size(96, 21);
         this.txtStartBalance.TabIndex = 3;
         this.txtStartBalance.Text = "";
         this.txtStartBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblTotalCharges
         // 
         this.lblTotalCharges.Location = new System.Drawing.Point(16, 96);
         this.lblTotalCharges.Name = "lblTotalCharges";
         this.lblTotalCharges.TabIndex = 4;
         this.lblTotalCharges.Text = "Total charges:";
         this.lblTotalCharges.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtTotalCharges
         // 
         this.txtTotalCharges.Location = new System.Drawing.Point(120, 96);
         this.txtTotalCharges.Name = "txtTotalCharges";
         this.txtTotalCharges.Size = new System.Drawing.Size(96, 21);
         this.txtTotalCharges.TabIndex = 5;
         this.txtTotalCharges.Text = "";
         this.txtTotalCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblTotalCredits
         // 
         this.lblTotalCredits.Location = new System.Drawing.Point(16, 136);
         this.lblTotalCredits.Name = "lblTotalCredits";
         this.lblTotalCredits.TabIndex = 6;
         this.lblTotalCredits.Text = "Total credits:";
         this.lblTotalCredits.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtTotalCredits
         // 
         this.txtTotalCredits.Location = new System.Drawing.Point(120, 136);
         this.txtTotalCredits.Name = "txtTotalCredits";
         this.txtTotalCredits.Size = new System.Drawing.Size(96, 21);
         this.txtTotalCredits.TabIndex = 7;
         this.txtTotalCredits.Text = "";
         this.txtTotalCredits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblCreditLimit
         // 
         this.lblCreditLimit.Location = new System.Drawing.Point(16, 176);
         this.lblCreditLimit.Name = "lblCreditLimit";
         this.lblCreditLimit.TabIndex = 8;
         this.lblCreditLimit.Text = "Credit limit:";
         this.lblCreditLimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtCreditLimit
         // 
         this.txtCreditLimit.Location = new System.Drawing.Point(120, 176);
         this.txtCreditLimit.Name = "txtCreditLimit";
         this.txtCreditLimit.Size = new System.Drawing.Size(96, 21);
         this.txtCreditLimit.TabIndex = 9;
         this.txtCreditLimit.Text = "";
         this.txtCreditLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblNewBalance
         // 
         this.lblNewBalance.Location = new System.Drawing.Point(16, 216);
         this.lblNewBalance.Name = "lblNewBalance";
         this.lblNewBalance.TabIndex = 10;
         this.lblNewBalance.Text = "New balance:";
         this.lblNewBalance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblNewBalanceNumber
         // 
         this.lblNewBalanceNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblNewBalanceNumber.Location = new System.Drawing.Point(120, 216);
         this.lblNewBalanceNumber.Name = "lblNewBalanceNumber";
         this.lblNewBalanceNumber.Size = new System.Drawing.Size(96, 23);
         this.lblNewBalanceNumber.TabIndex = 11;
         this.lblNewBalanceNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblError
         // 
         this.lblError.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblError.Location = new System.Drawing.Point(16, 256);
         this.lblError.Name = "lblError";
         this.lblError.Size = new System.Drawing.Size(200, 23);
         this.lblError.TabIndex = 12;
         this.lblError.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(96, 296);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(120, 23);
         this.btnCalculate.TabIndex = 13;
         this.btnCalculate.Text = "Calculate Balance";
         // 
         // FrmCreditChecker
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(232, 333);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblError);
         this.Controls.Add(this.lblNewBalanceNumber);
         this.Controls.Add(this.lblNewBalance);
         this.Controls.Add(this.txtCreditLimit);
         this.Controls.Add(this.lblCreditLimit);
         this.Controls.Add(this.txtTotalCredits);
         this.Controls.Add(this.lblTotalCredits);
         this.Controls.Add(this.txtTotalCharges);
         this.Controls.Add(this.lblTotalCharges);
         this.Controls.Add(this.txtStartBalance);
         this.Controls.Add(this.lblStartBalance);
         this.Controls.Add(this.txtAccountNumber);
         this.Controls.Add(this.lblAccountNumber);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCreditChecker";
         this.Text = "Credit Checker";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCreditChecker() );
      }

   } // end class FrmCreditChecker
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/