using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CurrencyConverter
{
   /// <summary>
   /// Summary description for FrmCurrencyConverter.
   /// </summary>
   public class FrmCurrencyConverter : System.Windows.Forms.Form
   {
      // Label and TextBox to input amount of dollars
      private System.Windows.Forms.Label lblConvert;
      private System.Windows.Forms.TextBox txtValue;

      // Label and TextBox to input currency to convert into
      private System.Windows.Forms.Label lblTo;
      private System.Windows.Forms.TextBox txtCurrency;

      // Labels to output converted value
      private System.Windows.Forms.Label lblOutput;
      private System.Windows.Forms.Label lblConvertedResult;

      // Button to convert dollars into another currency
      private System.Windows.Forms.Button btnConvert;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmCurrencyConverter()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblConvert = new System.Windows.Forms.Label();
         this.txtValue = new System.Windows.Forms.TextBox();
         this.lblTo = new System.Windows.Forms.Label();
         this.txtCurrency = new System.Windows.Forms.TextBox();
         this.lblOutput = new System.Windows.Forms.Label();
         this.lblConvertedResult = new System.Windows.Forms.Label();
         this.btnConvert = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblConvert
         // 
         this.lblConvert.Location = new System.Drawing.Point(16, 16);
         this.lblConvert.Name = "lblConvert";
         this.lblConvert.TabIndex = 0;
         this.lblConvert.Text = "Dollars to Convert:";
         this.lblConvert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtValue
         // 
         this.txtValue.Location = new System.Drawing.Point(152, 16);
         this.txtValue.Name = "txtValue";
         this.txtValue.Size = new System.Drawing.Size(96, 21);
         this.txtValue.TabIndex = 1;
         this.txtValue.Text = "";
         this.txtValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblTo
         // 
         this.lblTo.Location = new System.Drawing.Point(16, 56);
         this.lblTo.Name = "lblTo";
         this.lblTo.Size = new System.Drawing.Size(128, 23);
         this.lblTo.TabIndex = 2;
         this.lblTo.Text = "Convert from Dollars to:";
         this.lblTo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtCurrency
         // 
         this.txtCurrency.Location = new System.Drawing.Point(152, 56);
         this.txtCurrency.Name = "txtCurrency";
         this.txtCurrency.Size = new System.Drawing.Size(96, 21);
         this.txtCurrency.TabIndex = 3;
         this.txtCurrency.Text = "";
         this.txtCurrency.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblOutput
         // 
         this.lblOutput.Location = new System.Drawing.Point(16, 96);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(104, 23);
         this.lblOutput.TabIndex = 4;
         this.lblOutput.Text = "Converted Amount:";
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblConvertedResult
         // 
         this.lblConvertedResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblConvertedResult.Location = new System.Drawing.Point(152, 96);
         this.lblConvertedResult.Name = "lblConvertedResult";
         this.lblConvertedResult.Size = new System.Drawing.Size(96, 23);
         this.lblConvertedResult.TabIndex = 5;
         this.lblConvertedResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnConvert
         // 
         this.btnConvert.Location = new System.Drawing.Point(152, 136);
         this.btnConvert.Name = "btnConvert";
         this.btnConvert.Size = new System.Drawing.Size(96, 23);
         this.btnConvert.TabIndex = 6;
         this.btnConvert.Text = "Convert";
         // 
         // FrmCurrencyConverter
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(264, 173);
         this.Controls.Add(this.btnConvert);
         this.Controls.Add(this.lblConvertedResult);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.txtCurrency);
         this.Controls.Add(this.lblTo);
         this.Controls.Add(this.txtValue);
         this.Controls.Add(this.lblConvert);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCurrencyConverter";
         this.Text = "Currency Converter";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCurrencyConverter() );
      }

   } // end class FrmCurrencyConverter
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/