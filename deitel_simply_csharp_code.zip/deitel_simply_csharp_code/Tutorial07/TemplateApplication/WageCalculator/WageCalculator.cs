using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WageCalculator
{
   /// <summary>
   /// Summary description for FrmWageCalculator.
   /// </summary>
   public class FrmWageCalculator : System.Windows.Forms.Form
   {
      // Label and TextBox for hourly wage
      private System.Windows.Forms.Label lblWage;
      private System.Windows.Forms.TextBox txtWage;

      // Label and Textbox for weekly hours
      private System.Windows.Forms.Label lbHours;
      private System.Windows.Forms.TextBox txtHours;

      // Labels to display gross earnings
      private System.Windows.Forms.Label lblEarnings;
      private System.Windows.Forms.Label lblEarningsResult;

      // Button to calculate total earnings
      private System.Windows.Forms.Button btnCalculate;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmWageCalculator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblWage = new System.Windows.Forms.Label();
         this.lbHours = new System.Windows.Forms.Label();
         this.txtWage = new System.Windows.Forms.TextBox();
         this.txtHours = new System.Windows.Forms.TextBox();
         this.lblEarnings = new System.Windows.Forms.Label();
         this.lblEarningsResult = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblWage
         // 
         this.lblWage.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblWage.Location = new System.Drawing.Point(16, 16);
         this.lblWage.Name = "lblWage";
         this.lblWage.Size = new System.Drawing.Size(80, 21);
         this.lblWage.TabIndex = 0;
         this.lblWage.Text = "Hourly wage:";
         this.lblWage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lbHours
         // 
         this.lbHours.Location = new System.Drawing.Point(16, 56);
         this.lbHours.Name = "lbHours";
         this.lbHours.Size = new System.Drawing.Size(80, 21);
         this.lbHours.TabIndex = 1;
         this.lbHours.Text = "Weekly hours:";
         this.lbHours.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtWage
         // 
         this.txtWage.Location = new System.Drawing.Point(112, 16);
         this.txtWage.Name = "txtWage";
         this.txtWage.Size = new System.Drawing.Size(64, 21);
         this.txtWage.TabIndex = 2;
         this.txtWage.Text = "0";
         this.txtWage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtHours
         // 
         this.txtHours.Location = new System.Drawing.Point(112, 56);
         this.txtHours.Name = "txtHours";
         this.txtHours.Size = new System.Drawing.Size(64, 21);
         this.txtHours.TabIndex = 3;
         this.txtHours.Text = "0";
         this.txtHours.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblEarnings
         // 
         this.lblEarnings.Location = new System.Drawing.Point(16, 96);
         this.lblEarnings.Name = "lblEarnings";
         this.lblEarnings.Size = new System.Drawing.Size(88, 21);
         this.lblEarnings.TabIndex = 4;
         this.lblEarnings.Text = "Gross Earnings:";
         this.lblEarnings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblEarningsResult
         // 
         this.lblEarningsResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblEarningsResult.Location = new System.Drawing.Point(112, 96);
         this.lblEarningsResult.Name = "lblEarningsResult";
         this.lblEarningsResult.Size = new System.Drawing.Size(64, 21);
         this.lblEarningsResult.TabIndex = 0;
         this.lblEarningsResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(112, 136);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(64, 24);
         this.btnCalculate.TabIndex = 5;
         this.btnCalculate.Text = "Calculate";
         // 
         // FrmWageCalculator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(192, 173);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblEarningsResult);
         this.Controls.Add(this.lblEarnings);
         this.Controls.Add(this.txtHours);
         this.Controls.Add(this.txtWage);
         this.Controls.Add(this.lbHours);
         this.Controls.Add(this.lblWage);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmWageCalculator";
         this.Text = "Wage Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmWageCalculator() );
      }

   } // end class FrmWageCalculator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/