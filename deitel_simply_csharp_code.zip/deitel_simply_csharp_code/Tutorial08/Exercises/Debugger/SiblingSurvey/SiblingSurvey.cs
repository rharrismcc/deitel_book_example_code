using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SiblingSurvey
{
   /// <summary>
   /// Summary description for FrmSiblingSurvey.
   /// </summary>
   public class FrmSiblingSurvey : System.Windows.Forms.Form
   {
      // Label that gives directions for the survey
      private System.Windows.Forms.Label lblDirections;

      // CheckBoxes to choose siblings
      private System.Windows.Forms.CheckBox chkBrother;
      private System.Windows.Forms.CheckBox chkSister;
      private System.Windows.Forms.CheckBox chkNone;
      
      // Button to submit information
      private System.Windows.Forms.Button btnSubmit;
		
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmSiblingSurvey()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblDirections = new System.Windows.Forms.Label();
         this.chkBrother = new System.Windows.Forms.CheckBox();
         this.chkSister = new System.Windows.Forms.CheckBox();
         this.chkNone = new System.Windows.Forms.CheckBox();
         this.btnSubmit = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblDirections
         // 
         this.lblDirections.Location = new System.Drawing.Point(16, 16);
         this.lblDirections.Name = "lblDirections";
         this.lblDirections.Size = new System.Drawing.Size(184, 23);
         this.lblDirections.TabIndex = 1;
         this.lblDirections.Text = "Please select the siblings you have:";
         this.lblDirections.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // chkBrother
         // 
         this.chkBrother.Location = new System.Drawing.Point(16, 56);
         this.chkBrother.Name = "chkBrother";
         this.chkBrother.TabIndex = 2;
         this.chkBrother.Text = "Brother(s)";
         // 
         // chkSister
         // 
         this.chkSister.Location = new System.Drawing.Point(16, 96);
         this.chkSister.Name = "chkSister";
         this.chkSister.TabIndex = 3;
         this.chkSister.Text = "Sister(s)";
         // 
         // chkNone
         // 
         this.chkNone.Location = new System.Drawing.Point(16, 136);
         this.chkNone.Name = "chkNone";
         this.chkNone.TabIndex = 4;
         this.chkNone.Text = "No Siblings";
         // 
         // btnSubmit
         // 
         this.btnSubmit.Location = new System.Drawing.Point(56, 176);
         this.btnSubmit.Name = "btnSubmit";
         this.btnSubmit.Size = new System.Drawing.Size(104, 23);
         this.btnSubmit.TabIndex = 5;
         this.btnSubmit.Text = "Submit Survey";
         this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
         // 
         // FrmSiblingSurvey
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(216, 213);
         this.Controls.Add(this.btnSubmit);
         this.Controls.Add(this.chkNone);
         this.Controls.Add(this.chkSister);
         this.Controls.Add(this.chkBrother);
         this.Controls.Add(this.lblDirections);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmSiblingSurvey";
         this.Text = "Sibling Survey";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmSiblingSurvey() );
      }

      // handles Click event
      private void btnSubmit_Click( 
         object sender, System.EventArgs e )
      {
         // check if user selects brothers or sisters
         // and no siblings
         if ( chkNone.Checked == true &&
            chkBrother.Checked == true &&
            chkSister.Checked == true )
         {
            MessageBox.Show( "Selected combination is not possible",
               "Invalid Input", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         }
         // check if user selects CheckBox
         else if ( chkNone.Checked == false && 
            chkBrother.Checked == false && 
            chkSister.Checked == false )
         {
            MessageBox.Show( "Please check at least one CheckBox", 
               "Invalid Input", MessageBoxButtons.OK, 
               MessageBoxIcon.Exclamation );
         }
         // check if user has brothers and sisters
         else if ( chkBrother.Checked == true || 
            chkSister.Checked == true )
         {
            MessageBox.Show( "You have brothers and sisters", 
               "Siblings", MessageBoxButtons.OK, 
               MessageBoxIcon.Information );
         }
         // check if user has brothers
         else if ( chkBrother.Checked == true )
         {
            MessageBox.Show( "You have at least one brother",
               "Siblings", MessageBoxButtons.OK, 
               MessageBoxIcon.Information );
         }
         // check if user has sisters
         else if ( chkSister.Checked == true )
         {
            MessageBox.Show( "You have at least one sister", 
               "Siblings", MessageBoxButtons.OK, 
               MessageBoxIcon.Information );
         }
         // user has no siblings
         else
         {
            MessageBox.Show( "You have no siblings", 
               "Siblings", MessageBoxButtons.OK, 
               MessageBoxIcon.Information );
         }

      } // end method btnSubmit_Click

   } // end class FrmSiblingSurvey
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
