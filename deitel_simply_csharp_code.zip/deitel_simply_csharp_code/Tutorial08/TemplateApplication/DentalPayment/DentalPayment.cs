using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DentalPayment
{
   /// <summary>
   /// Summary description for FrmDentalPayment.
   /// </summary>
   public class FrmDentalPayment : System.Windows.Forms.Form
   {
      // Label displaying title
      private System.Windows.Forms.Label lblTitle;

      // Label and TextBox for patient name
      private System.Windows.Forms.Label lblName;
      private System.Windows.Forms.TextBox txtName;

      // Label for a cleaning
      private System.Windows.Forms.Label lblCleanCost;

      // Label for a filling
      private System.Windows.Forms.Label lblFillingCost;

      // Label for an X-Ray
      private System.Windows.Forms.Label lblXRayCost;

      // Labels to display total cost
      private System.Windows.Forms.Label lblTotal;
      private System.Windows.Forms.Label lblTotalResult;

      // Button to calculate total cost
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmDentalPayment()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();
         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblTitle = new System.Windows.Forms.Label();
         this.lblName = new System.Windows.Forms.Label();
         this.txtName = new System.Windows.Forms.TextBox();
         this.lblCleanCost = new System.Windows.Forms.Label();
         this.lblFillingCost = new System.Windows.Forms.Label();
         this.lblXRayCost = new System.Windows.Forms.Label();
         this.lblTotal = new System.Windows.Forms.Label();
         this.lblTotalResult = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblTitle
         // 
         this.lblTitle.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblTitle.Location = new System.Drawing.Point(19, 19);
         this.lblTitle.Name = "lblTitle";
         this.lblTitle.Size = new System.Drawing.Size(235, 28);
         this.lblTitle.TabIndex = 0;
         this.lblTitle.Text = "Dental Payment";
         this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblName
         // 
         this.lblName.Location = new System.Drawing.Point(19, 65);
         this.lblName.Name = "lblName";
         this.lblName.Size = new System.Drawing.Size(91, 21);
         this.lblName.TabIndex = 1;
         this.lblName.Text = "Patient Name:";
         this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtName
         // 
         this.txtName.Location = new System.Drawing.Point(132, 65);
         this.txtName.Name = "txtName";
         this.txtName.Size = new System.Drawing.Size(117, 21);
         this.txtName.TabIndex = 2;
         this.txtName.Text = "";
         // 
         // lblCleanCost
         // 
         this.lblCleanCost.Location = new System.Drawing.Point(211, 112);
         this.lblCleanCost.Name = "lblCleanCost";
         this.lblCleanCost.Size = new System.Drawing.Size(38, 24);
         this.lblCleanCost.TabIndex = 3;
         this.lblCleanCost.Text = "$35";
         this.lblCleanCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblFillingCost
         // 
         this.lblFillingCost.Location = new System.Drawing.Point(211, 159);
         this.lblFillingCost.Name = "lblFillingCost";
         this.lblFillingCost.Size = new System.Drawing.Size(38, 24);
         this.lblFillingCost.TabIndex = 4;
         this.lblFillingCost.Text = "$150";
         this.lblFillingCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblXRayCost
         // 
         this.lblXRayCost.Location = new System.Drawing.Point(211, 206);
         this.lblXRayCost.Name = "lblXRayCost";
         this.lblXRayCost.Size = new System.Drawing.Size(38, 24);
         this.lblXRayCost.TabIndex = 5;
         this.lblXRayCost.Text = "$85";
         this.lblXRayCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblTotal
         // 
         this.lblTotal.Location = new System.Drawing.Point(144, 256);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(41, 21);
         this.lblTotal.TabIndex = 6;
         this.lblTotal.Text = "Total:";
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotalResult
         // 
         this.lblTotalResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalResult.Location = new System.Drawing.Point(192, 256);
         this.lblTotalResult.Name = "lblTotalResult";
         this.lblTotalResult.Size = new System.Drawing.Size(56, 21);
         this.lblTotalResult.TabIndex = 7;
         this.lblTotalResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(179, 296);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(70, 24);
         this.btnCalculate.TabIndex = 8;
         this.btnCalculate.Text = "Calculate";
         // 
         // FrmDentalPayment
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(272, 336);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblTotalResult);
         this.Controls.Add(this.lblTotal);
         this.Controls.Add(this.lblXRayCost);
         this.Controls.Add(this.lblFillingCost);
         this.Controls.Add(this.lblCleanCost);
         this.Controls.Add(this.txtName);
         this.Controls.Add(this.lblName);
         this.Controls.Add(this.lblTitle);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmDentalPayment";
         this.Text = "DentalPayment";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmDentalPayment() );
      }

   } // end class FrmDentalPayment
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/