using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace OddNumbers
{
   /// <summary>
   /// Summary description for FrmOddNumbers.
   /// </summary>
   public class FrmOddNumbers : System.Windows.Forms.Form
   {
      // Label and TextBox to input upper limit of odd numbers
      private System.Windows.Forms.Label lblLimit;
      private System.Windows.Forms.TextBox txtLimit;

      // Button to view the list of odd numbers
      private System.Windows.Forms.Button btnView;

      // ListBox to list the odd numbers
      private System.Windows.Forms.ListBox lstResults;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmOddNumbers()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblLimit = new System.Windows.Forms.Label();
         this.txtLimit = new System.Windows.Forms.TextBox();
         this.btnView = new System.Windows.Forms.Button();
         this.lstResults = new System.Windows.Forms.ListBox();
         this.SuspendLayout();
         // 
         // lblLimit
         // 
         this.lblLimit.Location = new System.Drawing.Point(16, 8);
         this.lblLimit.Name = "lblLimit";
         this.lblLimit.Size = new System.Drawing.Size(64, 20);
         this.lblLimit.TabIndex = 2;
         this.lblLimit.Text = "Upper limit:";
         this.lblLimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtLimit
         // 
         this.txtLimit.Location = new System.Drawing.Point(88, 8);
         this.txtLimit.Name = "txtLimit";
         this.txtLimit.Size = new System.Drawing.Size(64, 21);
         this.txtLimit.TabIndex = 3;
         this.txtLimit.Text = "";
         this.txtLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnView
         // 
         this.btnView.Location = new System.Drawing.Point(168, 8);
         this.btnView.Name = "btnView";
         this.btnView.TabIndex = 4;
         this.btnView.Text = "View";
         this.btnView.Click += new System.EventHandler(this.btnView_Click);
         // 
         // lstResults
         // 
         this.lstResults.Location = new System.Drawing.Point(16, 40);
         this.lstResults.Name = "lstResults";
         this.lstResults.Size = new System.Drawing.Size(224, 95);
         this.lstResults.TabIndex = 5;
         // 
         // FrmOddNumbers
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(264, 149);
         this.Controls.Add(this.lstResults);
         this.Controls.Add(this.btnView);
         this.Controls.Add(this.txtLimit);
         this.Controls.Add(this.lblLimit);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmOddNumbers";
         this.Text = "Odd Numbers";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmOddNumbers() );
      }

      // handles Click event
      private void btnView_Click( 
         object sender, System.EventArgs e )
      {
         int intLimit = 0; // upper limit set by user
         int intCounter = 1; // counter begins at 1

         lstResults.Items.Clear(); // clear ListBox
         intLimit = 
            Int32.Parse( txtLimit.Text ); // retrieve upper limit
         lstResults.Items.Add( "Odd numbers:" ); // display header

         while ( intCounter < intLimit )
         {
            // determine and display odd numbers
            if ( intCounter % 2 != 0 )
            {
               lstResults.Items.Add( intCounter );
            }

            intLimit++; // increment counter
         }
      
      } // end method btnView_Click

   } // end class FrmOddNumbers
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/