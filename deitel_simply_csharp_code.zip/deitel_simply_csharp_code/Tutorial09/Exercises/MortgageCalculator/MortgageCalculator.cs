using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace MortgageCalculator
{
   /// <summary>
   /// Summary description for FrmMortgageCalculator.
   /// </summary>
   public class FrmMortgageCalculator : System.Windows.Forms.Form
   {
      // Label and TextBox to enter mortgage amount
      private System.Windows.Forms.Label lblMortgageAmount;
      private System.Windows.Forms.TextBox txtMortgageAmount;

      // Label and TextBox to enter interest rate
      private System.Windows.Forms.Label lblInterestRate;
      private System.Windows.Forms.TextBox txtRate;

      // Button to calculate mortgage payments
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmMortgageCalculator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblMortgageAmount = new System.Windows.Forms.Label();
         this.txtMortgageAmount = new System.Windows.Forms.TextBox();
         this.lblInterestRate = new System.Windows.Forms.Label();
         this.txtRate = new System.Windows.Forms.TextBox();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblMortgageAmount
         // 
         this.lblMortgageAmount.Location = new System.Drawing.Point(16, 16);
         this.lblMortgageAmount.Name = "lblMortgageAmount";
         this.lblMortgageAmount.Size = new System.Drawing.Size(104, 21);
         this.lblMortgageAmount.TabIndex = 1;
         this.lblMortgageAmount.Text = "Mortgage amount:";
         this.lblMortgageAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtMortgageAmount
         // 
         this.txtMortgageAmount.Location = new System.Drawing.Point(144, 16);
         this.txtMortgageAmount.Name = "txtMortgageAmount";
         this.txtMortgageAmount.Size = new System.Drawing.Size(56, 21);
         this.txtMortgageAmount.TabIndex = 2;
         this.txtMortgageAmount.Text = "";
         this.txtMortgageAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblInterestRate
         // 
         this.lblInterestRate.Location = new System.Drawing.Point(16, 56);
         this.lblInterestRate.Name = "lblInterestRate";
         this.lblInterestRate.Size = new System.Drawing.Size(112, 21);
         this.lblInterestRate.TabIndex = 3;
         this.lblInterestRate.Text = "Annual interest rate:";
         this.lblInterestRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtRate
         // 
         this.txtRate.Location = new System.Drawing.Point(144, 56);
         this.txtRate.Name = "txtRate";
         this.txtRate.Size = new System.Drawing.Size(56, 21);
         this.txtRate.TabIndex = 4;
         this.txtRate.Text = "";
         this.txtRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(224, 16);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(64, 23);
         this.btnCalculate.TabIndex = 5;
         this.btnCalculate.Text = "Calculate";
         // 
         // FrmMortgageCalculator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(304, 205);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.txtRate);
         this.Controls.Add(this.lblInterestRate);
         this.Controls.Add(this.txtMortgageAmount);
         this.Controls.Add(this.lblMortgageAmount);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmMortgageCalculator";
         this.Text = "MortgageCalculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmMortgageCalculator() );
      }

   } // end class FrmMortgageCalculator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/