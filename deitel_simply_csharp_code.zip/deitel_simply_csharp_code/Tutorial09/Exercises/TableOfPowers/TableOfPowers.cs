using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TableOfPowers
{
   /// <summary>
   /// Summary description for FrmTableOfPowers.
   /// </summary>
   public class FrmTableOfPowers : System.Windows.Forms.Form
   {
      // Label and TextBox to input upper limit of N
      private System.Windows.Forms.Label lblUpperLimit;
      private System.Windows.Forms.TextBox txtInput;

      // Button to compute powers
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmTableOfPowers()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblUpperLimit = new System.Windows.Forms.Label();
         this.txtInput = new System.Windows.Forms.TextBox();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblUpperLimit
         // 
         this.lblUpperLimit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
         this.lblUpperLimit.Location = new System.Drawing.Point(16, 16);
         this.lblUpperLimit.Name = "lblUpperLimit";
         this.lblUpperLimit.Size = new System.Drawing.Size(64, 23);
         this.lblUpperLimit.TabIndex = 3;
         this.lblUpperLimit.Text = "Upper limit:";
         this.lblUpperLimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtInput
         // 
         this.txtInput.Location = new System.Drawing.Point(96, 16);
         this.txtInput.Name = "txtInput";
         this.txtInput.Size = new System.Drawing.Size(48, 21);
         this.txtInput.TabIndex = 4;
         this.txtInput.Text = "";
         this.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(168, 16);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.TabIndex = 5;
         this.btnCalculate.Text = "Calculate";
         // 
         // FrmTableOfPowers
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(256, 165);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.txtInput);
         this.Controls.Add(this.lblUpperLimit);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmTableOfPowers";
         this.Text = "Table of Powers";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmTableOfPowers() );
      }

   } // end class FrmTableOfPowers
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/