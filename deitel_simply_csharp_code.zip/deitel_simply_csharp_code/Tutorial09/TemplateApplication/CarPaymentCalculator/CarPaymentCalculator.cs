using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CarPaymentCalculator
{
   /// <summary>
   /// Summary description for FrmCarPayment.
   /// </summary>
   public class FrmCarPayment : System.Windows.Forms.Form
   {
      // Label and TextBox for sticker price
      private System.Windows.Forms.Label lblStickerPrice;
      private System.Windows.Forms.TextBox txtStickerPrice;

      // Label and TextBox for down payment
      private System.Windows.Forms.Label lblDownPayment;
      private System.Windows.Forms.TextBox txtDownPayment;

      // Label and textbox for interest rate
      private System.Windows.Forms.TextBox txtInterest;
      private System.Windows.Forms.Label lblInterest;

      // Button to calculate total cost
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmCarPayment()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblStickerPrice = new System.Windows.Forms.Label();
         this.lblDownPayment = new System.Windows.Forms.Label();
         this.lblInterest = new System.Windows.Forms.Label();
         this.txtStickerPrice = new System.Windows.Forms.TextBox();
         this.txtDownPayment = new System.Windows.Forms.TextBox();
         this.txtInterest = new System.Windows.Forms.TextBox();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblStickerPrice
         // 
         this.lblStickerPrice.Location = new System.Drawing.Point(40, 24);
         this.lblStickerPrice.Name = "lblStickerPrice";
         this.lblStickerPrice.Size = new System.Drawing.Size(80, 21);
         this.lblStickerPrice.TabIndex = 0;
         this.lblStickerPrice.Text = "Price:";
         this.lblStickerPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblDownPayment
         // 
         this.lblDownPayment.Location = new System.Drawing.Point(40, 56);
         this.lblDownPayment.Name = "lblDownPayment";
         this.lblDownPayment.Size = new System.Drawing.Size(96, 21);
         this.lblDownPayment.TabIndex = 1;
         this.lblDownPayment.Text = "Down payment:";
         this.lblDownPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblInterest
         // 
         this.lblInterest.Location = new System.Drawing.Point(40, 88);
         this.lblInterest.Name = "lblInterest";
         this.lblInterest.Size = new System.Drawing.Size(108, 21);
         this.lblInterest.TabIndex = 2;
         this.lblInterest.Text = "Annual interest rate:";
         this.lblInterest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtStickerPrice
         // 
         this.txtStickerPrice.Location = new System.Drawing.Point(184, 24);
         this.txtStickerPrice.Name = "txtStickerPrice";
         this.txtStickerPrice.Size = new System.Drawing.Size(56, 21);
         this.txtStickerPrice.TabIndex = 3;
         this.txtStickerPrice.Text = "";
         this.txtStickerPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtDownPayment
         // 
         this.txtDownPayment.Location = new System.Drawing.Point(184, 56);
         this.txtDownPayment.Name = "txtDownPayment";
         this.txtDownPayment.Size = new System.Drawing.Size(56, 21);
         this.txtDownPayment.TabIndex = 4;
         this.txtDownPayment.Text = "";
         this.txtDownPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtInterest
         // 
         this.txtInterest.Location = new System.Drawing.Point(184, 88);
         this.txtInterest.Name = "txtInterest";
         this.txtInterest.Size = new System.Drawing.Size(56, 21);
         this.txtInterest.TabIndex = 5;
         this.txtInterest.Text = "";
         this.txtInterest.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(112, 128);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(64, 24);
         this.btnCalculate.TabIndex = 6;
         this.btnCalculate.Text = "Calculate";
         // 
         // FrmCarPayment
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(292, 273);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.txtInterest);
         this.Controls.Add(this.txtDownPayment);
         this.Controls.Add(this.txtStickerPrice);
         this.Controls.Add(this.lblInterest);
         this.Controls.Add(this.lblDownPayment);
         this.Controls.Add(this.lblStickerPrice);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCarPayment";
         this.Text = "Car Payment Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCarPayment() );
      }

   } // end class FrmCarPayment
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
