using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ClassAverage
{
   /// <summary>
   /// Summary description for FrmClassAverage.
   /// </summary>
   public class FrmClassAverage : System.Windows.Forms.Form
   {
      // Label and ListBox to display grades
      private System.Windows.Forms.Label lblGradeList;
      private System.Windows.Forms.ListBox lstGrades;

      // Label, TextBox and Button to add a grade
      private System.Windows.Forms.Label lblPrompt;
      private System.Windows.Forms.TextBox txtInput;
      private System.Windows.Forms.Button btnAdd;

      // Labels to display the average grade
      private System.Windows.Forms.Label lblDescribeOutput;
      private System.Windows.Forms.Label lblOutput;

      // Button to compute the average grade
      private System.Windows.Forms.Button btnAverage;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmClassAverage()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblGradeList = new System.Windows.Forms.Label();
         this.lblPrompt = new System.Windows.Forms.Label();
         this.lblDescribeOutput = new System.Windows.Forms.Label();
         this.lblOutput = new System.Windows.Forms.Label();
         this.lstGrades = new System.Windows.Forms.ListBox();
         this.btnAdd = new System.Windows.Forms.Button();
         this.btnAverage = new System.Windows.Forms.Button();
         this.txtInput = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // lblGradeList
         // 
         this.lblGradeList.Location = new System.Drawing.Point(16, 8);
         this.lblGradeList.Name = "lblGradeList";
         this.lblGradeList.Size = new System.Drawing.Size(56, 23);
         this.lblGradeList.TabIndex = 0;
         this.lblGradeList.Text = "Grade list:";
         this.lblGradeList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPrompt
         // 
         this.lblPrompt.Location = new System.Drawing.Point(128, 8);
         this.lblPrompt.Name = "lblPrompt";
         this.lblPrompt.Size = new System.Drawing.Size(80, 23);
         this.lblPrompt.TabIndex = 1;
         this.lblPrompt.Text = "Enter grade:";
         this.lblPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblDescribeOutput
         // 
         this.lblDescribeOutput.Location = new System.Drawing.Point(128, 112);
         this.lblDescribeOutput.Name = "lblDescribeOutput";
         this.lblDescribeOutput.Size = new System.Drawing.Size(80, 23);
         this.lblDescribeOutput.TabIndex = 2;
         this.lblDescribeOutput.Text = "Class average:";
         this.lblDescribeOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput
         // 
         this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput.Location = new System.Drawing.Point(128, 136);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(72, 21);
         this.lblOutput.TabIndex = 3;
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lstGrades
         // 
         this.lstGrades.Location = new System.Drawing.Point(16, 32);
         this.lstGrades.Name = "lstGrades";
         this.lstGrades.Size = new System.Drawing.Size(88, 160);
         this.lstGrades.TabIndex = 4;
         // 
         // btnAdd
         // 
         this.btnAdd.Location = new System.Drawing.Point(128, 64);
         this.btnAdd.Name = "btnAdd";
         this.btnAdd.Size = new System.Drawing.Size(72, 21);
         this.btnAdd.TabIndex = 5;
         this.btnAdd.Text = "Add Grade";
         this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
         // 
         // btnAverage
         // 
         this.btnAverage.Location = new System.Drawing.Point(128, 168);
         this.btnAverage.Name = "btnAverage";
         this.btnAverage.Size = new System.Drawing.Size(72, 21);
         this.btnAverage.TabIndex = 6;
         this.btnAverage.Text = "Average";
         this.btnAverage.Click += new System.EventHandler(this.btnAverage_Click);
         // 
         // txtInput
         // 
         this.txtInput.Location = new System.Drawing.Point(128, 32);
         this.txtInput.Name = "txtInput";
         this.txtInput.Size = new System.Drawing.Size(72, 21);
         this.txtInput.TabIndex = 7;
         this.txtInput.Text = "";
         this.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // FrmClassAverage
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(216, 205);
         this.Controls.Add(this.txtInput);
         this.Controls.Add(this.btnAverage);
         this.Controls.Add(this.btnAdd);
         this.Controls.Add(this.lstGrades);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.lblDescribeOutput);
         this.Controls.Add(this.lblPrompt);
         this.Controls.Add(this.lblGradeList);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmClassAverage";
         this.Text = "Class Average";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmClassAverage() );
      }

      // handles Add Grade Button's Click event
      private void btnAdd_Click(
         object sender, System.EventArgs e )
      {
         // clear previous grades and calculation result
         if ( lblOutput.Text != "" )
         {
            lblOutput.Text = "";
            lstGrades.Items.Clear();
         }

         // display grade in ListBox
         lstGrades.Items.Add( Int32.Parse( txtInput.Text ) );
         txtInput.Clear(); // clear grade from TextBox
         txtInput.Focus(); // transfer focus to TextBox

         // prohibit users from entering more than 10 grades
         if ( lstGrades.Items.Count == 10 )
         {
            btnAdd.Enabled = false; // disable Add Grade Button
            btnAverage.Focus(); // transfer focus to Average Button
         }

      } // end method btnAdd_Click

      // handles Average Button's Click event
      private void btnAverage_Click(
         object sender, System.EventArgs e )
      {
         // initialization phase
         int intTotal = 0;
         int intGradeCounter = 0;
         int intGrade = 0;
         double dblAverage = 0;

         // sum grades in ListBox
         do
         {
            // read grade from ListBox
            intGrade = ( int )
               lstGrades.Items[ intGradeCounter ];
            intTotal += intGrade; // add grade to total
            intGradeCounter++; // increment counter
         } while ( intGradeCounter < 10 );
      
         dblAverage = intTotal / 10.0; // calculate average
         lblOutput.Text = String.Format( "{0:F}", dblAverage );
         btnAdd.Enabled = true; // enable Add Grade Button
         txtInput.Focus(); // reset focus to Enter grade: TextBox

      } // end method btnAverage_Click

   } // end class FrmClassAverage
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/