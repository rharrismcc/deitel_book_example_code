using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Factorial
{
   /// <summary>
   /// Summary description for FrmFactorial.
   /// </summary>
   public class FrmFactorial : System.Windows.Forms.Form
   {
      // Label and TextBox to enter the number
      private System.Windows.Forms.Label lblNumber;
      private System.Windows.Forms.TextBox txtNumber;

      // Labels to display the factorial of the number
      private System.Windows.Forms.Label lblFactorial;
      private System.Windows.Forms.Label lblResult;
      
      // Button to calculate the factorial
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmFactorial()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblNumber = new System.Windows.Forms.Label();
         this.txtNumber = new System.Windows.Forms.TextBox();
         this.lblFactorial = new System.Windows.Forms.Label();
         this.lblResult = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblNumber
         // 
         this.lblNumber.Location = new System.Drawing.Point(16, 16);
         this.lblNumber.Name = "lblNumber";
         this.lblNumber.Size = new System.Drawing.Size(80, 23);
         this.lblNumber.TabIndex = 3;
         this.lblNumber.Text = "Enter number:";
         this.lblNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtNumber
         // 
         this.txtNumber.Location = new System.Drawing.Point(112, 16);
         this.txtNumber.Name = "txtNumber";
         this.txtNumber.TabIndex = 4;
         this.txtNumber.Text = "";
         this.txtNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblFactorial
         // 
         this.lblFactorial.Location = new System.Drawing.Point(16, 56);
         this.lblFactorial.Name = "lblFactorial";
         this.lblFactorial.Size = new System.Drawing.Size(72, 23);
         this.lblFactorial.TabIndex = 5;
         this.lblFactorial.Text = "Factorial:";
         this.lblFactorial.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblResult
         // 
         this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblResult.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
         this.lblResult.Location = new System.Drawing.Point(112, 56);
         this.lblResult.Name = "lblResult";
         this.lblResult.TabIndex = 6;
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(112, 96);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(104, 23);
         this.btnCalculate.TabIndex = 7;
         this.btnCalculate.Text = "Calculate";
         this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
         // 
         // FrmFactorial
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(232, 133);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.lblFactorial);
         this.Controls.Add(this.txtNumber);
         this.Controls.Add(this.lblNumber);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmFactorial";
         this.Text = "Factorial";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmFactorial() );
      }

      // handles Click event
      private void btnCalculate_Click( 
         object sender, System.EventArgs e )
      {
         int intInput; // user input
         int intFactorial = 1; // holds factorial

         intInput = Int32.Parse( txtNumber.Text ); // get user input

         // loop until intInput equals zero
         do
         {
            intFactorial *= intInput; // calculate factorial
            intInput--; // decrement counter
         } while ( intInput <= 1 ); // test guard condition

         // display factorial
         lblResult.Text = Convert.ToString( intFactorial );
      
      } // end method btnCalculate_Click

   } // end class FrmFactorial
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/