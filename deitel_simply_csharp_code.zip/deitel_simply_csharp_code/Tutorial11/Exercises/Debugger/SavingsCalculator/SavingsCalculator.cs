using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SavingsCalculator
{
   /// <summary>
   /// Summary description for FrmSavingsCalculator.
   /// </summary>
   public class FrmSavingsCalculator : System.Windows.Forms.Form
   {
      // Label and TextBox to input starting amount
      private System.Windows.Forms.Label lblStartingAmount;
      private System.Windows.Forms.TextBox txtStartAmount;

      // Labels display savings after one year
      private System.Windows.Forms.Label lblResult;
      private System.Windows.Forms.Label lblTotal;

      // Button calculates savings after one year
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmSavingsCalculator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblStartingAmount = new System.Windows.Forms.Label();
         this.txtStartAmount = new System.Windows.Forms.TextBox();
         this.lblResult = new System.Windows.Forms.Label();
         this.lblTotal = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblStartingAmount
         // 
         this.lblStartingAmount.Location = new System.Drawing.Point(16, 16);
         this.lblStartingAmount.Name = "lblStartingAmount";
         this.lblStartingAmount.Size = new System.Drawing.Size(104, 23);
         this.lblStartingAmount.TabIndex = 1;
         this.lblStartingAmount.Text = "Starting amount:";
         this.lblStartingAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtStartAmount
         // 
         this.txtStartAmount.Location = new System.Drawing.Point(152, 16);
         this.txtStartAmount.Name = "txtStartAmount";
         this.txtStartAmount.Size = new System.Drawing.Size(80, 21);
         this.txtStartAmount.TabIndex = 5;
         this.txtStartAmount.Text = "";
         this.txtStartAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblResult
         // 
         this.lblResult.Location = new System.Drawing.Point(16, 56);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(128, 23);
         this.lblResult.TabIndex = 6;
         this.lblResult.Text = "Amount after one year:";
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotal
         // 
         this.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotal.Location = new System.Drawing.Point(152, 56);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(80, 23);
         this.lblTotal.TabIndex = 7;
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(160, 96);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(72, 23);
         this.btnCalculate.TabIndex = 8;
         this.btnCalculate.Text = "Calculate";
         this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
         // 
         // FrmSavingsCalculator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(248, 133);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblTotal);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.txtStartAmount);
         this.Controls.Add(this.lblStartingAmount);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmSavingsCalculator";
         this.Text = "Savings Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmSavingsCalculator() );
      }

      // calculate amount in account after one year
      private void btnCalculate_Click( 
         object sender, System.EventArgs e )
      {
         int intTotal = 0; // amount on deposit
         int intCounter = 0; // counter starts at 1

         // get amount on deposit
         intTotal = Int32.Parse( txtStartAmount.Text ); 

         // add $100 a month for one year 
         for ( intCounter = 0; intCounter <= 12;
            intCounter++ )
         {
            intTotal += 100; // add money
         }

         // display total after 12 months
         lblTotal.Text = Convert.ToString( intTotal ); 
      
      } // end method btnCalculate_Click

   } // end class FrmSavingsCalculator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/