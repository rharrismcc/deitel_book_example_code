using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CashRegister
{
   /// <summary>
   /// Summary description for FrmCashRegister.
   /// </summary>
   public class FrmCashRegister : System.Windows.Forms.Form
   {
      // Label and TextBox to display current price
      private System.Windows.Forms.Label lblDollarSign;
      private System.Windows.Forms.TextBox txtCurrentPrice;

      // Buttons to input prices
      private System.Windows.Forms.Button btnOne;
      private System.Windows.Forms.Button btnTwo;
      private System.Windows.Forms.Button btnThree;
      private System.Windows.Forms.Button btnFour;
      private System.Windows.Forms.Button btnFive;
      private System.Windows.Forms.Button btnSix;
      private System.Windows.Forms.Button btnSeven;
      private System.Windows.Forms.Button btnEight;
      private System.Windows.Forms.Button btnNine;
      private System.Windows.Forms.Button btnZero;
      private System.Windows.Forms.Button btnPoint;

      // Buttons to enter a price, calculate the total,
      // clear the price in the TextBox and clear all input,
      // respectively.
      private System.Windows.Forms.Button btnEnter;
      private System.Windows.Forms.Button btnTotal;
      private System.Windows.Forms.Button btnDelete;
      private System.Windows.Forms.Button btnClear;

      // Labels to display the subtotal
      private System.Windows.Forms.Label lblSubtotal;
      private System.Windows.Forms.Label lblSubTotalValue;

      // Labels to display the tax
      private System.Windows.Forms.Label lblTax;
      private System.Windows.Forms.Label lblTaxValue;

      // Labels to display the total price
      private System.Windows.Forms.Label lblTotal;
      private System.Windows.Forms.Label lblTotalValue;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmCashRegister()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblDollarSign = new System.Windows.Forms.Label();
         this.txtCurrentPrice = new System.Windows.Forms.TextBox();
         this.btnOne = new System.Windows.Forms.Button();
         this.btnTwo = new System.Windows.Forms.Button();
         this.btnThree = new System.Windows.Forms.Button();
         this.btnFour = new System.Windows.Forms.Button();
         this.btnFive = new System.Windows.Forms.Button();
         this.btnSix = new System.Windows.Forms.Button();
         this.btnSeven = new System.Windows.Forms.Button();
         this.btnEight = new System.Windows.Forms.Button();
         this.btnNine = new System.Windows.Forms.Button();
         this.btnZero = new System.Windows.Forms.Button();
         this.btnPoint = new System.Windows.Forms.Button();
         this.btnEnter = new System.Windows.Forms.Button();
         this.btnTotal = new System.Windows.Forms.Button();
         this.btnDelete = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.lblSubtotal = new System.Windows.Forms.Label();
         this.lblSubTotalValue = new System.Windows.Forms.Label();
         this.lblTax = new System.Windows.Forms.Label();
         this.lblTaxValue = new System.Windows.Forms.Label();
         this.lblTotal = new System.Windows.Forms.Label();
         this.lblTotalValue = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // lblDollarSign
         // 
         this.lblDollarSign.Location = new System.Drawing.Point(16, 16);
         this.lblDollarSign.Name = "lblDollarSign";
         this.lblDollarSign.Size = new System.Drawing.Size(8, 21);
         this.lblDollarSign.TabIndex = 55;
         this.lblDollarSign.Text = "$";
         this.lblDollarSign.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtCurrentPrice
         // 
         this.txtCurrentPrice.Location = new System.Drawing.Point(24, 16);
         this.txtCurrentPrice.Name = "txtCurrentPrice";
         this.txtCurrentPrice.ReadOnly = true;
         this.txtCurrentPrice.Size = new System.Drawing.Size(168, 21);
         this.txtCurrentPrice.TabIndex = 57;
         this.txtCurrentPrice.Text = "";
         // 
         // btnOne
         // 
         this.btnOne.Location = new System.Drawing.Point(32, 56);
         this.btnOne.Name = "btnOne";
         this.btnOne.Size = new System.Drawing.Size(24, 24);
         this.btnOne.TabIndex = 58;
         this.btnOne.Text = "1";
         // 
         // btnTwo
         // 
         this.btnTwo.Location = new System.Drawing.Point(56, 56);
         this.btnTwo.Name = "btnTwo";
         this.btnTwo.Size = new System.Drawing.Size(24, 24);
         this.btnTwo.TabIndex = 59;
         this.btnTwo.Text = "2";
         // 
         // btnThree
         // 
         this.btnThree.Location = new System.Drawing.Point(80, 56);
         this.btnThree.Name = "btnThree";
         this.btnThree.Size = new System.Drawing.Size(24, 24);
         this.btnThree.TabIndex = 60;
         this.btnThree.Text = "3";
         // 
         // btnFour
         // 
         this.btnFour.Location = new System.Drawing.Point(32, 80);
         this.btnFour.Name = "btnFour";
         this.btnFour.Size = new System.Drawing.Size(24, 24);
         this.btnFour.TabIndex = 61;
         this.btnFour.Text = "4";
         // 
         // btnFive
         // 
         this.btnFive.Location = new System.Drawing.Point(56, 80);
         this.btnFive.Name = "btnFive";
         this.btnFive.Size = new System.Drawing.Size(24, 24);
         this.btnFive.TabIndex = 62;
         this.btnFive.Text = "5";
         // 
         // btnSix
         // 
         this.btnSix.Location = new System.Drawing.Point(80, 80);
         this.btnSix.Name = "btnSix";
         this.btnSix.Size = new System.Drawing.Size(24, 24);
         this.btnSix.TabIndex = 63;
         this.btnSix.Text = "6";
         // 
         // btnSeven
         // 
         this.btnSeven.Location = new System.Drawing.Point(32, 104);
         this.btnSeven.Name = "btnSeven";
         this.btnSeven.Size = new System.Drawing.Size(24, 24);
         this.btnSeven.TabIndex = 64;
         this.btnSeven.Text = "7";
         // 
         // btnEight
         // 
         this.btnEight.Location = new System.Drawing.Point(56, 104);
         this.btnEight.Name = "btnEight";
         this.btnEight.Size = new System.Drawing.Size(24, 24);
         this.btnEight.TabIndex = 65;
         this.btnEight.Text = "8";
         // 
         // btnNine
         // 
         this.btnNine.Location = new System.Drawing.Point(80, 104);
         this.btnNine.Name = "btnNine";
         this.btnNine.Size = new System.Drawing.Size(24, 24);
         this.btnNine.TabIndex = 66;
         this.btnNine.Text = "9";
         // 
         // btnZero
         // 
         this.btnZero.Location = new System.Drawing.Point(56, 128);
         this.btnZero.Name = "btnZero";
         this.btnZero.Size = new System.Drawing.Size(24, 24);
         this.btnZero.TabIndex = 67;
         this.btnZero.Text = "0";
         // 
         // btnPoint
         // 
         this.btnPoint.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnPoint.Location = new System.Drawing.Point(80, 128);
         this.btnPoint.Name = "btnPoint";
         this.btnPoint.Size = new System.Drawing.Size(24, 24);
         this.btnPoint.TabIndex = 68;
         this.btnPoint.Text = ".";
         // 
         // btnEnter
         // 
         this.btnEnter.Location = new System.Drawing.Point(120, 56);
         this.btnEnter.Name = "btnEnter";
         this.btnEnter.Size = new System.Drawing.Size(48, 24);
         this.btnEnter.TabIndex = 69;
         this.btnEnter.Text = "Enter";
         // 
         // btnTotal
         // 
         this.btnTotal.Location = new System.Drawing.Point(120, 80);
         this.btnTotal.Name = "btnTotal";
         this.btnTotal.Size = new System.Drawing.Size(48, 24);
         this.btnTotal.TabIndex = 70;
         this.btnTotal.Text = "Total";
         // 
         // btnDelete
         // 
         this.btnDelete.Location = new System.Drawing.Point(120, 104);
         this.btnDelete.Name = "btnDelete";
         this.btnDelete.Size = new System.Drawing.Size(48, 24);
         this.btnDelete.TabIndex = 71;
         this.btnDelete.Text = "Delete";
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(120, 128);
         this.btnClear.Name = "btnClear";
         this.btnClear.Size = new System.Drawing.Size(48, 24);
         this.btnClear.TabIndex = 72;
         this.btnClear.Text = "Clear";
         // 
         // lblSubtotal
         // 
         this.lblSubtotal.Location = new System.Drawing.Point(16, 176);
         this.lblSubtotal.Name = "lblSubtotal";
         this.lblSubtotal.Size = new System.Drawing.Size(56, 23);
         this.lblSubtotal.TabIndex = 73;
         this.lblSubtotal.Text = "Subtotal:";
         this.lblSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblSubTotalValue
         // 
         this.lblSubTotalValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblSubTotalValue.Location = new System.Drawing.Point(88, 176);
         this.lblSubTotalValue.Name = "lblSubTotalValue";
         this.lblSubTotalValue.TabIndex = 74;
         this.lblSubTotalValue.Text = "$0.00";
         this.lblSubTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblTax
         // 
         this.lblTax.Location = new System.Drawing.Point(16, 216);
         this.lblTax.Name = "lblTax";
         this.lblTax.Size = new System.Drawing.Size(56, 23);
         this.lblTax.TabIndex = 75;
         this.lblTax.Text = "Tax:";
         this.lblTax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTaxValue
         // 
         this.lblTaxValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTaxValue.Location = new System.Drawing.Point(88, 216);
         this.lblTaxValue.Name = "lblTaxValue";
         this.lblTaxValue.TabIndex = 76;
         this.lblTaxValue.Text = "$0.00";
         this.lblTaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblTotal
         // 
         this.lblTotal.Location = new System.Drawing.Point(16, 256);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(56, 23);
         this.lblTotal.TabIndex = 77;
         this.lblTotal.Text = "Total:";
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotalValue
         // 
         this.lblTotalValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalValue.Location = new System.Drawing.Point(88, 256);
         this.lblTotalValue.Name = "lblTotalValue";
         this.lblTotalValue.TabIndex = 78;
         this.lblTotalValue.Text = "$0.00";
         this.lblTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // FrmCashRegister
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(208, 293);
         this.Controls.Add(this.lblTotalValue);
         this.Controls.Add(this.lblTotal);
         this.Controls.Add(this.lblTaxValue);
         this.Controls.Add(this.lblTax);
         this.Controls.Add(this.lblSubTotalValue);
         this.Controls.Add(this.lblSubtotal);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.btnDelete);
         this.Controls.Add(this.btnTotal);
         this.Controls.Add(this.btnEnter);
         this.Controls.Add(this.btnPoint);
         this.Controls.Add(this.btnZero);
         this.Controls.Add(this.btnNine);
         this.Controls.Add(this.btnEight);
         this.Controls.Add(this.btnSeven);
         this.Controls.Add(this.btnSix);
         this.Controls.Add(this.btnFive);
         this.Controls.Add(this.btnFour);
         this.Controls.Add(this.btnThree);
         this.Controls.Add(this.btnTwo);
         this.Controls.Add(this.btnOne);
         this.Controls.Add(this.txtCurrentPrice);
         this.Controls.Add(this.lblDollarSign);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCashRegister";
         this.Text = "Cash Register";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCashRegister() );
      }

   } // end class FrmCashRegister
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/