using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DiscountCalculator
{
   /// <summary>
   /// Summary description for FrmDiscountCalculator.
   /// </summary>
   public class FrmDiscountCalculator : System.Windows.Forms.Form
   {
      // Label and TextBox to input amount spent
      private System.Windows.Forms.Label lblAmount;
      private System.Windows.Forms.TextBox txtAmount;

      // Button to view discount
      private System.Windows.Forms.Button btnView;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmDiscountCalculator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblAmount = new System.Windows.Forms.Label();
         this.txtAmount = new System.Windows.Forms.TextBox();
         this.btnView = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblAmount
         // 
         this.lblAmount.Location = new System.Drawing.Point(16, 16);
         this.lblAmount.Name = "lblAmount";
         this.lblAmount.Size = new System.Drawing.Size(112, 20);
         this.lblAmount.TabIndex = 2;
         this.lblAmount.Text = "Enter amount spent:";
         this.lblAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtAmount
         // 
         this.txtAmount.Location = new System.Drawing.Point(136, 16);
         this.txtAmount.Name = "txtAmount";
         this.txtAmount.Size = new System.Drawing.Size(88, 21);
         this.txtAmount.TabIndex = 3;
         this.txtAmount.Text = "0";
         this.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnView
         // 
         this.btnView.Location = new System.Drawing.Point(136, 48);
         this.btnView.Name = "btnView";
         this.btnView.Size = new System.Drawing.Size(88, 23);
         this.btnView.TabIndex = 4;
         this.btnView.Text = "View Discount";
         this.btnView.Click += new System.EventHandler(this.btnView_Click);
         // 
         // FrmDiscountCalculator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(240, 85);
         this.Controls.Add(this.btnView);
         this.Controls.Add(this.txtAmount);
         this.Controls.Add(this.lblAmount);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmDiscountCalculator";
         this.Text = "Discount Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmDiscountCalculator() );
      }

      // handles View Button's Click event
      private void btnView_Click( 
         object sender, System.EventArgs e )
      {
         int intTotal; // amount spent
         string strDiscount; // discount rate

         intTotal = Int32.Parse( txtAmount.Text ); // get total

         switch ( intTotal / 50 )
         {
            // values in the range $0-49
            case 0: 
               strDiscount = "0";
               break;

            // values in the range $100-149
            case 2:
               strDiscount = "10";
               break;

            // values $150 or greater
            default:
               strDiscount = "15";
               break;

         } // end switch

         // display discount to user
         MessageBox.Show( "Your discount is: " + strDiscount + "%",
            "Discount", MessageBoxButtons.OK,
            MessageBoxIcon.Information );
      
      } // end method btnView_Click

   } // end class FrmDiscountCalculator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/