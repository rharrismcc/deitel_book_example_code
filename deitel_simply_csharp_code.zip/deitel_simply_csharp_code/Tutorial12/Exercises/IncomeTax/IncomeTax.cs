using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace IncomeTax
{
   /// <summary>
   /// Summary description for FrmIncomeTax.
   /// </summary>
   public class FrmIncomeTax : System.Windows.Forms.Form
   {
      // Label and TextBox to input yearly salary
      private System.Windows.Forms.Label lblSalary;
      private System.Windows.Forms.TextBox txtSalary;
      
      // Labels to display income tax
      private System.Windows.Forms.Label lblIncomeTax;
      private System.Windows.Forms.Label lblResult;

      // Button to calculate income tax
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmIncomeTax()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblSalary = new System.Windows.Forms.Label();
         this.txtSalary = new System.Windows.Forms.TextBox();
         this.lblIncomeTax = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.lblResult = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // lblSalary
         // 
         this.lblSalary.Location = new System.Drawing.Point(16, 16);
         this.lblSalary.Name = "lblSalary";
         this.lblSalary.Size = new System.Drawing.Size(72, 21);
         this.lblSalary.TabIndex = 1;
         this.lblSalary.Text = "Yearly salary:";
         this.lblSalary.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtSalary
         // 
         this.txtSalary.Location = new System.Drawing.Point(104, 16);
         this.txtSalary.Name = "txtSalary";
         this.txtSalary.Size = new System.Drawing.Size(96, 21);
         this.txtSalary.TabIndex = 2;
         this.txtSalary.Text = "";
         this.txtSalary.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblIncomeTax
         // 
         this.lblIncomeTax.Location = new System.Drawing.Point(16, 56);
         this.lblIncomeTax.Name = "lblIncomeTax";
         this.lblIncomeTax.Size = new System.Drawing.Size(72, 23);
         this.lblIncomeTax.TabIndex = 4;
         this.lblIncomeTax.Text = "Income Tax:";
         this.lblIncomeTax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(104, 96);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(96, 23);
         this.btnCalculate.TabIndex = 5;
         this.btnCalculate.Text = "Calculate";
         // 
         // lblResult
         // 
         this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblResult.Location = new System.Drawing.Point(104, 56);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(96, 23);
         this.lblResult.TabIndex = 6;
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // FrmIncomeTax
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(216, 133);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblIncomeTax);
         this.Controls.Add(this.txtSalary);
         this.Controls.Add(this.lblSalary);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmIncomeTax";
         this.Text = "Income Tax Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmIncomeTax() );
      }

   } // end class FrmIncomeTax
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/