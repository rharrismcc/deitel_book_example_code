using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SalesCommissionCalculator
{
   /// <summary>
   /// Summary description for FrmSalesCommission.
   /// </summary>
   public class FrmSalesCommission : System.Windows.Forms.Form
   {
      // Label and TextBox to input number of items sold
      private System.Windows.Forms.Label lblItemsSold;
      private System.Windows.Forms.TextBox txtItemsSold;

      // Labels to display gross sales
      private System.Windows.Forms.Label lblGrossSales;
      private System.Windows.Forms.Label lblGrossSalesResult;

      // Labels to display commission percentage
      private System.Windows.Forms.Label lblCommissionPercentage;
      private System.Windows.Forms.Label 
         lblCommissionPercentageResult;

      // Labels to display earnings
      private System.Windows.Forms.Label lblEarnings;
      private System.Windows.Forms.Label lblEarningsResult;

      // Button to perform calculations
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmSalesCommission()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.txtItemsSold = new System.Windows.Forms.TextBox();
         this.lblItemsSold = new System.Windows.Forms.Label();
         this.lblGrossSales = new System.Windows.Forms.Label();
         this.lblGrossSalesResult = new System.Windows.Forms.Label();
         this.lblCommissionPercentage = new System.Windows.Forms.Label();
         this.lblCommissionPercentageResult = new System.Windows.Forms.Label();
         this.lblEarnings = new System.Windows.Forms.Label();
         this.lblEarningsResult = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // txtItemsSold
         // 
         this.txtItemsSold.Location = new System.Drawing.Point(144, 16);
         this.txtItemsSold.Name = "txtItemsSold";
         this.txtItemsSold.Size = new System.Drawing.Size(75, 21);
         this.txtItemsSold.TabIndex = 2;
         this.txtItemsSold.Text = "";
         this.txtItemsSold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblItemsSold
         // 
         this.lblItemsSold.Location = new System.Drawing.Point(16, 16);
         this.lblItemsSold.Name = "lblItemsSold";
         this.lblItemsSold.Size = new System.Drawing.Size(120, 20);
         this.lblItemsSold.TabIndex = 3;
         this.lblItemsSold.Text = "Number of items sold:";
         this.lblItemsSold.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblGrossSales
         // 
         this.lblGrossSales.Location = new System.Drawing.Point(16, 64);
         this.lblGrossSales.Name = "lblGrossSales";
         this.lblGrossSales.Size = new System.Drawing.Size(72, 23);
         this.lblGrossSales.TabIndex = 4;
         this.lblGrossSales.Text = "Gross sales:";
         this.lblGrossSales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblGrossSalesResult
         // 
         this.lblGrossSalesResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblGrossSalesResult.Location = new System.Drawing.Point(144, 64);
         this.lblGrossSalesResult.Name = "lblGrossSalesResult";
         this.lblGrossSalesResult.Size = new System.Drawing.Size(75, 23);
         this.lblGrossSalesResult.TabIndex = 5;
         this.lblGrossSalesResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblCommissionPercentage
         // 
         this.lblCommissionPercentage.Location = new System.Drawing.Point(16, 104);
         this.lblCommissionPercentage.Name = "lblCommissionPercentage";
         this.lblCommissionPercentage.Size = new System.Drawing.Size(96, 23);
         this.lblCommissionPercentage.TabIndex = 6;
         this.lblCommissionPercentage.Text = "Commission (%):";
         this.lblCommissionPercentage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblCommissionPercentageResult
         // 
         this.lblCommissionPercentageResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblCommissionPercentageResult.Location = new System.Drawing.Point(144, 104);
         this.lblCommissionPercentageResult.Name = "lblCommissionPercentageResult";
         this.lblCommissionPercentageResult.Size = new System.Drawing.Size(75, 23);
         this.lblCommissionPercentageResult.TabIndex = 7;
         this.lblCommissionPercentageResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblEarnings
         // 
         this.lblEarnings.Location = new System.Drawing.Point(16, 144);
         this.lblEarnings.Name = "lblEarnings";
         this.lblEarnings.Size = new System.Drawing.Size(56, 23);
         this.lblEarnings.TabIndex = 8;
         this.lblEarnings.Text = "Earnings:";
         this.lblEarnings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblEarningsResult
         // 
         this.lblEarningsResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblEarningsResult.Location = new System.Drawing.Point(144, 144);
         this.lblEarningsResult.Name = "lblEarningsResult";
         this.lblEarningsResult.Size = new System.Drawing.Size(75, 23);
         this.lblEarningsResult.TabIndex = 9;
         this.lblEarningsResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(144, 184);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.TabIndex = 10;
         this.btnCalculate.Text = "Calculate";
         // 
         // FrmSalesCommission
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(240, 221);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblEarningsResult);
         this.Controls.Add(this.lblEarnings);
         this.Controls.Add(this.lblCommissionPercentageResult);
         this.Controls.Add(this.lblCommissionPercentage);
         this.Controls.Add(this.lblGrossSalesResult);
         this.Controls.Add(this.lblGrossSales);
         this.Controls.Add(this.lblItemsSold);
         this.Controls.Add(this.txtItemsSold);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmSalesCommission";
         this.Text = "Sales Commission Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmSalesCommission() );
      }

   } // end class FrmSalesCommission
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/