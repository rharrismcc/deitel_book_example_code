using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace GasPump
{
   /// <summary>
   /// Summary description for FrmGasPump.
   /// </summary>
   public class FrmGasPump : System.Windows.Forms.Form
   {
      // Label and TextBox to input number of gallons
      private System.Windows.Forms.Label lblNumberGallons;
      private System.Windows.Forms.TextBox txtNumberGallons;

      // Labels to display total cost
      private System.Windows.Forms.Label lblTotal;
      private System.Windows.Forms.Label lblTotalResult;

      // Buttons to choose regular, special or super+ gas
      private System.Windows.Forms.Button btnRegular;
      private System.Windows.Forms.Button btnSpecial;
      private System.Windows.Forms.Button btnSuper;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmGasPump()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblNumberGallons = new System.Windows.Forms.Label();
         this.txtNumberGallons = new System.Windows.Forms.TextBox();
         this.lblTotal = new System.Windows.Forms.Label();
         this.lblTotalResult = new System.Windows.Forms.Label();
         this.btnRegular = new System.Windows.Forms.Button();
         this.btnSpecial = new System.Windows.Forms.Button();
         this.btnSuper = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblNumberGallons
         // 
         this.lblNumberGallons.Location = new System.Drawing.Point(16, 16);
         this.lblNumberGallons.Name = "lblNumberGallons";
         this.lblNumberGallons.Size = new System.Drawing.Size(104, 21);
         this.lblNumberGallons.TabIndex = 23;
         this.lblNumberGallons.Text = "Number of gallons:";
         this.lblNumberGallons.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtNumberGallons
         // 
         this.txtNumberGallons.Location = new System.Drawing.Point(128, 16);
         this.txtNumberGallons.Name = "txtNumberGallons";
         this.txtNumberGallons.Size = new System.Drawing.Size(96, 21);
         this.txtNumberGallons.TabIndex = 24;
         this.txtNumberGallons.Text = "";
         this.txtNumberGallons.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblTotal
         // 
         this.lblTotal.Location = new System.Drawing.Point(240, 16);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(40, 21);
         this.lblTotal.TabIndex = 25;
         this.lblTotal.Text = "Total:";
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotalResult
         // 
         this.lblTotalResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalResult.Location = new System.Drawing.Point(288, 16);
         this.lblTotalResult.Name = "lblTotalResult";
         this.lblTotalResult.Size = new System.Drawing.Size(56, 21);
         this.lblTotalResult.TabIndex = 26;
         this.lblTotalResult.Text = "0";
         this.lblTotalResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnRegular
         // 
         this.btnRegular.Location = new System.Drawing.Point(16, 56);
         this.btnRegular.Name = "btnRegular";
         this.btnRegular.Size = new System.Drawing.Size(75, 75);
         this.btnRegular.TabIndex = 27;
         this.btnRegular.Text = "Regular";
         this.btnRegular.Click += new System.EventHandler(this.btnRegular_Click);
         // 
         // btnSpecial
         // 
         this.btnSpecial.Location = new System.Drawing.Point(144, 56);
         this.btnSpecial.Name = "btnSpecial";
         this.btnSpecial.Size = new System.Drawing.Size(75, 75);
         this.btnSpecial.TabIndex = 28;
         this.btnSpecial.Text = "Special";
         this.btnSpecial.Click += new System.EventHandler(this.btnSpecial_Click);
         // 
         // btnSuper
         // 
         this.btnSuper.Location = new System.Drawing.Point(272, 56);
         this.btnSuper.Name = "btnSuper";
         this.btnSuper.Size = new System.Drawing.Size(75, 75);
         this.btnSuper.TabIndex = 29;
         this.btnSuper.Text = "Super+";
         this.btnSuper.Click += new System.EventHandler(this.btnSuper_Click);
         // 
         // FrmGasPump
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(368, 149);
         this.Controls.Add(this.btnSuper);
         this.Controls.Add(this.btnSpecial);
         this.Controls.Add(this.btnRegular);
         this.Controls.Add(this.lblTotalResult);
         this.Controls.Add(this.lblTotal);
         this.Controls.Add(this.txtNumberGallons);
         this.Controls.Add(this.lblNumberGallons);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmGasPump";
         this.Text = "Gas Pump";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmGasPump() );
      }

      // handles Regular Button's Click Event
      private void btnRegular_Click( 
         object sender, System.EventArgs e )
      {
         int intGallons; // number of gallons

         intGallons = Int32.Parse( txtNumberGallons.Text );

         // call method to determine total
         Total( btnRegular.Text, intGallons );
      
      } // end method btnRegular_Click

      // handles Special Button's Click Event
      private void btnSpecial_Click( 
         object sender, System.EventArgs e )
      {
         int intGallons; // number of gallons

         intGallons = Int32.Parse( txtNumberGallons.Text );

         // call method to determine total
         Total( btnSpecial.Text, intGallons );
       
      } // end method btnSpecial_Click

      // handles Super+ Button's Click Event
      private void btnSuper_Click( 
         object sender, System.EventArgs e )
      {
         int intGallons; // number of gallons

         intGallons = Int32.Parse( txtNumberGallons.Text );

         // call method to determine total
         Total( btnSuper.Text, intGallons );
            
      } // end method btnSuper_Click

      void Total( string strGrade, int intGallons )
      {
         // determine grade selected and output total
         switch ( strGrade )
         {
            case "Regular":
               lblTotalResult.Text =
                  String.Format( "{0:C}", 1.41 * intGallons );
               break;

            case "Special":
               lblTotalResult.Text =
                  String.Format( "{0:C}", 1.91 * intGallons );
               break;

            case "Super+":
               lblTotalResult.Text =
                  String.Format( "{0:C}", 1.57 * intGallons );
               break;
         }

      } // end method Total

   } // end class FrmGasPump
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/