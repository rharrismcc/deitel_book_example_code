using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DisplaySquare
{
   /// <summary>
   /// Summary description for FrmDisplaySquare.
   /// </summary>
   public class FrmDisplaySquare : System.Windows.Forms.Form
   {
      // Label and TextBox to input size of side
      private System.Windows.Forms.Label lblSideSize;
      private System.Windows.Forms.TextBox txtSideSize;

      // Label and TextBox to input character to fill square with
      private System.Windows.Forms.Label lblFillCharacter;
      private System.Windows.Forms.TextBox txtFillCharacter;

      // Button to display the square
      private System.Windows.Forms.Button btnDisplaySquare;

      // TextBox to display the square
      private System.Windows.Forms.TextBox txtOutput;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmDisplaySquare()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblSideSize = new System.Windows.Forms.Label();
         this.txtSideSize = new System.Windows.Forms.TextBox();
         this.lblFillCharacter = new System.Windows.Forms.Label();
         this.txtFillCharacter = new System.Windows.Forms.TextBox();
         this.btnDisplaySquare = new System.Windows.Forms.Button();
         this.txtOutput = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // lblSideSize
         // 
         this.lblSideSize.Location = new System.Drawing.Point(16, 16);
         this.lblSideSize.Name = "lblSideSize";
         this.lblSideSize.Size = new System.Drawing.Size(80, 21);
         this.lblSideSize.TabIndex = 1;
         this.lblSideSize.Text = "Square size:";
         this.lblSideSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtSideSize
         // 
         this.txtSideSize.Location = new System.Drawing.Point(104, 16);
         this.txtSideSize.MaxLength = 2;
         this.txtSideSize.Name = "txtSideSize";
         this.txtSideSize.Size = new System.Drawing.Size(24, 21);
         this.txtSideSize.TabIndex = 3;
         this.txtSideSize.Text = "";
         this.txtSideSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblFillCharacter
         // 
         this.lblFillCharacter.Location = new System.Drawing.Point(16, 56);
         this.lblFillCharacter.Name = "lblFillCharacter";
         this.lblFillCharacter.Size = new System.Drawing.Size(80, 21);
         this.lblFillCharacter.TabIndex = 4;
         this.lblFillCharacter.Text = "Fill character:";
         this.lblFillCharacter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtFillCharacter
         // 
         this.txtFillCharacter.Location = new System.Drawing.Point(104, 56);
         this.txtFillCharacter.MaxLength = 1;
         this.txtFillCharacter.Name = "txtFillCharacter";
         this.txtFillCharacter.Size = new System.Drawing.Size(24, 21);
         this.txtFillCharacter.TabIndex = 5;
         this.txtFillCharacter.Text = "";
         this.txtFillCharacter.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnDisplaySquare
         // 
         this.btnDisplaySquare.Location = new System.Drawing.Point(144, 16);
         this.btnDisplaySquare.Name = "btnDisplaySquare";
         this.btnDisplaySquare.Size = new System.Drawing.Size(104, 23);
         this.btnDisplaySquare.TabIndex = 6;
         this.btnDisplaySquare.Text = "Display Square";
         // 
         // txtOutput
         // 
         this.txtOutput.Location = new System.Drawing.Point(16, 96);
         this.txtOutput.Multiline = true;
         this.txtOutput.Name = "txtOutput";
         this.txtOutput.ReadOnly = true;
         this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
         this.txtOutput.Size = new System.Drawing.Size(228, 136);
         this.txtOutput.TabIndex = 7;
         this.txtOutput.Text = "";
         // 
         // FrmDisplaySquare
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(264, 245);
         this.Controls.Add(this.txtOutput);
         this.Controls.Add(this.btnDisplaySquare);
         this.Controls.Add(this.txtFillCharacter);
         this.Controls.Add(this.lblFillCharacter);
         this.Controls.Add(this.txtSideSize);
         this.Controls.Add(this.lblSideSize);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmDisplaySquare";
         this.Text = "Display Square";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmDisplaySquare() );
      }

   } // end class FrmDisplaySquare
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
