using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TemperatureConversion
{
   /// <summary>
   /// Summary description for FrmTemperatureConversion.
   /// </summary>
   public class FrmTemperatureConversion : System.Windows.Forms.Form
   {
      // Label and TextBox to input degrees
      private System.Windows.Forms.Label lblDegrees;
      private System.Windows.Forms.TextBox txtDegrees;

      // Label to output converted degrees
      private System.Windows.Forms.Label lblOutput;

      // Button to convert to degrees Fahrenheit
      private System.Windows.Forms.Button btnConvertFahrenheit;

      // Button to convert to degrees Celsius
      private System.Windows.Forms.Button btnConvertCelsius;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmTemperatureConversion()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblDegrees = new System.Windows.Forms.Label();
         this.txtDegrees = new System.Windows.Forms.TextBox();
         this.lblOutput = new System.Windows.Forms.Label();
         this.btnConvertFahrenheit = new System.Windows.Forms.Button();
         this.btnConvertCelsius = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblDegrees
         // 
         this.lblDegrees.Location = new System.Drawing.Point(16, 16);
         this.lblDegrees.Name = "lblDegrees";
         this.lblDegrees.Size = new System.Drawing.Size(56, 21);
         this.lblDegrees.TabIndex = 12;
         this.lblDegrees.Text = "Degrees:";
         this.lblDegrees.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtDegrees
         // 
         this.txtDegrees.Location = new System.Drawing.Point(136, 16);
         this.txtDegrees.Name = "txtDegrees";
         this.txtDegrees.Size = new System.Drawing.Size(64, 21);
         this.txtDegrees.TabIndex = 13;
         this.txtDegrees.Text = "";
         this.txtDegrees.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblOutput
         // 
         this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput.Location = new System.Drawing.Point(16, 56);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(184, 32);
         this.lblOutput.TabIndex = 14;
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnConvertFahrenheit
         // 
         this.btnConvertFahrenheit.Location = new System.Drawing.Point(16, 104);
         this.btnConvertFahrenheit.Name = "btnConvertFahrenheit";
         this.btnConvertFahrenheit.Size = new System.Drawing.Size(72, 40);
         this.btnConvertFahrenheit.TabIndex = 15;
         this.btnConvertFahrenheit.Text = "Convert To Fahrenheit";
         // 
         // btnConvertCelsius
         // 
         this.btnConvertCelsius.Location = new System.Drawing.Point(128, 104);
         this.btnConvertCelsius.Name = "btnConvertCelsius";
         this.btnConvertCelsius.Size = new System.Drawing.Size(72, 40);
         this.btnConvertCelsius.TabIndex = 16;
         this.btnConvertCelsius.Text = "Convert To Celsius";
         // 
         // FrmTemperatureConversion
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(216, 157);
         this.Controls.Add(this.btnConvertCelsius);
         this.Controls.Add(this.btnConvertFahrenheit);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.txtDegrees);
         this.Controls.Add(this.lblDegrees);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmTemperatureConversion";
         this.Text = "Temperature Converter";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmTemperatureConversion() );
      }

   } // end class FrmTemperatureConversion
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/