using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Maximum
{
   /// <summary>
   /// Summary description for FrmMaximum.
   /// </summary>
   public class FrmMaximum : System.Windows.Forms.Form
   {
      // Labels and TextBoxes to input the three values
      private System.Windows.Forms.Label lblFirst;
      private System.Windows.Forms.TextBox txtFirst;

      private System.Windows.Forms.Label lblSecond;
      private System.Windows.Forms.TextBox txtSecond;

      private System.Windows.Forms.Label lblThird;
      private System.Windows.Forms.TextBox txtThird;

      // Labels to display the maximum value
      private System.Windows.Forms.Label lblMaximum;
      private System.Windows.Forms.Label lblOutput;

      // Button to calculate the maximum value
      private System.Windows.Forms.Button btnMaximum;
		
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmMaximum()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblFirst = new System.Windows.Forms.Label();
         this.lblSecond = new System.Windows.Forms.Label();
         this.lblThird = new System.Windows.Forms.Label();
         this.lblMaximum = new System.Windows.Forms.Label();
         this.lblOutput = new System.Windows.Forms.Label();
         this.txtFirst = new System.Windows.Forms.TextBox();
         this.txtSecond = new System.Windows.Forms.TextBox();
         this.txtThird = new System.Windows.Forms.TextBox();
         this.btnMaximum = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblFirst
         // 
         this.lblFirst.Location = new System.Drawing.Point(16, 16);
         this.lblFirst.Name = "lblFirst";
         this.lblFirst.Size = new System.Drawing.Size(100, 24);
         this.lblFirst.TabIndex = 0;
         this.lblFirst.Text = "Enter first value:";
         this.lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblSecond
         // 
         this.lblSecond.Location = new System.Drawing.Point(16, 56);
         this.lblSecond.Name = "lblSecond";
         this.lblSecond.Size = new System.Drawing.Size(120, 24);
         this.lblSecond.TabIndex = 1;
         this.lblSecond.Text = "Enter second value:";
         this.lblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblThird
         // 
         this.lblThird.Location = new System.Drawing.Point(16, 96);
         this.lblThird.Name = "lblThird";
         this.lblThird.Size = new System.Drawing.Size(120, 24);
         this.lblThird.TabIndex = 2;
         this.lblThird.Text = "Enter third value:";
         this.lblThird.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblMaximum
         // 
         this.lblMaximum.Location = new System.Drawing.Point(16, 152);
         this.lblMaximum.Name = "lblMaximum";
         this.lblMaximum.Size = new System.Drawing.Size(100, 24);
         this.lblMaximum.TabIndex = 3;
         this.lblMaximum.Text = "Maximum:";
         this.lblMaximum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput
         // 
         this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput.Location = new System.Drawing.Point(144, 152);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(80, 24);
         this.lblOutput.TabIndex = 4;
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // txtFirst
         // 
         this.txtFirst.Location = new System.Drawing.Point(144, 16);
         this.txtFirst.Name = "txtFirst";
         this.txtFirst.Size = new System.Drawing.Size(80, 21);
         this.txtFirst.TabIndex = 5;
         this.txtFirst.Text = "";
         this.txtFirst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtSecond
         // 
         this.txtSecond.Location = new System.Drawing.Point(144, 56);
         this.txtSecond.Name = "txtSecond";
         this.txtSecond.Size = new System.Drawing.Size(80, 21);
         this.txtSecond.TabIndex = 6;
         this.txtSecond.Text = "";
         this.txtSecond.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtThird
         // 
         this.txtThird.Location = new System.Drawing.Point(144, 96);
         this.txtThird.Name = "txtThird";
         this.txtThird.Size = new System.Drawing.Size(80, 21);
         this.txtThird.TabIndex = 7;
         this.txtThird.Text = "";
         this.txtThird.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnMaximum
         // 
         this.btnMaximum.Location = new System.Drawing.Point(144, 192);
         this.btnMaximum.Name = "btnMaximum";
         this.btnMaximum.Size = new System.Drawing.Size(80, 24);
         this.btnMaximum.TabIndex = 8;
         this.btnMaximum.Text = "Maximum";
         // 
         // FrmMaximum
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(240, 229);
         this.Controls.Add(this.btnMaximum);
         this.Controls.Add(this.txtThird);
         this.Controls.Add(this.txtSecond);
         this.Controls.Add(this.txtFirst);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.lblMaximum);
         this.Controls.Add(this.lblThird);
         this.Controls.Add(this.lblSecond);
         this.Controls.Add(this.lblFirst);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmMaximum";
         this.Text = "Maximum";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmMaximum() );
      }

   } // end class FrmMaximum
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
