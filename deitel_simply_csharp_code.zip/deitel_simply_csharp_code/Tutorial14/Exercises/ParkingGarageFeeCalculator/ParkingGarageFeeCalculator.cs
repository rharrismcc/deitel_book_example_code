using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ParkingGarageFeeCalculator
{
   /// <summary>
   /// Summary description for FrmParkingGarageFeeCalculator.
   /// </summary>
   public class FrmParkingGarageFeeCalculator : System.Windows.Forms.Form
   {
      // Label to choose time that parking garage was entered
      private System.Windows.Forms.Label lblTimeIn;

      // Label to choose time that parking garage was exited
      private System.Windows.Forms.Label lblTimeOut;

      // Labels to display parking fee
      private System.Windows.Forms.Label lblFee;
      private System.Windows.Forms.Label lblFeeResult;

      // Button to calculate parking fee
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmParkingGarageFeeCalculator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblTimeIn = new System.Windows.Forms.Label();
         this.lblTimeOut = new System.Windows.Forms.Label();
         this.lblFee = new System.Windows.Forms.Label();
         this.lblFeeResult = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblTimeIn
         // 
         this.lblTimeIn.Location = new System.Drawing.Point(16, 16);
         this.lblTimeIn.Name = "lblTimeIn";
         this.lblTimeIn.Size = new System.Drawing.Size(48, 16);
         this.lblTimeIn.TabIndex = 1;
         this.lblTimeIn.Text = "Time in:";
         // 
         // lblTimeOut
         // 
         this.lblTimeOut.Location = new System.Drawing.Point(16, 56);
         this.lblTimeOut.Name = "lblTimeOut";
         this.lblTimeOut.Size = new System.Drawing.Size(56, 16);
         this.lblTimeOut.TabIndex = 2;
         this.lblTimeOut.Text = "Time out:";
         // 
         // lblFee
         // 
         this.lblFee.Location = new System.Drawing.Point(16, 88);
         this.lblFee.Name = "lblFee";
         this.lblFee.Size = new System.Drawing.Size(48, 16);
         this.lblFee.TabIndex = 7;
         this.lblFee.Text = "Fee:";
         // 
         // lblFeeResult
         // 
         this.lblFeeResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblFeeResult.Location = new System.Drawing.Point(88, 88);
         this.lblFeeResult.Name = "lblFeeResult";
         this.lblFeeResult.Size = new System.Drawing.Size(88, 16);
         this.lblFeeResult.TabIndex = 8;
         this.lblFeeResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(104, 120);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.TabIndex = 9;
         this.btnCalculate.Text = "Calculate";
         // 
         // FrmParkingGarageFeeCalculator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(192, 157);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblFeeResult);
         this.Controls.Add(this.lblFee);
         this.Controls.Add(this.lblTimeOut);
         this.Controls.Add(this.lblTimeIn);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmParkingGarageFeeCalculator";
         this.Text = "Fee Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmParkingGarageFeeCalculator() );
      }

   } // end class FrmParkingGarageFeeCalculator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/