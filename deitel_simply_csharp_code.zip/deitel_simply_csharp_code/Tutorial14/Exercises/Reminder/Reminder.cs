// Exercise 14.13 Solution
// Reminder.cs

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Reminder
{
   /// <summary>
   /// Summary description for FrmReminder.
   /// </summary>
   public class FrmReminder : System.Windows.Forms.Form
   {
      // Label and DateTimePicker to choose the time
      private System.Windows.Forms.Label lblTime;

      // Label and TextBox for reminder's text
      private System.Windows.Forms.Label lblReminder;
      private System.Windows.Forms.TextBox txtReminder;

      // Button to set the reminder for the displayed time
      private System.Windows.Forms.Button btnSetTime;

      // Button to cancel the reminder
      private System.Windows.Forms.Button btnReset;

      // Timer to keep track of reminder time
      private System.Windows.Forms.Timer tmrReminder;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components;

      public FrmReminder()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.lblTime = new System.Windows.Forms.Label();
         this.btnSetTime = new System.Windows.Forms.Button();
         this.btnReset = new System.Windows.Forms.Button();
         this.tmrReminder = new System.Windows.Forms.Timer(this.components);
         this.lblReminder = new System.Windows.Forms.Label();
         this.txtReminder = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // lblTime
         // 
         this.lblTime.Location = new System.Drawing.Point(10, 16);
         this.lblTime.Name = "lblTime";
         this.lblTime.Size = new System.Drawing.Size(48, 16);
         this.lblTime.TabIndex = 15;
         this.lblTime.Text = "Time:";
         this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // btnSetTime
         // 
         this.btnSetTime.Location = new System.Drawing.Point(176, 16);
         this.btnSetTime.Name = "btnSetTime";
         this.btnSetTime.Size = new System.Drawing.Size(48, 23);
         this.btnSetTime.TabIndex = 16;
         this.btnSetTime.Text = "Set";
         // 
         // btnReset
         // 
         this.btnReset.Enabled = false;
         this.btnReset.Location = new System.Drawing.Point(240, 16);
         this.btnReset.Name = "btnReset";
         this.btnReset.Size = new System.Drawing.Size(48, 24);
         this.btnReset.TabIndex = 17;
         this.btnReset.Text = "Reset";
         // 
         // tmrReminder
         // 
         this.tmrReminder.Enabled = true;
         this.tmrReminder.Interval = 1000;
         // 
         // lblReminder
         // 
         this.lblReminder.Location = new System.Drawing.Point(10, 56);
         this.lblReminder.Name = "lblReminder";
         this.lblReminder.Size = new System.Drawing.Size(62, 23);
         this.lblReminder.TabIndex = 19;
         this.lblReminder.Text = "Reminder:";
         this.lblReminder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtReminder
         // 
         this.txtReminder.Location = new System.Drawing.Point(80, 56);
         this.txtReminder.Name = "txtReminder";
         this.txtReminder.Size = new System.Drawing.Size(208, 21);
         this.txtReminder.TabIndex = 20;
         this.txtReminder.Text = "";
         // 
         // FrmReminder
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(304, 93);
         this.Controls.Add(this.txtReminder);
         this.Controls.Add(this.lblReminder);
         this.Controls.Add(this.btnReset);
         this.Controls.Add(this.btnSetTime);
         this.Controls.Add(this.lblTime);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmReminder";
         this.Text = "Pop-Up Reminder";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmReminder() );
      }

   } // end class FrmReminder
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/