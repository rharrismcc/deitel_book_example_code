using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ShippingTime
{
   /// <summary>
   /// Summary description for FrmShippingTime.
   /// </summary>
   public class FrmShippingTime : System.Windows.Forms.Form
   {
      // Labels and Timer to display current time
      private System.Windows.Forms.Label lblCurrentTimeIs;
      private System.Windows.Forms.Label lblCurrentTime;
      private System.Windows.Forms.Timer tmrClock;

      // GroupBox for drop-off time
      private System.Windows.Forms.GroupBox fraDropOff;

      // Label and DateTimePicker to choose drop-off time
      private System.Windows.Forms.Label lblDropOff;
      private System.Windows.Forms.DateTimePicker dtpDropOff;

      // GroupBox for delivery time
      private System.Windows.Forms.GroupBox fraDeliveryTime;

      // Labels to display delivery time
      private System.Windows.Forms.Label lblDeliveryTime;
      private System.Windows.Forms.Label lblLasVegasTime;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components;

      public FrmShippingTime()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.lblCurrentTimeIs = new System.Windows.Forms.Label();
         this.lblCurrentTime = new System.Windows.Forms.Label();
         this.fraDeliveryTime = new System.Windows.Forms.GroupBox();
         this.lblLasVegasTime = new System.Windows.Forms.Label();
         this.lblDeliveryTime = new System.Windows.Forms.Label();
         this.fraDropOff = new System.Windows.Forms.GroupBox();
         this.dtpDropOff = new System.Windows.Forms.DateTimePicker();
         this.lblDropOff = new System.Windows.Forms.Label();
         this.tmrClock = new System.Windows.Forms.Timer(this.components);
         this.fraDeliveryTime.SuspendLayout();
         this.fraDropOff.SuspendLayout();
         this.SuspendLayout();
         // 
         // lblCurrentTimeIs
         // 
         this.lblCurrentTimeIs.Location = new System.Drawing.Point(160, 16);
         this.lblCurrentTimeIs.Name = "lblCurrentTimeIs";
         this.lblCurrentTimeIs.TabIndex = 0;
         this.lblCurrentTimeIs.Text = "Current time is:";
         this.lblCurrentTimeIs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblCurrentTime
         // 
         this.lblCurrentTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblCurrentTime.Location = new System.Drawing.Point(256, 16);
         this.lblCurrentTime.Name = "lblCurrentTime";
         this.lblCurrentTime.Size = new System.Drawing.Size(88, 23);
         this.lblCurrentTime.TabIndex = 1;
         this.lblCurrentTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // fraDeliveryTime
         // 
         this.fraDeliveryTime.Controls.Add(this.lblLasVegasTime);
         this.fraDeliveryTime.Controls.Add(this.lblDeliveryTime);
         this.fraDeliveryTime.Location = new System.Drawing.Point(16, 136);
         this.fraDeliveryTime.Name = "fraDeliveryTime";
         this.fraDeliveryTime.Size = new System.Drawing.Size(328, 73);
         this.fraDeliveryTime.TabIndex = 2;
         this.fraDeliveryTime.TabStop = false;
         this.fraDeliveryTime.Text = "Express Shipping to Las Vegas";
         // 
         // lblLasVegasTime
         // 
         this.lblLasVegasTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblLasVegasTime.Location = new System.Drawing.Point(96, 32);
         this.lblLasVegasTime.Name = "lblLasVegasTime";
         this.lblLasVegasTime.Size = new System.Drawing.Size(224, 24);
         this.lblLasVegasTime.TabIndex = 1;
         this.lblLasVegasTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblDeliveryTime
         // 
         this.lblDeliveryTime.Location = new System.Drawing.Point(13, 32);
         this.lblDeliveryTime.Name = "lblDeliveryTime";
         this.lblDeliveryTime.Size = new System.Drawing.Size(80, 23);
         this.lblDeliveryTime.TabIndex = 0;
         this.lblDeliveryTime.Text = "Delivery time:";
         this.lblDeliveryTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // fraDropOff
         // 
         this.fraDropOff.Controls.Add(this.dtpDropOff);
         this.fraDropOff.Controls.Add(this.lblDropOff);
         this.fraDropOff.Location = new System.Drawing.Point(15, 56);
         this.fraDropOff.Name = "fraDropOff";
         this.fraDropOff.Size = new System.Drawing.Size(328, 64);
         this.fraDropOff.TabIndex = 3;
         this.fraDropOff.TabStop = false;
         this.fraDropOff.Text = "Drop Off";
         // 
         // dtpDropOff
         // 
         this.dtpDropOff.CustomFormat = "hh:mm tt";
         this.dtpDropOff.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
         this.dtpDropOff.Location = new System.Drawing.Point(128, 32);
         this.dtpDropOff.Name = "dtpDropOff";
         this.dtpDropOff.ShowUpDown = true;
         this.dtpDropOff.Size = new System.Drawing.Size(88, 21);
         this.dtpDropOff.TabIndex = 1;
         this.dtpDropOff.ValueChanged += new System.EventHandler(this.dtpDropOff_ValueChanged);
         // 
         // lblDropOff
         // 
         this.lblDropOff.Location = new System.Drawing.Point(16, 32);
         this.lblDropOff.Name = "lblDropOff";
         this.lblDropOff.Size = new System.Drawing.Size(104, 21);
         this.lblDropOff.TabIndex = 0;
         this.lblDropOff.Text = "Enter drop-off time:";
         this.lblDropOff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // tmrClock
         // 
         this.tmrClock.Enabled = true;
         this.tmrClock.Interval = 1000;
         this.tmrClock.Tick += new System.EventHandler(this.tmrClock_Tick);
         // 
         // FrmShippingTime
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(360, 229);
         this.Controls.Add(this.fraDropOff);
         this.Controls.Add(this.fraDeliveryTime);
         this.Controls.Add(this.lblCurrentTime);
         this.Controls.Add(this.lblCurrentTimeIs);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmShippingTime";
         this.Text = "Shipping Time";
         this.Load += new System.EventHandler(this.FrmShippingTime_Load);
         this.fraDeliveryTime.ResumeLayout(false);
         this.fraDropOff.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmShippingTime() );
      }

      // update current time every second
      private void tmrClock_Tick( 
         object sender, System.EventArgs e )
      {
         // print current time
         lblCurrentTime.Text = 
            String.Format( "{0:hh:mm:ss tt}", DateTime.Now );

      } // end method tmrClock_Tick

      // initialize DateTimePicker status when Form loads
      private void FrmShippingTime_Load(
         object sender, System.EventArgs e )
      {
         // store current time
         DateTime dtmCurrentTime = DateTime.Now;

         // set range of possible drop-off times
         dtpDropOff.MinDate = new DateTime( dtmCurrentTime.Year,
            dtmCurrentTime.Month, dtmCurrentTime.Day, 0, 0, 0 );

         dtpDropOff.MaxDate = dtpDropOff.MinDate.AddDays( 1 );

         // display the delivery time
         DisplayDeliveryTime();

      } // end method FrmShippingTime_Load

      // update ship time on change of drop-off time
      private void dtpDropOff_ValueChanged(
         object sender, System.EventArgs e )
      {
         // display the delivery time
         DisplayDeliveryTime();

      } // end method dtpDropOff_ValueChanged

      // calculates and displays the delivery time
      void DisplayDeliveryTime()
      {
         // print initial delivery time
         DateTime dtmDelivery = DepartureTime();

         // add 3 hours to departure and display result
         dtmDelivery = dtmDelivery.AddHours( 3 );
         lblLasVegasTime.Text = dtmDelivery.ToLongDateString()
            + " at " + dtmDelivery.ToShortTimeString();

      } // end method DisplayDeliveryTime

      // returns flight departure time for selected drop-off time
      DateTime DepartureTime()
      {
         // store current date and departure time
         DateTime dtmCurrentDate = DateTime.Now;
         DateTime dtmDepartureTime; 

         // determine which flight the shipment takes
         switch ( dtpDropOff.Value.Hour )
         {
            // seafood will be on the noon flight
            case 1: case 2: case 3: case 4: case 5:
            case 6: case 7: case 8: case 9: case 10:
               dtmDepartureTime = new DateTime(
                  dtmCurrentDate.Year, dtmCurrentDate.Month,
                  dtmCurrentDate.Day, 12, 0, 0 );
               break;

            // seafood will be on tomorrow's noon flight
            case 23:
               dtmCurrentDate = dtmCurrentDate.AddDays( 1 );
               dtmDepartureTime = new DateTime( 
                  dtmCurrentDate.Year, dtmCurrentDate.Month,
                  dtmCurrentDate.Day, 12, 0, 0 );
               break;

            // seafood will be on midnight flight
            default:
               dtmCurrentDate = dtmCurrentDate.AddDays( 1 );
               dtmDepartureTime = new DateTime(
                  dtmCurrentDate.Year, dtmCurrentDate.Month,
                  dtmCurrentDate.Day, 0, 0, 0 );
               break;

         } // end switch

         // return the flight's departure time
         return dtmDepartureTime; 

      } // end method DepartureTime

   } // end class FrmShippingTime
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
