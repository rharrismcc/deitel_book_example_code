using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WorldClock
{
   /// <summary>
   /// Summary description for FrmWorldClock.
   /// </summary>
   public class FrmWorldClock : System.Windows.Forms.Form
   {
      // Labels to display the time in Los Angeles
      private System.Windows.Forms.Label lblLA;
      private System.Windows.Forms.Label lblLATime;

      // Labels to display the time in Atlanta
      private System.Windows.Forms.Label lblAtlanta;
      private System.Windows.Forms.Label lblAtlantaTime;

      // Labels to display the time in London
      private System.Windows.Forms.Label lblLondon;
      private System.Windows.Forms.Label lblLondonTime;

      // Labels to display the time in Tokyo
      private System.Windows.Forms.Label lblTokyo;
      private System.Windows.Forms.Label lblTokyoTime;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmWorldClock()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblLA = new System.Windows.Forms.Label();
         this.lblLATime = new System.Windows.Forms.Label();
         this.lblAtlanta = new System.Windows.Forms.Label();
         this.lblAtlantaTime = new System.Windows.Forms.Label();
         this.lblLondon = new System.Windows.Forms.Label();
         this.lblLondonTime = new System.Windows.Forms.Label();
         this.lblTokyo = new System.Windows.Forms.Label();
         this.lblTokyoTime = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // lblLA
         // 
         this.lblLA.Location = new System.Drawing.Point(16, 16);
         this.lblLA.Name = "lblLA";
         this.lblLA.Size = new System.Drawing.Size(72, 24);
         this.lblLA.TabIndex = 8;
         this.lblLA.Text = "Los Angeles:";
         this.lblLA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblLATime
         // 
         this.lblLATime.BackColor = System.Drawing.SystemColors.Control;
         this.lblLATime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblLATime.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblLATime.Location = new System.Drawing.Point(104, 16);
         this.lblLATime.Name = "lblLATime";
         this.lblLATime.Size = new System.Drawing.Size(184, 24);
         this.lblLATime.TabIndex = 9;
         this.lblLATime.Text = "Time";
         this.lblLATime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblAtlanta
         // 
         this.lblAtlanta.Location = new System.Drawing.Point(16, 56);
         this.lblAtlanta.Name = "lblAtlanta";
         this.lblAtlanta.Size = new System.Drawing.Size(72, 24);
         this.lblAtlanta.TabIndex = 10;
         this.lblAtlanta.Text = "Atlanta:";
         this.lblAtlanta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblAtlantaTime
         // 
         this.lblAtlantaTime.BackColor = System.Drawing.SystemColors.Control;
         this.lblAtlantaTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblAtlantaTime.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblAtlantaTime.Location = new System.Drawing.Point(104, 56);
         this.lblAtlantaTime.Name = "lblAtlantaTime";
         this.lblAtlantaTime.Size = new System.Drawing.Size(184, 24);
         this.lblAtlantaTime.TabIndex = 11;
         this.lblAtlantaTime.Text = "Time";
         this.lblAtlantaTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblLondon
         // 
         this.lblLondon.Location = new System.Drawing.Point(16, 96);
         this.lblLondon.Name = "lblLondon";
         this.lblLondon.Size = new System.Drawing.Size(72, 24);
         this.lblLondon.TabIndex = 12;
         this.lblLondon.Text = "London:";
         this.lblLondon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblLondonTime
         // 
         this.lblLondonTime.BackColor = System.Drawing.SystemColors.Control;
         this.lblLondonTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblLondonTime.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblLondonTime.Location = new System.Drawing.Point(104, 96);
         this.lblLondonTime.Name = "lblLondonTime";
         this.lblLondonTime.Size = new System.Drawing.Size(184, 24);
         this.lblLondonTime.TabIndex = 13;
         this.lblLondonTime.Text = "Time";
         this.lblLondonTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblTokyo
         // 
         this.lblTokyo.Location = new System.Drawing.Point(16, 136);
         this.lblTokyo.Name = "lblTokyo";
         this.lblTokyo.Size = new System.Drawing.Size(72, 24);
         this.lblTokyo.TabIndex = 14;
         this.lblTokyo.Text = "Tokyo:";
         this.lblTokyo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTokyoTime
         // 
         this.lblTokyoTime.BackColor = System.Drawing.SystemColors.Control;
         this.lblTokyoTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTokyoTime.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblTokyoTime.Location = new System.Drawing.Point(104, 136);
         this.lblTokyoTime.Name = "lblTokyoTime";
         this.lblTokyoTime.Size = new System.Drawing.Size(184, 24);
         this.lblTokyoTime.TabIndex = 15;
         this.lblTokyoTime.Text = "Time";
         this.lblTokyoTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // FrmWorldClock
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(304, 173);
         this.Controls.Add(this.lblTokyoTime);
         this.Controls.Add(this.lblTokyo);
         this.Controls.Add(this.lblLondonTime);
         this.Controls.Add(this.lblLondon);
         this.Controls.Add(this.lblAtlantaTime);
         this.Controls.Add(this.lblAtlanta);
         this.Controls.Add(this.lblLATime);
         this.Controls.Add(this.lblLA);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmWorldClock";
         this.Text = "World Clock";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmWorldClock() );
      }

   } // end class FrmWorldClock
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/