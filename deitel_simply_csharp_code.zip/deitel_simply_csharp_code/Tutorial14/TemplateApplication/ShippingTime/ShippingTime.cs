using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ShippingTime
{
   /// <summary>
   /// Summary description for FrmShippingTime.
   /// </summary>
   public class FrmShippingTime : System.Windows.Forms.Form
   {
      // Labels to display current time
      private System.Windows.Forms.Label lblCurrentTimeIs;
      private System.Windows.Forms.Label lblCurrentTime;

      // GroupBox for delivery time
      private System.Windows.Forms.GroupBox fraDeliveryTime;

      // Labels to display delivery time
      private System.Windows.Forms.Label lblDeliveryTime;
      private System.Windows.Forms.Label lblLasVegasTime;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmShippingTime()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblCurrentTimeIs = new System.Windows.Forms.Label();
         this.lblCurrentTime = new System.Windows.Forms.Label();
         this.fraDeliveryTime = new System.Windows.Forms.GroupBox();
         this.lblLasVegasTime = new System.Windows.Forms.Label();
         this.lblDeliveryTime = new System.Windows.Forms.Label();
         this.fraDeliveryTime.SuspendLayout();
         this.SuspendLayout();
         // 
         // lblCurrentTimeIs
         // 
         this.lblCurrentTimeIs.Location = new System.Drawing.Point(160, 16);
         this.lblCurrentTimeIs.Name = "lblCurrentTimeIs";
         this.lblCurrentTimeIs.TabIndex = 0;
         this.lblCurrentTimeIs.Text = "Current time is:";
         this.lblCurrentTimeIs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblCurrentTime
         // 
         this.lblCurrentTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblCurrentTime.Location = new System.Drawing.Point(256, 16);
         this.lblCurrentTime.Name = "lblCurrentTime";
         this.lblCurrentTime.Size = new System.Drawing.Size(88, 23);
         this.lblCurrentTime.TabIndex = 1;
         this.lblCurrentTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // fraDeliveryTime
         // 
         this.fraDeliveryTime.Controls.Add(this.lblLasVegasTime);
         this.fraDeliveryTime.Controls.Add(this.lblDeliveryTime);
         this.fraDeliveryTime.Location = new System.Drawing.Point(16, 136);
         this.fraDeliveryTime.Name = "fraDeliveryTime";
         this.fraDeliveryTime.Size = new System.Drawing.Size(328, 73);
         this.fraDeliveryTime.TabIndex = 2;
         this.fraDeliveryTime.TabStop = false;
         this.fraDeliveryTime.Text = "Express Shipping to Las Vegas";
         // 
         // lblLasVegasTime
         // 
         this.lblLasVegasTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblLasVegasTime.Location = new System.Drawing.Point(96, 32);
         this.lblLasVegasTime.Name = "lblLasVegasTime";
         this.lblLasVegasTime.Size = new System.Drawing.Size(224, 24);
         this.lblLasVegasTime.TabIndex = 1;
         this.lblLasVegasTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblDeliveryTime
         // 
         this.lblDeliveryTime.Location = new System.Drawing.Point(13, 32);
         this.lblDeliveryTime.Name = "lblDeliveryTime";
         this.lblDeliveryTime.Size = new System.Drawing.Size(80, 23);
         this.lblDeliveryTime.TabIndex = 0;
         this.lblDeliveryTime.Text = "Delivery time:";
         this.lblDeliveryTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // FrmShippingTime
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(360, 229);
         this.Controls.Add(this.fraDeliveryTime);
         this.Controls.Add(this.lblCurrentTime);
         this.Controls.Add(this.lblCurrentTimeIs);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmShippingTime";
         this.Text = "Shipping Time";
         this.fraDeliveryTime.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmShippingTime() );
      }

   } // end class FrmShippingTime
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
