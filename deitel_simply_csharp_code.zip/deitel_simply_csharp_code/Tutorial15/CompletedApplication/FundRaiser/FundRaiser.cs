using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace FundRaiser
{
   /// <summary>
   /// Summary description for FrmFundRaiser.
   /// </summary>
   public class FrmFundRaiser : System.Windows.Forms.Form
   {
      // Label and TextBox to input donation
      private System.Windows.Forms.Label lblDonation;
      private System.Windows.Forms.TextBox txtDonation;

      // Labels to display value of donation after expenses
      private System.Windows.Forms.Label lblDonated;
      private System.Windows.Forms.Label lblDonatedValue;

      // Labels to display total raised so far minus expenses
      private System.Windows.Forms.Label lblTotal;
      private System.Windows.Forms.Label lblTotalValue;

      // Button to make a donation
      private System.Windows.Forms.Button btnDonate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // instance variable stores total raised for charity
      decimal m_decTotalRaised = 0;

      public FrmFundRaiser()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblDonation = new System.Windows.Forms.Label();
         this.lblDonated = new System.Windows.Forms.Label();
         this.lblDonatedValue = new System.Windows.Forms.Label();
         this.lblTotal = new System.Windows.Forms.Label();
         this.lblTotalValue = new System.Windows.Forms.Label();
         this.txtDonation = new System.Windows.Forms.TextBox();
         this.btnDonate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblDonation
         // 
         this.lblDonation.Location = new System.Drawing.Point(16, 16);
         this.lblDonation.Name = "lblDonation";
         this.lblDonation.Size = new System.Drawing.Size(80, 20);
         this.lblDonation.TabIndex = 0;
         this.lblDonation.Text = "Donation:";
         this.lblDonation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblDonated
         // 
         this.lblDonated.Location = new System.Drawing.Point(16, 48);
         this.lblDonated.Name = "lblDonated";
         this.lblDonated.Size = new System.Drawing.Size(88, 20);
         this.lblDonated.TabIndex = 1;
         this.lblDonated.Text = "After expenses:";
         this.lblDonated.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblDonatedValue
         // 
         this.lblDonatedValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblDonatedValue.Location = new System.Drawing.Point(112, 48);
         this.lblDonatedValue.Name = "lblDonatedValue";
         this.lblDonatedValue.Size = new System.Drawing.Size(120, 20);
         this.lblDonatedValue.TabIndex = 2;
         this.lblDonatedValue.Text = "$0.00";
         this.lblDonatedValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblTotal
         // 
         this.lblTotal.Location = new System.Drawing.Point(16, 80);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(88, 20);
         this.lblTotal.TabIndex = 3;
         this.lblTotal.Text = "Total raised:";
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotalValue
         // 
         this.lblTotalValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalValue.Location = new System.Drawing.Point(112, 80);
         this.lblTotalValue.Name = "lblTotalValue";
         this.lblTotalValue.Size = new System.Drawing.Size(120, 20);
         this.lblTotalValue.TabIndex = 4;
         this.lblTotalValue.Text = "$0.00";
         this.lblTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // txtDonation
         // 
         this.txtDonation.Location = new System.Drawing.Point(112, 16);
         this.txtDonation.Name = "txtDonation";
         this.txtDonation.Size = new System.Drawing.Size(120, 21);
         this.txtDonation.TabIndex = 5;
         this.txtDonation.Text = "";
         this.txtDonation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.txtDonation.TextChanged += new System.EventHandler(this.txtDonation_TextChanged);
         // 
         // btnDonate
         // 
         this.btnDonate.Location = new System.Drawing.Point(72, 112);
         this.btnDonate.Name = "btnDonate";
         this.btnDonate.Size = new System.Drawing.Size(104, 24);
         this.btnDonate.TabIndex = 6;
         this.btnDonate.Text = "Make Donation";
         this.btnDonate.Click += new System.EventHandler(this.btnDonate_Click);
         // 
         // FrmFundRaiser
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(248, 149);
         this.Controls.Add(this.btnDonate);
         this.Controls.Add(this.txtDonation);
         this.Controls.Add(this.lblTotalValue);
         this.Controls.Add(this.lblTotal);
         this.Controls.Add(this.lblDonatedValue);
         this.Controls.Add(this.lblDonated);
         this.Controls.Add(this.lblDonation);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmFundRaiser";
         this.Text = "Fund Raiser";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmFundRaiser() );
      }

      // returns donation amount after operating expenses
      void CalculateDonation( 
         decimal decDonatedAmount, out decimal decNetDonation )
      {
         const double dblCOSTS = 0.17;

         // calculate amount of donation for charity
         decNetDonation = decDonatedAmount -
            ( decDonatedAmount * ( decimal ) dblCOSTS );

      }  // end method CalculateDonation

      // handles Donation: TextBox's TextChanged event
      private void txtDonation_TextChanged(
         object sender, System.EventArgs e )
      {
         lblDonatedValue.Text = ""; // clear After expenses: field

      } // end method txtDonation_TextChanged

      // handles Make Donation Button's Click event
      private void btnDonate_Click( 
         object sender, System.EventArgs e )
      {
         decimal decDonation;    // amount donated
         decimal decAfterCosts;  // amount for charity

         // get donation amount
         decDonation = Decimal.Parse( txtDonation.Text );

         // obtain donation amount after operating costs deduction
         CalculateDonation( decDonation, out decAfterCosts );

         // display amount of donation after costs
         lblDonatedValue.Text = 
            String.Format( "{0:C}", decAfterCosts );

         // update total amount of donations received
         m_decTotalRaised += decAfterCosts;

         // display total amount collected for charity
         lblTotalValue.Text = 
            String.Format( "{0:C}", m_decTotalRaised );

      } // end method btnDonate_Click

   } // end class FrmFundRaiser
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
