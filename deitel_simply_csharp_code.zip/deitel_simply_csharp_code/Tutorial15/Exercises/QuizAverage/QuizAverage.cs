using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace QuizAverage
{
   /// <summary>
   /// Summary description for FrmQuizAverage.
   /// </summary>
   public class FrmQuizAverage : System.Windows.Forms.Form
   {
      // Label and TextBox to input a quiz score
      private System.Windows.Forms.Label lblScore;
      private System.Windows.Forms.TextBox txtScore;

      // Labels to display number of quizzes taken
      private System.Windows.Forms.Label lblNumber;
      private System.Windows.Forms.Label lblTaken;

      // Labels to display average quiz score
      private System.Windows.Forms.Label lblResult;
      private System.Windows.Forms.Label lblAverage;

      // Button to submit a quiz score and recalculate the average
      private System.Windows.Forms.Button btnCalculate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmQuizAverage()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblScore = new System.Windows.Forms.Label();
         this.txtScore = new System.Windows.Forms.TextBox();
         this.lblNumber = new System.Windows.Forms.Label();
         this.lblTaken = new System.Windows.Forms.Label();
         this.lblResult = new System.Windows.Forms.Label();
         this.lblAverage = new System.Windows.Forms.Label();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblScore
         // 
         this.lblScore.Location = new System.Drawing.Point(16, 8);
         this.lblScore.Name = "lblScore";
         this.lblScore.Size = new System.Drawing.Size(88, 21);
         this.lblScore.TabIndex = 1;
         this.lblScore.Text = "Quiz score:";
         this.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtScore
         // 
         this.txtScore.Location = new System.Drawing.Point(112, 8);
         this.txtScore.Name = "txtScore";
         this.txtScore.Size = new System.Drawing.Size(40, 21);
         this.txtScore.TabIndex = 2;
         this.txtScore.Text = "";
         this.txtScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblNumber
         // 
         this.lblNumber.Location = new System.Drawing.Point(16, 40);
         this.lblNumber.Name = "lblNumber";
         this.lblNumber.Size = new System.Drawing.Size(88, 21);
         this.lblNumber.TabIndex = 3;
         this.lblNumber.Text = "Number taken:";
         this.lblNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTaken
         // 
         this.lblTaken.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTaken.Location = new System.Drawing.Point(112, 40);
         this.lblTaken.Name = "lblTaken";
         this.lblTaken.Size = new System.Drawing.Size(40, 21);
         this.lblTaken.TabIndex = 4;
         this.lblTaken.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblResult
         // 
         this.lblResult.Location = new System.Drawing.Point(160, 40);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(56, 21);
         this.lblResult.TabIndex = 5;
         this.lblResult.Text = "Average:";
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblAverage
         // 
         this.lblAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblAverage.Location = new System.Drawing.Point(224, 40);
         this.lblAverage.Name = "lblAverage";
         this.lblAverage.Size = new System.Drawing.Size(40, 21);
         this.lblAverage.TabIndex = 6;
         this.lblAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(168, 8);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(96, 23);
         this.btnCalculate.TabIndex = 7;
         this.btnCalculate.Text = "Submit Score";
         // 
         // FrmQuizAverage
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(288, 77);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.lblAverage);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.lblTaken);
         this.Controls.Add(this.lblNumber);
         this.Controls.Add(this.txtScore);
         this.Controls.Add(this.lblScore);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmQuizAverage";
         this.Text = "Quiz Average";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmQuizAverage() );
      }

   } // end class FrmQuizAverage
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/