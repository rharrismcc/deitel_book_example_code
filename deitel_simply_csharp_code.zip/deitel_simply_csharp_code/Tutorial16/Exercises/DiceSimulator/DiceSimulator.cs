using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace DiceSimulator
{
   /// <summary>
   /// Summary description for FrmDiceSimulator.
   /// </summary>
   public class FrmDiceSimulator : System.Windows.Forms.Form
   {
      // Labels to display the number of times each face
      // has appeared
      private System.Windows.Forms.Label lblSide1;
      private System.Windows.Forms.Label lblOutput1;
      private System.Windows.Forms.Label lblSide2;
      private System.Windows.Forms.Label lblOutput2;
      private System.Windows.Forms.Label lblSide3;
      private System.Windows.Forms.Label lblOutput3;
      private System.Windows.Forms.Label lblSide4;
      private System.Windows.Forms.Label lblOutput4;
      private System.Windows.Forms.Label lblSide5;
      private System.Windows.Forms.Label lblOutput5;
      private System.Windows.Forms.Label lblSide6;
      private System.Windows.Forms.Label lblOutput6;

      // PictureBoxes to show the two dice
      private System.Windows.Forms.PictureBox picDie1;
      private System.Windows.Forms.PictureBox picDie2;

      // Button to roll the dice
      private System.Windows.Forms.Button btnRoll;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmDiceSimulator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblSide1 = new System.Windows.Forms.Label();
         this.lblOutput1 = new System.Windows.Forms.Label();
         this.lblSide2 = new System.Windows.Forms.Label();
         this.lblOutput2 = new System.Windows.Forms.Label();
         this.lblSide3 = new System.Windows.Forms.Label();
         this.lblOutput3 = new System.Windows.Forms.Label();
         this.lblSide4 = new System.Windows.Forms.Label();
         this.lblOutput4 = new System.Windows.Forms.Label();
         this.lblSide5 = new System.Windows.Forms.Label();
         this.lblOutput5 = new System.Windows.Forms.Label();
         this.lblSide6 = new System.Windows.Forms.Label();
         this.lblOutput6 = new System.Windows.Forms.Label();
         this.picDie1 = new System.Windows.Forms.PictureBox();
         this.picDie2 = new System.Windows.Forms.PictureBox();
         this.btnRoll = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblSide1
         // 
         this.lblSide1.Location = new System.Drawing.Point(16, 16);
         this.lblSide1.Name = "lblSide1";
         this.lblSide1.Size = new System.Drawing.Size(48, 23);
         this.lblSide1.TabIndex = 4;
         this.lblSide1.Text = "Side 1:";
         this.lblSide1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput1
         // 
         this.lblOutput1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput1.Location = new System.Drawing.Point(72, 16);
         this.lblOutput1.Name = "lblOutput1";
         this.lblOutput1.Size = new System.Drawing.Size(56, 23);
         this.lblOutput1.TabIndex = 12;
         this.lblOutput1.Text = "0";
         this.lblOutput1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSide2
         // 
         this.lblSide2.Location = new System.Drawing.Point(16, 48);
         this.lblSide2.Name = "lblSide2";
         this.lblSide2.Size = new System.Drawing.Size(48, 23);
         this.lblSide2.TabIndex = 13;
         this.lblSide2.Text = "Side 2:";
         this.lblSide2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput2
         // 
         this.lblOutput2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput2.Location = new System.Drawing.Point(72, 48);
         this.lblOutput2.Name = "lblOutput2";
         this.lblOutput2.Size = new System.Drawing.Size(56, 23);
         this.lblOutput2.TabIndex = 14;
         this.lblOutput2.Text = "0";
         this.lblOutput2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSide3
         // 
         this.lblSide3.Location = new System.Drawing.Point(16, 80);
         this.lblSide3.Name = "lblSide3";
         this.lblSide3.Size = new System.Drawing.Size(48, 23);
         this.lblSide3.TabIndex = 15;
         this.lblSide3.Text = "Side 3:";
         this.lblSide3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput3
         // 
         this.lblOutput3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput3.Location = new System.Drawing.Point(72, 80);
         this.lblOutput3.Name = "lblOutput3";
         this.lblOutput3.Size = new System.Drawing.Size(56, 23);
         this.lblOutput3.TabIndex = 16;
         this.lblOutput3.Text = "0";
         this.lblOutput3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSide4
         // 
         this.lblSide4.Location = new System.Drawing.Point(16, 112);
         this.lblSide4.Name = "lblSide4";
         this.lblSide4.Size = new System.Drawing.Size(48, 23);
         this.lblSide4.TabIndex = 17;
         this.lblSide4.Text = "Side 4:";
         this.lblSide4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput4
         // 
         this.lblOutput4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput4.Location = new System.Drawing.Point(72, 112);
         this.lblOutput4.Name = "lblOutput4";
         this.lblOutput4.Size = new System.Drawing.Size(56, 23);
         this.lblOutput4.TabIndex = 18;
         this.lblOutput4.Text = "0";
         this.lblOutput4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSide5
         // 
         this.lblSide5.Location = new System.Drawing.Point(16, 144);
         this.lblSide5.Name = "lblSide5";
         this.lblSide5.Size = new System.Drawing.Size(48, 23);
         this.lblSide5.TabIndex = 19;
         this.lblSide5.Text = "Side 5:";
         this.lblSide5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput5
         // 
         this.lblOutput5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput5.Location = new System.Drawing.Point(72, 144);
         this.lblOutput5.Name = "lblOutput5";
         this.lblOutput5.Size = new System.Drawing.Size(56, 23);
         this.lblOutput5.TabIndex = 20;
         this.lblOutput5.Text = "0";
         this.lblOutput5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSide6
         // 
         this.lblSide6.Location = new System.Drawing.Point(16, 176);
         this.lblSide6.Name = "lblSide6";
         this.lblSide6.Size = new System.Drawing.Size(48, 23);
         this.lblSide6.TabIndex = 21;
         this.lblSide6.Text = "Side 6:";
         this.lblSide6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput6
         // 
         this.lblOutput6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput6.Location = new System.Drawing.Point(72, 176);
         this.lblOutput6.Name = "lblOutput6";
         this.lblOutput6.Size = new System.Drawing.Size(56, 23);
         this.lblOutput6.TabIndex = 22;
         this.lblOutput6.Text = "0";
         this.lblOutput6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // picDie1
         // 
         this.picDie1.Location = new System.Drawing.Point(152, 32);
         this.picDie1.Name = "picDie1";
         this.picDie1.Size = new System.Drawing.Size(72, 64);
         this.picDie1.TabIndex = 23;
         this.picDie1.TabStop = false;
         // 
         // picDie2
         // 
         this.picDie2.Location = new System.Drawing.Point(208, 96);
         this.picDie2.Name = "picDie2";
         this.picDie2.Size = new System.Drawing.Size(72, 64);
         this.picDie2.TabIndex = 24;
         this.picDie2.TabStop = false;
         // 
         // btnRoll
         // 
         this.btnRoll.Location = new System.Drawing.Point(144, 176);
         this.btnRoll.Name = "btnRoll";
         this.btnRoll.Size = new System.Drawing.Size(136, 24);
         this.btnRoll.TabIndex = 25;
         this.btnRoll.Text = "Roll";
         // 
         // FrmDiceSimulator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(296, 213);
         this.Controls.Add(this.btnRoll);
         this.Controls.Add(this.picDie2);
         this.Controls.Add(this.picDie1);
         this.Controls.Add(this.lblOutput6);
         this.Controls.Add(this.lblSide6);
         this.Controls.Add(this.lblOutput5);
         this.Controls.Add(this.lblSide5);
         this.Controls.Add(this.lblOutput4);
         this.Controls.Add(this.lblSide4);
         this.Controls.Add(this.lblOutput3);
         this.Controls.Add(this.lblSide3);
         this.Controls.Add(this.lblOutput2);
         this.Controls.Add(this.lblSide2);
         this.Controls.Add(this.lblOutput1);
         this.Controls.Add(this.lblSide1);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmDiceSimulator";
         this.Text = "Dice Simulator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmDiceSimulator() );
      }

   } // end class FrmDiceSimulator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/