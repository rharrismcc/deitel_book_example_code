using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace GuessNumber
{
   /// <summary>
   /// Summary description for FrmGuessNumber.
   /// </summary>
   public class FrmGuessNumber : System.Windows.Forms.Form
   {
      // Label to display directions
      private System.Windows.Forms.Label lblQuestion;

      // Label and TextBox to input a number as a guess
      private System.Windows.Forms.Label lblGuessNumber;
      private System.Windows.Forms.TextBox txtGuessNumber;

      // Labels to display result of guess
      private System.Windows.Forms.Label lblResult;
      private System.Windows.Forms.Label lblResultLabel;

      // Button to enter a guess
      private System.Windows.Forms.Button btnEnter;
      
      // Button to begin a new game
      private System.Windows.Forms.Button btnNewGame;
      
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmGuessNumber()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblQuestion = new System.Windows.Forms.Label();
         this.lblGuessNumber = new System.Windows.Forms.Label();
         this.txtGuessNumber = new System.Windows.Forms.TextBox();
         this.lblResultLabel = new System.Windows.Forms.Label();
         this.lblResult = new System.Windows.Forms.Label();
         this.btnEnter = new System.Windows.Forms.Button();
         this.btnNewGame = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblQuestion
         // 
         this.lblQuestion.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblQuestion.Location = new System.Drawing.Point(40, 16);
         this.lblQuestion.Name = "lblQuestion";
         this.lblQuestion.Size = new System.Drawing.Size(216, 48);
         this.lblQuestion.TabIndex = 2;
         this.lblQuestion.Text = "I have a number between 1 and 100. Can you guess my number? ";
         // 
         // lblGuessNumber
         // 
         this.lblGuessNumber.Location = new System.Drawing.Point(16, 80);
         this.lblGuessNumber.Name = "lblGuessNumber";
         this.lblGuessNumber.Size = new System.Drawing.Size(40, 20);
         this.lblGuessNumber.TabIndex = 7;
         this.lblGuessNumber.Text = "Guess:";
         this.lblGuessNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtGuessNumber
         // 
         this.txtGuessNumber.Location = new System.Drawing.Point(64, 80);
         this.txtGuessNumber.Name = "txtGuessNumber";
         this.txtGuessNumber.Size = new System.Drawing.Size(128, 21);
         this.txtGuessNumber.TabIndex = 8;
         this.txtGuessNumber.Text = "";
         this.txtGuessNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblResultLabel
         // 
         this.lblResultLabel.Location = new System.Drawing.Point(16, 112);
         this.lblResultLabel.Name = "lblResultLabel";
         this.lblResultLabel.Size = new System.Drawing.Size(40, 23);
         this.lblResultLabel.TabIndex = 10;
         this.lblResultLabel.Text = "Result:";
         // 
         // lblResult
         // 
         this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblResult.Location = new System.Drawing.Point(64, 112);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(128, 23);
         this.lblResult.TabIndex = 11;
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnEnter
         // 
         this.btnEnter.Location = new System.Drawing.Point(208, 80);
         this.btnEnter.Name = "btnEnter";
         this.btnEnter.TabIndex = 12;
         this.btnEnter.Text = "Enter";
         // 
         // btnNewGame
         // 
         this.btnNewGame.Enabled = false;
         this.btnNewGame.Location = new System.Drawing.Point(208, 112);
         this.btnNewGame.Name = "btnNewGame";
         this.btnNewGame.TabIndex = 13;
         this.btnNewGame.Text = "New Game";
         // 
         // FrmGuessNumber
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(296, 149);
         this.Controls.Add(this.btnNewGame);
         this.Controls.Add(this.btnEnter);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.lblResultLabel);
         this.Controls.Add(this.txtGuessNumber);
         this.Controls.Add(this.lblGuessNumber);
         this.Controls.Add(this.lblQuestion);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmGuessNumber";
         this.Text = "Guess the Number";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmGuessNumber() );
      }

   } // end class FrmGuessNumber
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/