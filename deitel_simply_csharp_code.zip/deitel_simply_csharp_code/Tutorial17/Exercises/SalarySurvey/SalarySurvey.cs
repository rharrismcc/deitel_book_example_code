using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SalarySurvey
{
   /// <summary>
   /// Summary description for FrmSalarySurvey.
   /// </summary>
   public class FrmSalarySurvey : System.Windows.Forms.Form
   {
      // Label and TextBox to input sales for an employee
      private System.Windows.Forms.Label lblInputSales;
      private System.Windows.Forms.TextBox txtInputSales;

      // Button to calculate an employee's salary
      private System.Windows.Forms.Button btnCalculate;

      // Labels to display an employee's salary
      private System.Windows.Forms.Label lblTotalSalaryLabel;
      private System.Windows.Forms.Label lblTotalSalary;

      // Button to display number of employees who have
      // salaries in various ranges
      private System.Windows.Forms.Button btnShowTotals;

      // Label and ListBox to display number of employees who have
      // salaries in various ranges
      private System.Windows.Forms.Label lblSurveyResults;
      private System.Windows.Forms.ListBox lstSalaryTotals;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmSalarySurvey()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblInputSales = new System.Windows.Forms.Label();
         this.txtInputSales = new System.Windows.Forms.TextBox();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.lblTotalSalaryLabel = new System.Windows.Forms.Label();
         this.lblTotalSalary = new System.Windows.Forms.Label();
         this.btnShowTotals = new System.Windows.Forms.Button();
         this.lblSurveyResults = new System.Windows.Forms.Label();
         this.lstSalaryTotals = new System.Windows.Forms.ListBox();
         this.SuspendLayout();
         // 
         // lblInputSales
         // 
         this.lblInputSales.Location = new System.Drawing.Point(16, 16);
         this.lblInputSales.Name = "lblInputSales";
         this.lblInputSales.Size = new System.Drawing.Size(64, 21);
         this.lblInputSales.TabIndex = 1;
         this.lblInputSales.Text = "Enter sales:";
         this.lblInputSales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtInputSales
         // 
         this.txtInputSales.Location = new System.Drawing.Point(88, 16);
         this.txtInputSales.Name = "txtInputSales";
         this.txtInputSales.Size = new System.Drawing.Size(72, 21);
         this.txtInputSales.TabIndex = 2;
         this.txtInputSales.Text = "";
         this.txtInputSales.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(40, 56);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(88, 23);
         this.btnCalculate.TabIndex = 3;
         this.btnCalculate.Text = "Calculate";
         // 
         // lblTotalSalaryLabel
         // 
         this.lblTotalSalaryLabel.Location = new System.Drawing.Point(16, 96);
         this.lblTotalSalaryLabel.Name = "lblTotalSalaryLabel";
         this.lblTotalSalaryLabel.Size = new System.Drawing.Size(68, 21);
         this.lblTotalSalaryLabel.TabIndex = 5;
         this.lblTotalSalaryLabel.Text = "Total salary:";
         this.lblTotalSalaryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotalSalary
         // 
         this.lblTotalSalary.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalSalary.Location = new System.Drawing.Point(88, 96);
         this.lblTotalSalary.Name = "lblTotalSalary";
         this.lblTotalSalary.Size = new System.Drawing.Size(72, 21);
         this.lblTotalSalary.TabIndex = 6;
         this.lblTotalSalary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnShowTotals
         // 
         this.btnShowTotals.Location = new System.Drawing.Point(40, 136);
         this.btnShowTotals.Name = "btnShowTotals";
         this.btnShowTotals.Size = new System.Drawing.Size(88, 23);
         this.btnShowTotals.TabIndex = 7;
         this.btnShowTotals.Text = "Show Totals";
         // 
         // lblSurveyResults
         // 
         this.lblSurveyResults.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
         this.lblSurveyResults.Location = new System.Drawing.Point(24, 176);
         this.lblSurveyResults.Name = "lblSurveyResults";
         this.lblSurveyResults.Size = new System.Drawing.Size(100, 16);
         this.lblSurveyResults.TabIndex = 9;
         this.lblSurveyResults.Text = "Survey results:";
         this.lblSurveyResults.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lstSalaryTotals
         // 
         this.lstSalaryTotals.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lstSalaryTotals.Location = new System.Drawing.Point(24, 192);
         this.lstSalaryTotals.Name = "lstSalaryTotals";
         this.lstSalaryTotals.Size = new System.Drawing.Size(128, 147);
         this.lstSalaryTotals.TabIndex = 10;
         // 
         // FrmSalarySurvey
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(176, 357);
         this.Controls.Add(this.lstSalaryTotals);
         this.Controls.Add(this.lblSurveyResults);
         this.Controls.Add(this.btnShowTotals);
         this.Controls.Add(this.lblTotalSalary);
         this.Controls.Add(this.lblTotalSalaryLabel);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.txtInputSales);
         this.Controls.Add(this.lblInputSales);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmSalarySurvey";
         this.Text = "Salary Survey";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmSalarySurvey() );
      }

   } // end class FrmSalarySurvey
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
