using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace StudentGrades
{
   /// <summary>
   /// Summary description for FrmStudentGrades.
   /// </summary>
   public class FrmStudentGrades : System.Windows.Forms.Form
   {
      // GroupBox to input grades
      private System.Windows.Forms.GroupBox fraInputGrade;

      // Label and TextBox to input a student name
      private System.Windows.Forms.Label lblInputName;
      private System.Windows.Forms.TextBox txtName;

      // Labels and TextBoxes to enter three test scores
      private System.Windows.Forms.Label lblTest1;
      private System.Windows.Forms.TextBox txtTest1;
      private System.Windows.Forms.Label lblTest2;
      private System.Windows.Forms.TextBox txtTest2;
      private System.Windows.Forms.Label lblTest3;
      private System.Windows.Forms.TextBox txtTest3;

      // Button to submit a student's grades
      private System.Windows.Forms.Button btnSubmit;

      // GroupBox with RadioButtons to display grades
      // numerically or as letters
      private System.Windows.Forms.GroupBox fraView;
      private System.Windows.Forms.RadioButton radNumeric;
      private System.Windows.Forms.RadioButton radLetter;

      // ListBox to display the students and their grades
      private System.Windows.Forms.ListBox lstNames;

      // Labels to display the class average
      private System.Windows.Forms.Label lblClassAverage;
      private System.Windows.Forms.Label lblClassOutput;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // counter for number of grades in array
      int m_intStudentCount = 0;

      // array of students and test averages
      string[,] m_strStudents = new string[ 10, 2 ];

      public FrmStudentGrades()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.fraInputGrade = new System.Windows.Forms.GroupBox();
         this.btnSubmit = new System.Windows.Forms.Button();
         this.lblTest3 = new System.Windows.Forms.Label();
         this.txtTest3 = new System.Windows.Forms.TextBox();
         this.lblTest2 = new System.Windows.Forms.Label();
         this.lblTest1 = new System.Windows.Forms.Label();
         this.lblInputName = new System.Windows.Forms.Label();
         this.txtTest1 = new System.Windows.Forms.TextBox();
         this.txtName = new System.Windows.Forms.TextBox();
         this.txtTest2 = new System.Windows.Forms.TextBox();
         this.lstNames = new System.Windows.Forms.ListBox();
         this.lblClassAverage = new System.Windows.Forms.Label();
         this.lblClassOutput = new System.Windows.Forms.Label();
         this.fraView = new System.Windows.Forms.GroupBox();
         this.radNumeric = new System.Windows.Forms.RadioButton();
         this.radLetter = new System.Windows.Forms.RadioButton();
         this.fraInputGrade.SuspendLayout();
         this.fraView.SuspendLayout();
         this.SuspendLayout();
         // 
         // fraInputGrade
         // 
         this.fraInputGrade.Controls.Add(this.btnSubmit);
         this.fraInputGrade.Controls.Add(this.lblTest3);
         this.fraInputGrade.Controls.Add(this.txtTest3);
         this.fraInputGrade.Controls.Add(this.lblTest2);
         this.fraInputGrade.Controls.Add(this.lblTest1);
         this.fraInputGrade.Controls.Add(this.lblInputName);
         this.fraInputGrade.Controls.Add(this.txtTest1);
         this.fraInputGrade.Controls.Add(this.txtName);
         this.fraInputGrade.Controls.Add(this.txtTest2);
         this.fraInputGrade.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.fraInputGrade.Location = new System.Drawing.Point(16, 16);
         this.fraInputGrade.Name = "fraInputGrade";
         this.fraInputGrade.Size = new System.Drawing.Size(248, 179);
         this.fraInputGrade.TabIndex = 13;
         this.fraInputGrade.TabStop = false;
         this.fraInputGrade.Text = "Input Grade";
         // 
         // btnSubmit
         // 
         this.btnSubmit.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnSubmit.Location = new System.Drawing.Point(144, 144);
         this.btnSubmit.Name = "btnSubmit";
         this.btnSubmit.Size = new System.Drawing.Size(88, 24);
         this.btnSubmit.TabIndex = 12;
         this.btnSubmit.Text = "Submit Grades";
         this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
         // 
         // lblTest3
         // 
         this.lblTest3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblTest3.Location = new System.Drawing.Point(8, 112);
         this.lblTest3.Name = "lblTest3";
         this.lblTest3.Size = new System.Drawing.Size(60, 23);
         this.lblTest3.TabIndex = 9;
         this.lblTest3.Text = "Test 3:";
         this.lblTest3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtTest3
         // 
         this.txtTest3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtTest3.Location = new System.Drawing.Point(176, 112);
         this.txtTest3.Name = "txtTest3";
         this.txtTest3.Size = new System.Drawing.Size(56, 21);
         this.txtTest3.TabIndex = 6;
         this.txtTest3.Text = "";
         this.txtTest3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblTest2
         // 
         this.lblTest2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblTest2.Location = new System.Drawing.Point(8, 88);
         this.lblTest2.Name = "lblTest2";
         this.lblTest2.Size = new System.Drawing.Size(60, 23);
         this.lblTest2.TabIndex = 4;
         this.lblTest2.Text = "Test 2:";
         this.lblTest2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTest1
         // 
         this.lblTest1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblTest1.Location = new System.Drawing.Point(8, 64);
         this.lblTest1.Name = "lblTest1";
         this.lblTest1.Size = new System.Drawing.Size(60, 23);
         this.lblTest1.TabIndex = 2;
         this.lblTest1.Text = "Test 1:";
         this.lblTest1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblInputName
         // 
         this.lblInputName.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblInputName.Location = new System.Drawing.Point(8, 32);
         this.lblInputName.Name = "lblInputName";
         this.lblInputName.Size = new System.Drawing.Size(80, 23);
         this.lblInputName.TabIndex = 1;
         this.lblInputName.Text = "Student name:";
         this.lblInputName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtTest1
         // 
         this.txtTest1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtTest1.Location = new System.Drawing.Point(176, 64);
         this.txtTest1.Name = "txtTest1";
         this.txtTest1.Size = new System.Drawing.Size(56, 21);
         this.txtTest1.TabIndex = 3;
         this.txtTest1.Text = "";
         this.txtTest1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtName
         // 
         this.txtName.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtName.Location = new System.Drawing.Point(104, 32);
         this.txtName.Name = "txtName";
         this.txtName.Size = new System.Drawing.Size(128, 21);
         this.txtName.TabIndex = 0;
         this.txtName.Text = "";
         this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtTest2
         // 
         this.txtTest2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtTest2.Location = new System.Drawing.Point(176, 88);
         this.txtTest2.Name = "txtTest2";
         this.txtTest2.Size = new System.Drawing.Size(56, 21);
         this.txtTest2.TabIndex = 5;
         this.txtTest2.Text = "";
         this.txtTest2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lstNames
         // 
         this.lstNames.Location = new System.Drawing.Point(280, 48);
         this.lstNames.Name = "lstNames";
         this.lstNames.Size = new System.Drawing.Size(192, 134);
         this.lstNames.TabIndex = 21;
         // 
         // lblClassAverage
         // 
         this.lblClassAverage.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblClassAverage.Location = new System.Drawing.Point(280, 216);
         this.lblClassAverage.Name = "lblClassAverage";
         this.lblClassAverage.Size = new System.Drawing.Size(96, 23);
         this.lblClassAverage.TabIndex = 22;
         this.lblClassAverage.Text = "Class average:";
         this.lblClassAverage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblClassOutput
         // 
         this.lblClassOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblClassOutput.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblClassOutput.Location = new System.Drawing.Point(416, 216);
         this.lblClassOutput.Name = "lblClassOutput";
         this.lblClassOutput.Size = new System.Drawing.Size(56, 23);
         this.lblClassOutput.TabIndex = 23;
         this.lblClassOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // radNumeric
         // 
         this.radNumeric.Checked = true;
         this.radNumeric.Location = new System.Drawing.Point(32, 24);
         this.radNumeric.Name = "radNumeric";
         this.radNumeric.Size = new System.Drawing.Size(80, 24);
         this.radNumeric.TabIndex = 24;
         this.radNumeric.TabStop = true;
         this.radNumeric.Text = "Numeric";
         this.radNumeric.CheckedChanged += new System.EventHandler(this.radNumeric_CheckedChanged);
         // 
         // radLetter
         // 
         this.radLetter.Location = new System.Drawing.Point(136, 24);
         this.radLetter.Name = "radLetter";
         this.radLetter.Size = new System.Drawing.Size(80, 24);
         this.radLetter.TabIndex = 25;
         this.radLetter.Text = "Letter";
         this.radLetter.CheckedChanged += new System.EventHandler(this.radLetter_CheckedChanged);
         // 
         // fraView
         // 
         this.fraView.Controls.Add(this.radNumeric);
         this.fraView.Controls.Add(this.radLetter);
         this.fraView.Location = new System.Drawing.Point(16, 200);
         this.fraView.Name = "fraView";
         this.fraView.Size = new System.Drawing.Size(248, 56);
         this.fraView.TabIndex = 26;
         this.fraView.TabStop = false;
         this.fraView.Text = "View";
         // 
         // FrmStudentGrades
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(488, 269);
         this.Controls.Add(this.lblClassOutput);
         this.Controls.Add(this.lblClassAverage);
         this.Controls.Add(this.fraInputGrade);
         this.Controls.Add(this.lstNames);
         this.Controls.Add(this.fraView);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmStudentGrades";
         this.Text = "Student Grades";
         this.fraInputGrade.ResumeLayout(false);
         this.fraView.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmStudentGrades() );
      }

      // convert a number to a letter grade
      string ConvertToLetterGrade( double grade )
      {
         if ( grade >= 90 )
         {
            return "A";
         }
         else if ( grade >= 80 )
         {
            return "B";
         }
         else if ( grade >= 70 )
         {
            return "C";
         }
         else if ( grade >= 60 )
         {
            return "D";
         }
         else
         {
            return "F";
         }
   
      } // end method ConvertToLetterGrade

      // returns student average
      double StudentAverage( 
         double dblTest1, double dblTest2, double dblTest3 )
      {
         // return the average of 3 test scores
         return ( ( dblTest1 + dblTest2 + dblTest3 ) / 3 );

      } // end method StudentAverage
      
      // handles Submit Button's Click event
      private void btnSubmit_Click( 
         object sender, System.EventArgs e )
      {
         // extract user input
         double dblTest1 = Double.Parse( txtTest1.Text );
         double dblTest2 = Double.Parse( txtTest2.Text );
         double dblTest3 = Double.Parse( txtTest3.Text );

         // add student name and test average
         // to the array of students
         m_strStudents[ m_intStudentCount, 0 ] = txtName.Text;
         m_strStudents[ m_intStudentCount, 1 ] =
            String.Format( "{0:F}",
            StudentAverage( dblTest1, dblTest2, dblTest3 ) );

         // increment grade counter
         m_intStudentCount++;

         // display grades in ListBox
         if ( radNumeric.Checked == true )
         {
            DisplayNumericGrades();
         }
         else
         {
            DisplayLetterGrades();
         }

         // clear TextBoxes for new data
         txtName.Text = "";
         txtTest1.Text = "";
         txtTest2.Text = "";
         txtTest3.Text = "";
      
         // maximum of ten students
         if ( m_intStudentCount == 10 )
         {
            btnSubmit.Enabled = false;
         }

      } // end method btnSubmit_Click
      
      // display student averages as numbers
      void DisplayNumericGrades()
      {
         // clear ListBox
         lstNames.Items.Clear();

         double dblTotal = 0; // total test score

         // iterate through array of students
         for ( int intCounter = 0; intCounter < m_intStudentCount; 
            intCounter++ )
         {
            // display student name and average in ListBox
            lstNames.Items.Add( m_strStudents[ intCounter, 0 ] +
               "\t" + m_strStudents[ intCounter, 1 ] );

            // add current student's average to class total
            dblTotal += Double.Parse(
               m_strStudents[ intCounter, 1 ] );
         }

         // display class average
         lblClassOutput.Text = String.Format( "{0:F}",
            dblTotal / m_intStudentCount );

      } // end method DisplayNumericGrades

      // display student averages as letters
      void DisplayLetterGrades()
      {
         // clear ListBox
         lstNames.Items.Clear();

         double dblTotal = 0; // total test score

         // iterate through array of students
         for ( int intCounter = 0; intCounter < m_intStudentCount; 
            intCounter++ )
         {
            // display student name and average in ListBox
            lstNames.Items.Add( m_strStudents[ intCounter, 0 ] +
               "\t" + ConvertToLetterGrade( Double.Parse(
               m_strStudents[ intCounter, 1 ] ) ) );

            // add current student's average to class total
            dblTotal += Double.Parse(
               m_strStudents[ intCounter, 1 ] );
         }

         // display class average
         lblClassOutput.Text = String.Format( "{0:F}",
            ConvertToLetterGrade( dblTotal / m_intStudentCount ) );

      } // end method DisplayLetterGrades

      // user selected numeric display
      private void radNumeric_CheckedChanged( 
         object sender, System.EventArgs e )
      {
         DisplayNumericGrades();

      } // end method radNumeric_CheckedChanged

      // user selected letter display
      private void radLetter_CheckedChanged(
         object sender, System.EventArgs e )
      {
         DisplayLetterGrades();

      } // end method radLetter_CheckedChanged

   } // end class FrmStudentGrades
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/