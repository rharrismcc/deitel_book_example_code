using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace LotteryPicker
{
   /// <summary>
   /// Summary description for FrmLotteryPicker.
   /// </summary>
   public class FrmLotteryPicker : System.Windows.Forms.Form
   {
      // Labels to display the three-number lottery numbers
      private System.Windows.Forms.Label lblThree;
      private System.Windows.Forms.Label lblOutput3;

      // Labels to display the four-number lottery numbers
      private System.Windows.Forms.Label lblFour;
      private System.Windows.Forms.Label lblOutput4;

      // Labels to display the five-number lottery numbers
      private System.Windows.Forms.Label lblFive;
      private System.Windows.Forms.Label lblOutput5;

      // Labels to display the five-number-plus-1 lottery numbers
      private System.Windows.Forms.Label lblFivePlusOne;
      private System.Windows.Forms.Label lblOutput5Plus1;
      private System.Windows.Forms.Label lblOutputExtra1;

      // Button to generate a set of lottery numbers
      private System.Windows.Forms.Button btnGenerate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      Random m_objRandom = new Random();

      public FrmLotteryPicker()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblThree = new System.Windows.Forms.Label();
         this.lblOutput3 = new System.Windows.Forms.Label();
         this.lblFour = new System.Windows.Forms.Label();
         this.lblOutput4 = new System.Windows.Forms.Label();
         this.lblFive = new System.Windows.Forms.Label();
         this.lblOutput5 = new System.Windows.Forms.Label();
         this.lblFivePlusOne = new System.Windows.Forms.Label();
         this.lblOutput5Plus1 = new System.Windows.Forms.Label();
         this.lblOutputExtra1 = new System.Windows.Forms.Label();
         this.btnGenerate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblThree
         // 
         this.lblThree.Location = new System.Drawing.Point(16, 24);
         this.lblThree.Name = "lblThree";
         this.lblThree.Size = new System.Drawing.Size(120, 16);
         this.lblThree.TabIndex = 3;
         this.lblThree.Text = "Three number lottery:";
         this.lblThree.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput3
         // 
         this.lblOutput3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput3.Location = new System.Drawing.Point(152, 16);
         this.lblOutput3.Name = "lblOutput3";
         this.lblOutput3.Size = new System.Drawing.Size(120, 23);
         this.lblOutput3.TabIndex = 10;
         this.lblOutput3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblFour
         // 
         this.lblFour.Location = new System.Drawing.Point(16, 56);
         this.lblFour.Name = "lblFour";
         this.lblFour.Size = new System.Drawing.Size(112, 16);
         this.lblFour.TabIndex = 11;
         this.lblFour.Text = "Four number lottery:";
         this.lblFour.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput4
         // 
         this.lblOutput4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput4.Location = new System.Drawing.Point(152, 48);
         this.lblOutput4.Name = "lblOutput4";
         this.lblOutput4.Size = new System.Drawing.Size(120, 23);
         this.lblOutput4.TabIndex = 12;
         this.lblOutput4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblFive
         // 
         this.lblFive.Location = new System.Drawing.Point(16, 88);
         this.lblFive.Name = "lblFive";
         this.lblFive.Size = new System.Drawing.Size(112, 16);
         this.lblFive.TabIndex = 13;
         this.lblFive.Text = "Five number lottery:";
         this.lblFive.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput5
         // 
         this.lblOutput5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput5.Location = new System.Drawing.Point(152, 80);
         this.lblOutput5.Name = "lblOutput5";
         this.lblOutput5.Size = new System.Drawing.Size(120, 23);
         this.lblOutput5.TabIndex = 14;
         this.lblOutput5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblFivePlusOne
         // 
         this.lblFivePlusOne.Location = new System.Drawing.Point(16, 120);
         this.lblFivePlusOne.Name = "lblFivePlusOne";
         this.lblFivePlusOne.Size = new System.Drawing.Size(128, 16);
         this.lblFivePlusOne.TabIndex = 15;
         this.lblFivePlusOne.Text = "Five number + 1 lottery:";
         this.lblFivePlusOne.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblOutput5Plus1
         // 
         this.lblOutput5Plus1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput5Plus1.Location = new System.Drawing.Point(152, 112);
         this.lblOutput5Plus1.Name = "lblOutput5Plus1";
         this.lblOutput5Plus1.Size = new System.Drawing.Size(88, 23);
         this.lblOutput5Plus1.TabIndex = 16;
         this.lblOutput5Plus1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblOutputExtra1
         // 
         this.lblOutputExtra1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutputExtra1.ForeColor = System.Drawing.Color.Red;
         this.lblOutputExtra1.Location = new System.Drawing.Point(248, 112);
         this.lblOutputExtra1.Name = "lblOutputExtra1";
         this.lblOutputExtra1.Size = new System.Drawing.Size(24, 23);
         this.lblOutputExtra1.TabIndex = 17;
         this.lblOutputExtra1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnGenerate
         // 
         this.btnGenerate.Location = new System.Drawing.Point(176, 152);
         this.btnGenerate.Name = "btnGenerate";
         this.btnGenerate.Size = new System.Drawing.Size(96, 24);
         this.btnGenerate.TabIndex = 18;
         this.btnGenerate.Text = "Generate";
         this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
         // 
         // FrmLotteryPicker
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(288, 189);
         this.Controls.Add(this.btnGenerate);
         this.Controls.Add(this.lblOutputExtra1);
         this.Controls.Add(this.lblOutput5Plus1);
         this.Controls.Add(this.lblFivePlusOne);
         this.Controls.Add(this.lblOutput5);
         this.Controls.Add(this.lblFive);
         this.Controls.Add(this.lblOutput4);
         this.Controls.Add(this.lblFour);
         this.Controls.Add(this.lblOutput3);
         this.Controls.Add(this.lblThree);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmLotteryPicker";
         this.Text = "Lottery Picker";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmLotteryPicker() );
      }

      // display random lottery numbers
      private void btnGenerate_Click( 
         object sender, System.EventArgs e )
      {
         // generate three numbers
         lblOutput3.Text = Generate( 0, 10 ) + " " +
            Generate( 0, 10 ) + " " + Generate( 0, 10 );

         // generate four numbers
         lblOutput4.Text = Generate( 0, 10 ) + " " +
            Generate( 0, 10 ) + " " + Generate( 0, 10 ) + " "
            + Generate( 0, 10 );

         // generate five numbers
         lblOutput5.Text = Generate( 1, 40 ) + " " +
            Generate( 1, 40 ) + " " + Generate( 1, 40 ) +
            " " + Generate( 1, 40 ) + " " + Generate( 1, 40 );

         // generate five plus one numbers
         lblOutput5Plus1.Text = Generate( 1, 50 ) + " " +
            Generate( 1, 50 ) + " " + Generate( 1, 50 ) + " " +
            Generate( 1, 50 ) + " " + Generate( 1, 50 );

         // generate extra number
         lblOutputExtra1.Text = Generate( 1, 43 );
      
      } // end method btnGenerate_Click

      // generate random numbers
      string Generate( int intLow, int intHigh )
      {
         return String.Format( "{0:D2}",
            m_objRandom.Next( intLow, intHigh ) );

      } // end method Generate

   } // end class FrmLotteryPicker
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel + Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/