using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace FoodSurvey
{
	/// <summary>
	/// Summary description for FrmFoodSurvey.
	/// </summary>
	public class FrmFoodSurvey : System.Windows.Forms.Form
	{
      // GroupBox for voting controls
      private System.Windows.Forms.GroupBox fraVote;

      // ComboBox to give choice of foods
      private System.Windows.Forms.ComboBox cboFoods;

      // Button to add vote to results
      private System.Windows.Forms.Button btnAdd;

      // GroupBox with ListBox to display results
      private System.Windows.Forms.GroupBox fraResults;
      private System.Windows.Forms.ListBox lstResults;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

      // string array for food choices
      string[] m_strFoods = { "Cheese Pizza", "Hamburger",
                              "Fish Sticks", "Mystery Meat" };

		public FrmFoodSurvey()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.cboFoods = new System.Windows.Forms.ComboBox();
         this.btnAdd = new System.Windows.Forms.Button();
         this.lstResults = new System.Windows.Forms.ListBox();
         this.fraVote = new System.Windows.Forms.GroupBox();
         this.fraResults = new System.Windows.Forms.GroupBox();
         this.fraVote.SuspendLayout();
         this.fraResults.SuspendLayout();
         this.SuspendLayout();
         // 
         // cboFoods
         // 
         this.cboFoods.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboFoods.Location = new System.Drawing.Point(16, 24);
         this.cboFoods.MaxDropDownItems = 4;
         this.cboFoods.Name = "cboFoods";
         this.cboFoods.TabIndex = 0;
         // 
         // btnAdd
         // 
         this.btnAdd.Location = new System.Drawing.Point(312, 24);
         this.btnAdd.Name = "btnAdd";
         this.btnAdd.Size = new System.Drawing.Size(72, 23);
         this.btnAdd.TabIndex = 3;
         this.btnAdd.Text = "Add";
         // 
         // lstResults
         // 
         this.lstResults.Location = new System.Drawing.Point(16, 24);
         this.lstResults.Name = "lstResults";
         this.lstResults.Size = new System.Drawing.Size(368, 82);
         this.lstResults.TabIndex = 4;
         // 
         // fraVote
         // 
         this.fraVote.Controls.Add(this.btnAdd);
         this.fraVote.Controls.Add(this.cboFoods);
         this.fraVote.Location = new System.Drawing.Point(16, 8);
         this.fraVote.Name = "fraVote";
         this.fraVote.Size = new System.Drawing.Size(408, 64);
         this.fraVote.TabIndex = 5;
         this.fraVote.TabStop = false;
         this.fraVote.Text = "Vote";
         // 
         // fraResults
         // 
         this.fraResults.Controls.Add(this.lstResults);
         this.fraResults.Location = new System.Drawing.Point(16, 88);
         this.fraResults.Name = "fraResults";
         this.fraResults.Size = new System.Drawing.Size(408, 120);
         this.fraResults.TabIndex = 6;
         this.fraResults.TabStop = false;
         this.fraResults.Text = "Results";
         // 
         // FrmFoodSurvey
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(448, 221);
         this.Controls.Add(this.fraResults);
         this.Controls.Add(this.fraVote);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmFoodSurvey";
         this.Text = "Food Survey";
         this.Load += new System.EventHandler(this.FrmFoodSurvey_Load);
         this.fraVote.ResumeLayout(false);
         this.fraResults.ResumeLayout(false);
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run( new FrmFoodSurvey() );
		}

      // handles Form's Load event
      private void FrmFoodSurvey_Load( 
         object sender, System.EventArgs e )
      {
         // display foods in ComboBox
         cboFoods.DataSource = m_strFoods;

      }

	} // end class FrmFoodSurvey
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/