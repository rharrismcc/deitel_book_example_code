using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ProfitReport
{
	/// <summary>
	/// Summary description for FrmProfitReport.
	/// </summary>
	public class FrmProfitReport : System.Windows.Forms.Form
	{
      // GroupBox to input and item's profits
      private System.Windows.Forms.GroupBox fraInput;
      
      // Label and TextBox to input item
      private System.Windows.Forms.Label lblItem;
      private System.Windows.Forms.TextBox txtItem;

      // Labels and TextBoxes to input daily profits
      private System.Windows.Forms.Label lblMonday;
      private System.Windows.Forms.TextBox txtMonday;
      private System.Windows.Forms.Label lblTuesday;
      private System.Windows.Forms.TextBox txtTuesday;
      private System.Windows.Forms.Label lblWednesday;
      private System.Windows.Forms.TextBox txtWednesday;
      private System.Windows.Forms.Label lblThursday;
      private System.Windows.Forms.TextBox txtThursday;
      private System.Windows.Forms.Label lblFriday;
      private System.Windows.Forms.TextBox txtFriday;

      // Button to submit an item's daily profits
      private System.Windows.Forms.Button btnSubmit;

      // Label and ListBox to display itemized profits
      private System.Windows.Forms.Label lblItemizedProfits;
      private System.Windows.Forms.ListBox lstItemizedProfits;

      // Labels to display total profits
      private System.Windows.Forms.Label lblGrossProfits;
      private System.Windows.Forms.Label lblOutput;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

      // initialize number of items to zero
      int m_intItemCount = 0;

      // one-dimensional array to store names of items
      string[] m_strItemNames = new string[ 10 ];

		public FrmProfitReport()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.fraInput = new System.Windows.Forms.GroupBox();
         this.txtThursday = new System.Windows.Forms.TextBox();
         this.lblThursday = new System.Windows.Forms.Label();
         this.txtWednesday = new System.Windows.Forms.TextBox();
         this.lblWednesday = new System.Windows.Forms.Label();
         this.txtFriday = new System.Windows.Forms.TextBox();
         this.lblFriday = new System.Windows.Forms.Label();
         this.txtTuesday = new System.Windows.Forms.TextBox();
         this.lblTuesday = new System.Windows.Forms.Label();
         this.btnSubmit = new System.Windows.Forms.Button();
         this.txtMonday = new System.Windows.Forms.TextBox();
         this.txtItem = new System.Windows.Forms.TextBox();
         this.lblMonday = new System.Windows.Forms.Label();
         this.lblItem = new System.Windows.Forms.Label();
         this.lblItemizedProfits = new System.Windows.Forms.Label();
         this.lstItemizedProfits = new System.Windows.Forms.ListBox();
         this.lblGrossProfits = new System.Windows.Forms.Label();
         this.lblOutput = new System.Windows.Forms.Label();
         this.fraInput.SuspendLayout();
         this.SuspendLayout();
         // 
         // fraInput
         // 
         this.fraInput.Controls.Add(this.txtThursday);
         this.fraInput.Controls.Add(this.lblThursday);
         this.fraInput.Controls.Add(this.txtWednesday);
         this.fraInput.Controls.Add(this.lblWednesday);
         this.fraInput.Controls.Add(this.txtFriday);
         this.fraInput.Controls.Add(this.lblFriday);
         this.fraInput.Controls.Add(this.txtTuesday);
         this.fraInput.Controls.Add(this.lblTuesday);
         this.fraInput.Controls.Add(this.btnSubmit);
         this.fraInput.Controls.Add(this.txtMonday);
         this.fraInput.Controls.Add(this.txtItem);
         this.fraInput.Controls.Add(this.lblMonday);
         this.fraInput.Controls.Add(this.lblItem);
         this.fraInput.Location = new System.Drawing.Point(16, 16);
         this.fraInput.Name = "fraInput";
         this.fraInput.Size = new System.Drawing.Size(200, 328);
         this.fraInput.TabIndex = 0;
         this.fraInput.TabStop = false;
         this.fraInput.Text = "Input Item";
         // 
         // txtThursday
         // 
         this.txtThursday.Location = new System.Drawing.Point(120, 176);
         this.txtThursday.Name = "txtThursday";
         this.txtThursday.Size = new System.Drawing.Size(64, 21);
         this.txtThursday.TabIndex = 4;
         this.txtThursday.Text = "";
         this.txtThursday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblThursday
         // 
         this.lblThursday.Location = new System.Drawing.Point(16, 176);
         this.lblThursday.Name = "lblThursday";
         this.lblThursday.Size = new System.Drawing.Size(80, 23);
         this.lblThursday.TabIndex = 19;
         this.lblThursday.Text = "Thursday:";
         this.lblThursday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtWednesday
         // 
         this.txtWednesday.Location = new System.Drawing.Point(120, 144);
         this.txtWednesday.Name = "txtWednesday";
         this.txtWednesday.Size = new System.Drawing.Size(64, 21);
         this.txtWednesday.TabIndex = 3;
         this.txtWednesday.Text = "";
         this.txtWednesday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblWednesday
         // 
         this.lblWednesday.Location = new System.Drawing.Point(16, 144);
         this.lblWednesday.Name = "lblWednesday";
         this.lblWednesday.Size = new System.Drawing.Size(80, 23);
         this.lblWednesday.TabIndex = 17;
         this.lblWednesday.Text = "Wednesday:";
         this.lblWednesday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtFriday
         // 
         this.txtFriday.Location = new System.Drawing.Point(120, 208);
         this.txtFriday.Name = "txtFriday";
         this.txtFriday.Size = new System.Drawing.Size(64, 21);
         this.txtFriday.TabIndex = 5;
         this.txtFriday.Text = "";
         this.txtFriday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblFriday
         // 
         this.lblFriday.Location = new System.Drawing.Point(16, 208);
         this.lblFriday.Name = "lblFriday";
         this.lblFriday.Size = new System.Drawing.Size(80, 23);
         this.lblFriday.TabIndex = 15;
         this.lblFriday.Text = "Friday:";
         this.lblFriday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtTuesday
         // 
         this.txtTuesday.Location = new System.Drawing.Point(120, 112);
         this.txtTuesday.Name = "txtTuesday";
         this.txtTuesday.Size = new System.Drawing.Size(64, 21);
         this.txtTuesday.TabIndex = 2;
         this.txtTuesday.Text = "";
         this.txtTuesday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblTuesday
         // 
         this.lblTuesday.Location = new System.Drawing.Point(16, 112);
         this.lblTuesday.Name = "lblTuesday";
         this.lblTuesday.Size = new System.Drawing.Size(80, 23);
         this.lblTuesday.TabIndex = 13;
         this.lblTuesday.Text = "Tuesday:";
         this.lblTuesday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // btnSubmit
         // 
         this.btnSubmit.Location = new System.Drawing.Point(80, 288);
         this.btnSubmit.Name = "btnSubmit";
         this.btnSubmit.Size = new System.Drawing.Size(104, 23);
         this.btnSubmit.TabIndex = 6;
         this.btnSubmit.Text = "Submit Item";
         this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
         // 
         // txtMonday
         // 
         this.txtMonday.Location = new System.Drawing.Point(120, 80);
         this.txtMonday.Name = "txtMonday";
         this.txtMonday.Size = new System.Drawing.Size(64, 21);
         this.txtMonday.TabIndex = 1;
         this.txtMonday.Text = "";
         this.txtMonday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtItem
         // 
         this.txtItem.Location = new System.Drawing.Point(80, 32);
         this.txtItem.Name = "txtItem";
         this.txtItem.Size = new System.Drawing.Size(104, 21);
         this.txtItem.TabIndex = 0;
         this.txtItem.Text = "";
         this.txtItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblMonday
         // 
         this.lblMonday.Location = new System.Drawing.Point(16, 80);
         this.lblMonday.Name = "lblMonday";
         this.lblMonday.Size = new System.Drawing.Size(80, 23);
         this.lblMonday.TabIndex = 1;
         this.lblMonday.Text = "Monday:";
         this.lblMonday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblItem
         // 
         this.lblItem.Location = new System.Drawing.Point(16, 32);
         this.lblItem.Name = "lblItem";
         this.lblItem.Size = new System.Drawing.Size(56, 23);
         this.lblItem.TabIndex = 0;
         this.lblItem.Text = "Item:";
         this.lblItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblItemizedProfits
         // 
         this.lblItemizedProfits.Location = new System.Drawing.Point(232, 24);
         this.lblItemizedProfits.Name = "lblItemizedProfits";
         this.lblItemizedProfits.TabIndex = 1;
         this.lblItemizedProfits.Text = "Itemized Profits:";
         this.lblItemizedProfits.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lstItemizedProfits
         // 
         this.lstItemizedProfits.HorizontalScrollbar = true;
         this.lstItemizedProfits.Location = new System.Drawing.Point(232, 56);
         this.lstItemizedProfits.Name = "lstItemizedProfits";
         this.lstItemizedProfits.Size = new System.Drawing.Size(400, 186);
         this.lstItemizedProfits.TabIndex = 2;
         // 
         // lblGrossProfits
         // 
         this.lblGrossProfits.Location = new System.Drawing.Point(464, 264);
         this.lblGrossProfits.Name = "lblGrossProfits";
         this.lblGrossProfits.Size = new System.Drawing.Size(80, 23);
         this.lblGrossProfits.TabIndex = 3;
         this.lblGrossProfits.Text = "Gross Profits:";
         this.lblGrossProfits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // lblOutput
         // 
         this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput.Location = new System.Drawing.Point(552, 264);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(80, 23);
         this.lblOutput.TabIndex = 4;
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // FrmProfitReport
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(648, 357);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.lblGrossProfits);
         this.Controls.Add(this.lstItemizedProfits);
         this.Controls.Add(this.lblItemizedProfits);
         this.Controls.Add(this.fraInput);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmProfitReport";
         this.Text = "Profit Report";
         this.fraInput.ResumeLayout(false);
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run( new FrmProfitReport() );
		}

      // handles Submit Item Button's Click event
      private void btnSubmit_Click( 
         object sender, System.EventArgs e )
      {
         DisplayProfits(); // display itemized profits
      
         // clear TextBoxes for new data
         txtItem.Text = "";
         txtMonday.Text = "";
         txtTuesday.Text = "";
         txtWednesday.Text = "";
         txtThursday.Text = "";
         txtFriday.Text = "";

         // if 10 or more items
         if ( m_intItemCount == 10 )
         {
            // disable btnSubmit
            btnSubmit.Enabled = false;
         }

      } // end method btnSubmit_Click

      // display profits by type and day of week
      void DisplayProfits()
      {
         // clear the ListBox
         lstItemizedProfits.Items.Clear();

         // add a header to the ListBox
         lstItemizedProfits.Items.Add( "Name\t\tMon.\t" +
            "Tue.\tWed.\tThu.\tFri.\tTotal" );

         decimal decWeekTotal = 0;  // initialize weekly total
         decimal decProfitsTotal = 0; // initialize total profits
         string strOutput;          // displays profits in ListBox

         // output the total profits
         lblOutput.Text = String.Format( "{0:C}", decProfitsTotal );

      } // end method DisplayProfits

	} // end class FrmProfitReport
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/