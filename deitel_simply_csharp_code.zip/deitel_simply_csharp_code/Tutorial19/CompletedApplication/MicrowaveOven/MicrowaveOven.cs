using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace MicrowaveOven
{
   /// <summary>
   /// Summary description for FrmMicrowaveOven.
   /// </summary>
   public class FrmMicrowaveOven : System.Windows.Forms.Form
   {
      // Panel for the microwave's window
      private System.Windows.Forms.Panel pnlWindow;

      // Panel for the microwave's buttons
      private System.Windows.Forms.Panel pnlControl;

      // Label and Timer for the microwave's timer display
      private System.Windows.Forms.Label lblDisplay;
      private System.Windows.Forms.Timer tmrClock;

      // Buttons of the microwave
      private System.Windows.Forms.Button btnOne;
      private System.Windows.Forms.Button btnTwo;
      private System.Windows.Forms.Button btnThree;
      private System.Windows.Forms.Button btnFour;
      private System.Windows.Forms.Button btnFive;
      private System.Windows.Forms.Button btnSix;
      private System.Windows.Forms.Button btnSeven;
      private System.Windows.Forms.Button btnEight;
      private System.Windows.Forms.Button btnNine;
      private System.Windows.Forms.Button btnZero;
      private System.Windows.Forms.Button btnStart;
      private System.Windows.Forms.Button btnClear;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components;

      // contains time entered as a string
      private string m_strTime = "";

      // contains time entered
      private Time m_objTime;

      public FrmMicrowaveOven()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.pnlControl = new System.Windows.Forms.Panel();
         this.btnClear = new System.Windows.Forms.Button();
         this.btnStart = new System.Windows.Forms.Button();
         this.btnZero = new System.Windows.Forms.Button();
         this.btnNine = new System.Windows.Forms.Button();
         this.btnEight = new System.Windows.Forms.Button();
         this.btnSeven = new System.Windows.Forms.Button();
         this.btnSix = new System.Windows.Forms.Button();
         this.btnFive = new System.Windows.Forms.Button();
         this.btnFour = new System.Windows.Forms.Button();
         this.btnThree = new System.Windows.Forms.Button();
         this.btnTwo = new System.Windows.Forms.Button();
         this.btnOne = new System.Windows.Forms.Button();
         this.lblDisplay = new System.Windows.Forms.Label();
         this.tmrClock = new System.Windows.Forms.Timer(this.components);
         this.pnlWindow = new System.Windows.Forms.Panel();
         this.pnlControl.SuspendLayout();
         this.SuspendLayout();
         // 
         // pnlControl
         // 
         this.pnlControl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.pnlControl.Controls.Add(this.btnClear);
         this.pnlControl.Controls.Add(this.btnStart);
         this.pnlControl.Controls.Add(this.btnZero);
         this.pnlControl.Controls.Add(this.btnNine);
         this.pnlControl.Controls.Add(this.btnEight);
         this.pnlControl.Controls.Add(this.btnSeven);
         this.pnlControl.Controls.Add(this.btnSix);
         this.pnlControl.Controls.Add(this.btnFive);
         this.pnlControl.Controls.Add(this.btnFour);
         this.pnlControl.Controls.Add(this.btnThree);
         this.pnlControl.Controls.Add(this.btnTwo);
         this.pnlControl.Controls.Add(this.btnOne);
         this.pnlControl.Controls.Add(this.lblDisplay);
         this.pnlControl.Location = new System.Drawing.Point(368, 16);
         this.pnlControl.Name = "pnlControl";
         this.pnlControl.Size = new System.Drawing.Size(152, 224);
         this.pnlControl.TabIndex = 0;
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(79, 187);
         this.btnClear.Name = "btnClear";
         this.btnClear.Size = new System.Drawing.Size(64, 24);
         this.btnClear.TabIndex = 13;
         this.btnClear.Text = "Clear";
         this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
         // 
         // btnStart
         // 
         this.btnStart.Location = new System.Drawing.Point(7, 187);
         this.btnStart.Name = "btnStart";
         this.btnStart.Size = new System.Drawing.Size(64, 24);
         this.btnStart.TabIndex = 12;
         this.btnStart.Text = "Start";
         this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
         // 
         // btnZero
         // 
         this.btnZero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnZero.Location = new System.Drawing.Point(63, 144);
         this.btnZero.Name = "btnZero";
         this.btnZero.Size = new System.Drawing.Size(24, 24);
         this.btnZero.TabIndex = 11;
         this.btnZero.Text = "0";
         this.btnZero.Click += new System.EventHandler(this.btnZero_Click);
         // 
         // btnNine
         // 
         this.btnNine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnNine.Location = new System.Drawing.Point(86, 121);
         this.btnNine.Name = "btnNine";
         this.btnNine.Size = new System.Drawing.Size(24, 24);
         this.btnNine.TabIndex = 10;
         this.btnNine.Text = "9";
         this.btnNine.Click += new System.EventHandler(this.btnNine_Click);
         // 
         // btnEight
         // 
         this.btnEight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnEight.Location = new System.Drawing.Point(63, 121);
         this.btnEight.Name = "btnEight";
         this.btnEight.Size = new System.Drawing.Size(24, 24);
         this.btnEight.TabIndex = 9;
         this.btnEight.Text = "8";
         this.btnEight.Click += new System.EventHandler(this.btnEight_Click);
         // 
         // btnSeven
         // 
         this.btnSeven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnSeven.Location = new System.Drawing.Point(40, 121);
         this.btnSeven.Name = "btnSeven";
         this.btnSeven.Size = new System.Drawing.Size(24, 24);
         this.btnSeven.TabIndex = 8;
         this.btnSeven.Text = "7";
         this.btnSeven.Click += new System.EventHandler(this.btnSeven_Click);
         // 
         // btnSix
         // 
         this.btnSix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnSix.Location = new System.Drawing.Point(86, 98);
         this.btnSix.Name = "btnSix";
         this.btnSix.Size = new System.Drawing.Size(24, 24);
         this.btnSix.TabIndex = 7;
         this.btnSix.Text = "6";
         this.btnSix.Click += new System.EventHandler(this.btnSix_Click);
         // 
         // btnFive
         // 
         this.btnFive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnFive.Location = new System.Drawing.Point(63, 98);
         this.btnFive.Name = "btnFive";
         this.btnFive.Size = new System.Drawing.Size(24, 24);
         this.btnFive.TabIndex = 6;
         this.btnFive.Text = "5";
         this.btnFive.Click += new System.EventHandler(this.btnFive_Click);
         // 
         // btnFour
         // 
         this.btnFour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnFour.Location = new System.Drawing.Point(40, 98);
         this.btnFour.Name = "btnFour";
         this.btnFour.Size = new System.Drawing.Size(24, 24);
         this.btnFour.TabIndex = 5;
         this.btnFour.Text = "4";
         this.btnFour.Click += new System.EventHandler(this.btnFour_Click);
         // 
         // btnThree
         // 
         this.btnThree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnThree.Location = new System.Drawing.Point(86, 75);
         this.btnThree.Name = "btnThree";
         this.btnThree.Size = new System.Drawing.Size(24, 24);
         this.btnThree.TabIndex = 4;
         this.btnThree.Text = "3";
         this.btnThree.Click += new System.EventHandler(this.btnThree_Click);
         // 
         // btnTwo
         // 
         this.btnTwo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnTwo.Location = new System.Drawing.Point(63, 75);
         this.btnTwo.Name = "btnTwo";
         this.btnTwo.Size = new System.Drawing.Size(24, 24);
         this.btnTwo.TabIndex = 3;
         this.btnTwo.Text = "2";
         this.btnTwo.Click += new System.EventHandler(this.btnTwo_Click);
         // 
         // btnOne
         // 
         this.btnOne.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnOne.Location = new System.Drawing.Point(40, 75);
         this.btnOne.Name = "btnOne";
         this.btnOne.Size = new System.Drawing.Size(24, 24);
         this.btnOne.TabIndex = 2;
         this.btnOne.Text = "1";
         this.btnOne.Click += new System.EventHandler(this.btnOne_Click);
         // 
         // lblDisplay
         // 
         this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.lblDisplay.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblDisplay.Location = new System.Drawing.Point(15, 11);
         this.lblDisplay.Name = "lblDisplay";
         this.lblDisplay.Size = new System.Drawing.Size(120, 48);
         this.lblDisplay.TabIndex = 1;
         this.lblDisplay.Text = "Microwave Oven";
         this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // tmrClock
         // 
         this.tmrClock.Interval = 1000;
         this.tmrClock.Tick += new System.EventHandler(this.tmrClock_Tick);
         // 
         // pnlWindow
         // 
         this.pnlWindow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.pnlWindow.Location = new System.Drawing.Point(16, 16);
         this.pnlWindow.Name = "pnlWindow";
         this.pnlWindow.Size = new System.Drawing.Size(328, 224);
         this.pnlWindow.TabIndex = 1;
         // 
         // FrmMicrowaveOven
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(536, 261);
         this.Controls.Add(this.pnlWindow);
         this.Controls.Add(this.pnlControl);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmMicrowaveOven";
         this.Text = "Microwave Oven";
         this.pnlControl.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmMicrowaveOven() );
      }

      // event handler appends 1 to time string
      private void btnOne_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "1";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnOne_Click

      // event handler appends 2 to time string
      private void btnTwo_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "2";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnTwo_Click

      // event handler appends 3 to time string
      private void btnThree_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "3";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnThree_Click
      
      // event handler appends 4 to time string
      private void btnFour_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "4";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnFour_Click
      
      // event handler appends 5 to time string
      private void btnFive_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "5";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnFive_Click
      
      // event handler appends 6 to time string
      private void btnSix_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "6";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnSix_Click
      
      // event handler appends 7 to time string
      private void btnSeven_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "7";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnSeven_Click
      
      // event handler appends 8 to time string
      private void btnEight_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "8";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnEight_Click
      
      // event handler appends 9 to time string
      private void btnNine_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "9";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnNine_Click
      
      // event handler appends 0 to time string
      private void btnZero_Click( 
         object sender, System.EventArgs e )
      {
         m_strTime += "0";   // append digit to time input
         DisplayTime();      // display time input properly

      } // end method btnZero_Click

      // event handler starts the microwave oven's cooking process
      private void btnStart_Click( 
         object sender, System.EventArgs e )
      {
         int intSecond;
         int intMinute;

         // ensure that m_strTime has 4 characters
         m_strTime = m_strTime.PadLeft( 4, Convert.ToChar( "0" ) );

         // extract seconds and minutes
         intSecond = Int32.Parse( m_strTime.Substring( 2 ) );
         intMinute = Int32.Parse( m_strTime.Substring( 0, 2 ) );

         // create Time object to contain time entered by user
         m_objTime = new Time( intMinute, intSecond );

         lblDisplay.Text = String.Format( "{0:D2}:{1:D2}",
            m_objTime.Minute, m_objTime.Second );

         m_strTime = ""; // clear m_strTime for future input

         tmrClock.Enabled = true; // start timer

         pnlWindow.BackColor = Color.Yellow; // turn "light" on

      } // end method btnStart_Click

      // event handler to clear input
      private void btnClear_Click( 
         object sender, System.EventArgs e )
      {
         // reset each property or variable to its initial setting
         lblDisplay.Text = "Microwave Oven";
         m_strTime = "";
         m_objTime = new Time( 0, 0 );
         tmrClock.Enabled = false;
         pnlWindow.BackColor = SystemColors.Control;

      } // end method btnClear_Click

      // method to display formatted time in timer window
      private void DisplayTime()
      {
         int intSecond;
         int intMinute;

         string strDisplay; // string displays current input

         // if too much input entered
         if ( m_strTime.Length > 4 )
         {
            m_strTime = m_strTime.Substring( 0, 4 );
         }

         strDisplay = m_strTime.PadLeft( 4, Convert.ToChar( "0" ) );

         // extract seconds and minutes
         intSecond = Int32.Parse( strDisplay.Substring( 2 ) );
         intMinute = Int32.Parse( strDisplay.Substring( 0, 2 ) );

         // display number of minutes, ":" and number of seconds
         lblDisplay.Text = String.Format( "{0:D2}:{1:D2}",
            intMinute, intSecond );

      } // end method DisplayTime

      // event handler displays new time each second
      private void tmrClock_Tick( 
         object sender, System.EventArgs e )
      {
         // perform countdown, subtract one second
         if ( m_objTime.Second > 0 )
         {
            m_objTime.Second--;
         }
         else if ( m_objTime.Minute > 0 )
         {
            m_objTime.Minute--;    // subtract one minute
            m_objTime.Second = 59; // reset seconds for new minute
         }
         else // no more seconds
         {
            tmrClock.Enabled = false;  // stop timer
            lblDisplay.Text = "Done!"; // tell user time is finished
            pnlWindow.BackColor = SystemColors.Control;
            return;
         }

         lblDisplay.Text = String.Format( "{0:D2}:{1:D2}",
            m_objTime.Minute, m_objTime.Second );

      } // end method tmrClock_Tick

   } // end class FrmMicrowaveOven
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
