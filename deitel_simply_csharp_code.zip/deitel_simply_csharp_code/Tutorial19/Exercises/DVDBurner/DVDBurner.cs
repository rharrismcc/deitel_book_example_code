using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DVDBurner
{
   /// <summary>
   /// Summary description for FrmDVDBurner.
   /// </summary>
   public class FrmDVDBurner : System.Windows.Forms.Form
   {
      // GroupBox containing DVD title and length
      private System.Windows.Forms.GroupBox fraDVD;

      // Label and TextBox to input DVD title
      private System.Windows.Forms.Label lblMovieTitle;
      private System.Windows.Forms.TextBox txtTitle;

      // Label and TextBox to input length of movie in minutes
      private System.Windows.Forms.Label lblMinutes;
      private System.Windows.Forms.TextBox txtMovieMinute;

      // GroupBox containing bonus materials information
      private System.Windows.Forms.GroupBox fraBonus;

      // Labels and TextBoxes to input first bonus material's
      // description and length in minutes
      private System.Windows.Forms.Label lblBonusDescription1;
      private System.Windows.Forms.TextBox txtDescription1;
      private System.Windows.Forms.Label lblBonusMinutes;
      private System.Windows.Forms.TextBox txtMinutes1;

      // Labels and TextBoxes to input second bonus material's
      // description and length in minutes
      private System.Windows.Forms.Label lblBonusDescription2;
      private System.Windows.Forms.TextBox txtDescription2;
      private System.Windows.Forms.Label lblBonusMinutes2;
      private System.Windows.Forms.TextBox txtMinutes2;

      // Labels and TextBoxes to input third bonus material's
      // description and length in minutes
      private System.Windows.Forms.Label lblBonusDescription3;
      private System.Windows.Forms.TextBox txtDescription3;
      private System.Windows.Forms.Label lblBonusMinutes3;
      private System.Windows.Forms.TextBox txtMinutes3;

      // Button to create a DVD
      private System.Windows.Forms.Button btnCreate;

      // Button to display DVD information
      private System.Windows.Forms.Button btnInformation;

      // Label to display information to the user
      private System.Windows.Forms.Label lblDisplay;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmDVDBurner()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.fraDVD = new System.Windows.Forms.GroupBox();
         this.lblMinutes = new System.Windows.Forms.Label();
         this.txtTitle = new System.Windows.Forms.TextBox();
         this.txtMovieMinute = new System.Windows.Forms.TextBox();
         this.lblMovieTitle = new System.Windows.Forms.Label();
         this.fraBonus = new System.Windows.Forms.GroupBox();
         this.lblBonusMinutes3 = new System.Windows.Forms.Label();
         this.lblBonusMinutes2 = new System.Windows.Forms.Label();
         this.lblBonusMinutes = new System.Windows.Forms.Label();
         this.txtMinutes3 = new System.Windows.Forms.TextBox();
         this.txtMinutes2 = new System.Windows.Forms.TextBox();
         this.txtMinutes1 = new System.Windows.Forms.TextBox();
         this.lblBonusDescription3 = new System.Windows.Forms.Label();
         this.lblBonusDescription2 = new System.Windows.Forms.Label();
         this.txtDescription3 = new System.Windows.Forms.TextBox();
         this.txtDescription2 = new System.Windows.Forms.TextBox();
         this.txtDescription1 = new System.Windows.Forms.TextBox();
         this.lblBonusDescription1 = new System.Windows.Forms.Label();
         this.btnCreate = new System.Windows.Forms.Button();
         this.btnInformation = new System.Windows.Forms.Button();
         this.lblDisplay = new System.Windows.Forms.Label();
         this.fraDVD.SuspendLayout();
         this.fraBonus.SuspendLayout();
         this.SuspendLayout();
         // 
         // fraDVD
         // 
         this.fraDVD.Controls.Add(this.lblMinutes);
         this.fraDVD.Controls.Add(this.txtTitle);
         this.fraDVD.Controls.Add(this.txtMovieMinute);
         this.fraDVD.Controls.Add(this.lblMovieTitle);
         this.fraDVD.Location = new System.Drawing.Point(8, 8);
         this.fraDVD.Name = "fraDVD";
         this.fraDVD.Size = new System.Drawing.Size(240, 112);
         this.fraDVD.TabIndex = 3;
         this.fraDVD.TabStop = false;
         this.fraDVD.Text = "DVD Information";
         // 
         // lblMinutes
         // 
         this.lblMinutes.Location = new System.Drawing.Point(16, 72);
         this.lblMinutes.Name = "lblMinutes";
         this.lblMinutes.Size = new System.Drawing.Size(56, 21);
         this.lblMinutes.TabIndex = 5;
         this.lblMinutes.Text = "Minutes:";
         this.lblMinutes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtTitle
         // 
         this.txtTitle.Location = new System.Drawing.Point(88, 40);
         this.txtTitle.Name = "txtTitle";
         this.txtTitle.Size = new System.Drawing.Size(140, 21);
         this.txtTitle.TabIndex = 0;
         this.txtTitle.Text = "";
         // 
         // txtMovieMinute
         // 
         this.txtMovieMinute.Location = new System.Drawing.Point(176, 72);
         this.txtMovieMinute.Name = "txtMovieMinute";
         this.txtMovieMinute.Size = new System.Drawing.Size(50, 21);
         this.txtMovieMinute.TabIndex = 1;
         this.txtMovieMinute.Text = "";
         // 
         // lblMovieTitle
         // 
         this.lblMovieTitle.Location = new System.Drawing.Point(16, 40);
         this.lblMovieTitle.Name = "lblMovieTitle";
         this.lblMovieTitle.Size = new System.Drawing.Size(72, 21);
         this.lblMovieTitle.TabIndex = 4;
         this.lblMovieTitle.Text = "Movie title:";
         this.lblMovieTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // fraBonus
         // 
         this.fraBonus.Controls.Add(this.lblBonusMinutes3);
         this.fraBonus.Controls.Add(this.lblBonusMinutes2);
         this.fraBonus.Controls.Add(this.lblBonusMinutes);
         this.fraBonus.Controls.Add(this.txtMinutes3);
         this.fraBonus.Controls.Add(this.txtMinutes2);
         this.fraBonus.Controls.Add(this.txtMinutes1);
         this.fraBonus.Controls.Add(this.lblBonusDescription3);
         this.fraBonus.Controls.Add(this.lblBonusDescription2);
         this.fraBonus.Controls.Add(this.txtDescription3);
         this.fraBonus.Controls.Add(this.txtDescription2);
         this.fraBonus.Controls.Add(this.txtDescription1);
         this.fraBonus.Controls.Add(this.lblBonusDescription1);
         this.fraBonus.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.fraBonus.Location = new System.Drawing.Point(264, 8);
         this.fraBonus.Name = "fraBonus";
         this.fraBonus.Size = new System.Drawing.Size(248, 224);
         this.fraBonus.TabIndex = 4;
         this.fraBonus.TabStop = false;
         this.fraBonus.Text = "Bonus Materials";
         // 
         // lblBonusMinutes3
         // 
         this.lblBonusMinutes3.Location = new System.Drawing.Point(16, 192);
         this.lblBonusMinutes3.Name = "lblBonusMinutes3";
         this.lblBonusMinutes3.Size = new System.Drawing.Size(56, 21);
         this.lblBonusMinutes3.TabIndex = 21;
         this.lblBonusMinutes3.Text = "Minutes:";
         this.lblBonusMinutes3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblBonusMinutes2
         // 
         this.lblBonusMinutes2.Location = new System.Drawing.Point(16, 128);
         this.lblBonusMinutes2.Name = "lblBonusMinutes2";
         this.lblBonusMinutes2.Size = new System.Drawing.Size(56, 21);
         this.lblBonusMinutes2.TabIndex = 20;
         this.lblBonusMinutes2.Text = "Minutes:";
         this.lblBonusMinutes2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblBonusMinutes
         // 
         this.lblBonusMinutes.Location = new System.Drawing.Point(16, 64);
         this.lblBonusMinutes.Name = "lblBonusMinutes";
         this.lblBonusMinutes.Size = new System.Drawing.Size(56, 21);
         this.lblBonusMinutes.TabIndex = 19;
         this.lblBonusMinutes.Text = "Minutes:";
         this.lblBonusMinutes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtMinutes3
         // 
         this.txtMinutes3.Location = new System.Drawing.Point(184, 192);
         this.txtMinutes3.Name = "txtMinutes3";
         this.txtMinutes3.Size = new System.Drawing.Size(50, 21);
         this.txtMinutes3.TabIndex = 10;
         this.txtMinutes3.Text = "";
         // 
         // txtMinutes2
         // 
         this.txtMinutes2.Location = new System.Drawing.Point(184, 128);
         this.txtMinutes2.Name = "txtMinutes2";
         this.txtMinutes2.Size = new System.Drawing.Size(50, 21);
         this.txtMinutes2.TabIndex = 7;
         this.txtMinutes2.Text = "";
         // 
         // txtMinutes1
         // 
         this.txtMinutes1.Location = new System.Drawing.Point(184, 64);
         this.txtMinutes1.Name = "txtMinutes1";
         this.txtMinutes1.Size = new System.Drawing.Size(50, 21);
         this.txtMinutes1.TabIndex = 4;
         this.txtMinutes1.Text = "";
         // 
         // lblBonusDescription3
         // 
         this.lblBonusDescription3.Location = new System.Drawing.Point(16, 160);
         this.lblBonusDescription3.Name = "lblBonusDescription3";
         this.lblBonusDescription3.Size = new System.Drawing.Size(64, 23);
         this.lblBonusDescription3.TabIndex = 9;
         this.lblBonusDescription3.Text = "Description:";
         this.lblBonusDescription3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblBonusDescription2
         // 
         this.lblBonusDescription2.Location = new System.Drawing.Point(16, 96);
         this.lblBonusDescription2.Name = "lblBonusDescription2";
         this.lblBonusDescription2.Size = new System.Drawing.Size(64, 23);
         this.lblBonusDescription2.TabIndex = 8;
         this.lblBonusDescription2.Text = "Description:";
         this.lblBonusDescription2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtDescription3
         // 
         this.txtDescription3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtDescription3.Location = new System.Drawing.Point(96, 160);
         this.txtDescription3.Name = "txtDescription3";
         this.txtDescription3.Size = new System.Drawing.Size(140, 21);
         this.txtDescription3.TabIndex = 9;
         this.txtDescription3.Text = "";
         // 
         // txtDescription2
         // 
         this.txtDescription2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtDescription2.Location = new System.Drawing.Point(96, 96);
         this.txtDescription2.Name = "txtDescription2";
         this.txtDescription2.Size = new System.Drawing.Size(140, 21);
         this.txtDescription2.TabIndex = 6;
         this.txtDescription2.Text = "";
         // 
         // txtDescription1
         // 
         this.txtDescription1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtDescription1.Location = new System.Drawing.Point(96, 32);
         this.txtDescription1.Name = "txtDescription1";
         this.txtDescription1.Size = new System.Drawing.Size(140, 21);
         this.txtDescription1.TabIndex = 3;
         this.txtDescription1.Text = "";
         // 
         // lblBonusDescription1
         // 
         this.lblBonusDescription1.Location = new System.Drawing.Point(16, 32);
         this.lblBonusDescription1.Name = "lblBonusDescription1";
         this.lblBonusDescription1.Size = new System.Drawing.Size(64, 23);
         this.lblBonusDescription1.TabIndex = 4;
         this.lblBonusDescription1.Text = "Description:";
         this.lblBonusDescription1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // btnCreate
         // 
         this.btnCreate.Location = new System.Drawing.Point(88, 136);
         this.btnCreate.Name = "btnCreate";
         this.btnCreate.Size = new System.Drawing.Size(80, 24);
         this.btnCreate.TabIndex = 13;
         this.btnCreate.Text = "Create";
         // 
         // btnInformation
         // 
         this.btnInformation.Enabled = false;
         this.btnInformation.Location = new System.Drawing.Point(88, 168);
         this.btnInformation.Name = "btnInformation";
         this.btnInformation.Size = new System.Drawing.Size(80, 24);
         this.btnInformation.TabIndex = 14;
         this.btnInformation.Text = "Information";
         this.btnInformation.Click += new System.EventHandler(this.btnInformation_Click);
         // 
         // lblDisplay
         // 
         this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblDisplay.Location = new System.Drawing.Point(8, 208);
         this.lblDisplay.Name = "lblDisplay";
         this.lblDisplay.Size = new System.Drawing.Size(240, 24);
         this.lblDisplay.TabIndex = 15;
         this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // FrmDVDBurner
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(520, 245);
         this.Controls.Add(this.lblDisplay);
         this.Controls.Add(this.btnInformation);
         this.Controls.Add(this.btnCreate);
         this.Controls.Add(this.fraBonus);
         this.Controls.Add(this.fraDVD);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmDVDBurner";
         this.Text = "DVD Burner";
         this.fraDVD.ResumeLayout(false);
         this.fraBonus.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmDVDBurner() );
      }

      // display information about DVD
      private void btnInformation_Click( 
         object sender, System.EventArgs e )
      {
         string strInformation = ""; // output string

         lblDisplay.Text = ""; // clear Label

         // display output in a MessageBox
         MessageBox.Show( strInformation, "DVD Description",
            MessageBoxButtons.OK, MessageBoxIcon.Information );
      
      } // end method btnInformation_Click

   } // end class FrmDVDBurner
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/