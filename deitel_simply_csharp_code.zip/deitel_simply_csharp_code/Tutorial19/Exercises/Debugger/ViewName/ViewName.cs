using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ViewName
{
   /// <summary>
   /// Summary description for FrmViewName.
   /// </summary>
   public class FrmViewName : System.Windows.Forms.Form
   {
      // Label and TextBox to input first name
      private System.Windows.Forms.Label lblFirst;
      private System.Windows.Forms.TextBox txtFirst;

      // Label and TextBox to input last name
      private System.Windows.Forms.Label lblLast;
      private System.Windows.Forms.TextBox txtLast;

      // Button to view name in MessageBox
      private System.Windows.Forms.Button btnView;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      private Name m_objName; // Name object

      public FrmViewName()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblFirst = new System.Windows.Forms.Label();
         this.txtFirst = new System.Windows.Forms.TextBox();
         this.lblLast = new System.Windows.Forms.Label();
         this.txtLast = new System.Windows.Forms.TextBox();
         this.btnView = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblFirst
         // 
         this.lblFirst.Location = new System.Drawing.Point(16, 16);
         this.lblFirst.Name = "lblFirst";
         this.lblFirst.Size = new System.Drawing.Size(64, 21);
         this.lblFirst.TabIndex = 6;
         this.lblFirst.Text = "First name:";
         this.lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtFirst
         // 
         this.txtFirst.Location = new System.Drawing.Point(96, 16);
         this.txtFirst.Name = "txtFirst";
         this.txtFirst.TabIndex = 7;
         this.txtFirst.Text = "";
         // 
         // lblLast
         // 
         this.lblLast.Location = new System.Drawing.Point(16, 56);
         this.lblLast.Name = "lblLast";
         this.lblLast.Size = new System.Drawing.Size(64, 21);
         this.lblLast.TabIndex = 8;
         this.lblLast.Text = "Last name:";
         this.lblLast.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtLast
         // 
         this.txtLast.Location = new System.Drawing.Point(96, 56);
         this.txtLast.Name = "txtLast";
         this.txtLast.TabIndex = 9;
         this.txtLast.Text = "";
         // 
         // btnView
         // 
         this.btnView.Location = new System.Drawing.Point(120, 88);
         this.btnView.Name = "btnView";
         this.btnView.TabIndex = 10;
         this.btnView.Text = "View Name";
         this.btnView.Click += new System.EventHandler(this.btnView_Click);
         // 
         // FrmViewName
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(216, 125);
         this.Controls.Add(this.btnView);
         this.Controls.Add(this.txtLast);
         this.Controls.Add(this.lblLast);
         this.Controls.Add(this.txtFirst);
         this.Controls.Add(this.lblFirst);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmViewName";
         this.Text = "View Name";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmViewName() );
      }

      // handles View Name Button's Click event
      private void btnView_Click( 
         object sender, System.EventArgs e )
      {
         string strOutput; // holds first name and last name

         // create new Name
         m_objName = new Name( txtFirst.Text, txtLast.Text );

         // assign user's name to strOutput
         strOutput = "Your name is: " + m_objName.First + " "
            + m_objName.Last;

         // output name to string
         MessageBox.Show( strOutput, Name,
            MessageBoxButtons.OK, MessageBoxIcon.Information );
      
      } // end method btnView_Click

   } // end class FrmViewName
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
