// Time.cs
// Represents time data and contains properties.

using System;

namespace MicrowaveOven
{
   /// <summary>
   /// Summary description for Time.
   /// </summary>
   public class Time
   {
      // declare ints for minute and second
      private int m_intMinute;
      private int m_intSecond;

      // Time constructor, minute and second supplied
      public Time( int minuteValue, int secondValue )
      {
         Minute = minuteValue; // invokes Minute set accessor
         Second = secondValue; // invokes Second set accessor

      } // end constructor Time 

      // property Minute
      public int Minute
      {
         // return m_intMinute value
         get
         {
            return m_intMinute;

         } // end of get accessor

         // set m_intMinute value
         set
         {
            // if minute value entered is valid
            if ( value < 60 )
            {
               m_intMinute = value;
            }
            else
            {
               m_intMinute = 0; // set invalid input to 0
            }

         } // end of set accessor

      } // end property Minute

      // property Second
      public int Second
      {
         // return m_intSecond value
         get
         {
            return m_intSecond;

         } // end of get accessor

         // set m_intSecond value
         set
         {
            // if minute value entered is valid
            if ( value < 60 )
            {
               m_intSecond = value;
            }
            else
            {
               m_intSecond = 0; // set invalid input to 0
            }

         } // end of set accessor

      } // end property Second

   } // end class Time
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/