using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Triangle
{
   /// <summary>
   /// Summary description for FrmTriangleCreator.
   /// </summary>
   public class FrmTriangleCreator : System.Windows.Forms.Form
   {
      // Labels and TextBoxes to input the side lengths
      private System.Windows.Forms.Label lblSide1;
      private System.Windows.Forms.TextBox txtSide1;
      private System.Windows.Forms.Label lblSide2;
      private System.Windows.Forms.TextBox txtSide2;
      private System.Windows.Forms.Label lblSide3;
      private System.Windows.Forms.TextBox txtSide3;

      // Button to create a triangle
      private System.Windows.Forms.Button btnCreate;

      // Label to display triangle information
      private System.Windows.Forms.Label lblDisplay;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmTriangleCreator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblSide1 = new System.Windows.Forms.Label();
         this.txtSide1 = new System.Windows.Forms.TextBox();
         this.lblSide2 = new System.Windows.Forms.Label();
         this.txtSide2 = new System.Windows.Forms.TextBox();
         this.lblSide3 = new System.Windows.Forms.Label();
         this.txtSide3 = new System.Windows.Forms.TextBox();
         this.btnCreate = new System.Windows.Forms.Button();
         this.lblDisplay = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // lblSide1
         // 
         this.lblSide1.Location = new System.Drawing.Point(16, 16);
         this.lblSide1.Name = "lblSide1";
         this.lblSide1.Size = new System.Drawing.Size(40, 21);
         this.lblSide1.TabIndex = 1;
         this.lblSide1.Text = "Side1:";
         this.lblSide1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtSide1
         // 
         this.txtSide1.Location = new System.Drawing.Point(64, 16);
         this.txtSide1.Name = "txtSide1";
         this.txtSide1.Size = new System.Drawing.Size(88, 20);
         this.txtSide1.TabIndex = 2;
         this.txtSide1.Text = "";
         this.txtSide1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblSide2
         // 
         this.lblSide2.Location = new System.Drawing.Point(16, 48);
         this.lblSide2.Name = "lblSide2";
         this.lblSide2.Size = new System.Drawing.Size(40, 21);
         this.lblSide2.TabIndex = 3;
         this.lblSide2.Text = "Side2:";
         this.lblSide2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtSide2
         // 
         this.txtSide2.Location = new System.Drawing.Point(64, 48);
         this.txtSide2.Name = "txtSide2";
         this.txtSide2.Size = new System.Drawing.Size(88, 20);
         this.txtSide2.TabIndex = 4;
         this.txtSide2.Text = "";
         this.txtSide2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblSide3
         // 
         this.lblSide3.Location = new System.Drawing.Point(16, 80);
         this.lblSide3.Name = "lblSide3";
         this.lblSide3.Size = new System.Drawing.Size(40, 21);
         this.lblSide3.TabIndex = 5;
         this.lblSide3.Text = "Side3:";
         this.lblSide3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtSide3
         // 
         this.txtSide3.Location = new System.Drawing.Point(64, 80);
         this.txtSide3.Name = "txtSide3";
         this.txtSide3.Size = new System.Drawing.Size(88, 20);
         this.txtSide3.TabIndex = 6;
         this.txtSide3.Text = "";
         this.txtSide3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCreate
         // 
         this.btnCreate.Location = new System.Drawing.Point(168, 16);
         this.btnCreate.Name = "btnCreate";
         this.btnCreate.Size = new System.Drawing.Size(72, 23);
         this.btnCreate.TabIndex = 7;
         this.btnCreate.Text = "Create";
         // 
         // lblDisplay
         // 
         this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblDisplay.Location = new System.Drawing.Point(16, 120);
         this.lblDisplay.Name = "lblDisplay";
         this.lblDisplay.Size = new System.Drawing.Size(224, 32);
         this.lblDisplay.TabIndex = 8;
         this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // FrmTriangleCreator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(256, 165);
         this.Controls.Add(this.lblDisplay);
         this.Controls.Add(this.btnCreate);
         this.Controls.Add(this.txtSide3);
         this.Controls.Add(this.lblSide3);
         this.Controls.Add(this.txtSide2);
         this.Controls.Add(this.lblSide2);
         this.Controls.Add(this.txtSide1);
         this.Controls.Add(this.lblSide1);
         this.Font = new System.Drawing.Font("Tahoma", 8F);
         this.Name = "FrmTriangleCreator";
         this.Text = "Triangle Creator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmTriangleCreator() );
      }

   } // end class FrmTriangleCreator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
