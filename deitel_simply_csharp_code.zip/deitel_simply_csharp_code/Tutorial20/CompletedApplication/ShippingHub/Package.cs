// Package.cs
// represents package information

using System;

namespace ShippingHub
{
   /// <summary>
   /// Summary description for Package.
   /// </summary>
   public class Package
   {
      private string m_strAddress; // package address
      private string m_strCity; // package city
      private string m_strState; // package state
      private int m_intZip; // package zip code
      private DateTime m_dtmTime; // arrival time
      private int m_intPackageNumber; // package number

      // Package contructor
      public Package( int intPackage )
      {
         ArrivalTime = DateTime.Now;
         SetPackage( "", "", "", 99999, "" );
         PackageNumber = intPackage; // unique package number

      } // end constructor Package

      // set properties of Package object
      private void SetPackage( 
         string strAddress, string strCity,
         string strState, int intZip, string strDestination )
      {
         Address = strAddress;
         City = strCity;
         State = strState;
         Zip = intZip;

      } // end method SetPackage

      // property Address
      public string Address
      {
         // get m_strAddress value
         get
         {
            return m_strAddress;
         }

         // set m_strAddress value
         set
         {
            m_strAddress = value;
         }

      } // end property Address

      // property City
      public string City
      {
         // get m_strCity value
         get
         {
            return m_strCity;
         }

         // set m_strCity value
         set
         {
            m_strCity = value;
         }

      } // end property City

      // property State
      public string State
      {
         // get m_strState value
         get
         {
            return m_strState;
         }

         // set m_strState value
         set
         {
            m_strState = value;
         }

      } // end property State

      // property Zip
      public int Zip
      {
         // get m_intZip value
         get
         {
            return m_intZip;
         }

         // set m_intZip value
         set
         {
            m_intZip = value;
         }

      } // end property Zip


      // property PackageNumber
      public int PackageNumber
      {
         // get m_intPackageNumber value
         get
         {
            return m_intPackageNumber;
         }

         // set m_intPackageNumber value
         set
         {
            m_intPackageNumber = value;
         }

      } // end property PackageNumber

      // property ArrivalTime
      public DateTime ArrivalTime
      {
         // get m_dtmTime value
         get
         {
            return m_dtmTime;
         }

         // set m_dtmTime value
         set
         {
            m_dtmTime = value;
         }

      } // end property ArrivalTime

   } // end class Package
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/