using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ControlsCollection
{
   /// <summary>
   /// Summary description for FrmControlsCollection.
   /// </summary>
   public class FrmControlsCollection : System.Windows.Forms.Form
   {
      // some controls on the form
      private System.Windows.Forms.Label lblName;
      private System.Windows.Forms.TextBox txtName;
      private System.Windows.Forms.Label lblBook;
      private System.Windows.Forms.ComboBox cboBook;
      private System.Windows.Forms.Label lblCover;
      private System.Windows.Forms.PictureBox picBook;

      // Label and ListBox to list the controls on the form
      private System.Windows.Forms.Label lblList;
      private System.Windows.Forms.ListBox lstList;

      // Button to loop through the controls
      private System.Windows.Forms.Button btnSubmit;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmControlsCollection()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FrmControlsCollection));
         this.lblName = new System.Windows.Forms.Label();
         this.txtName = new System.Windows.Forms.TextBox();
         this.lblBook = new System.Windows.Forms.Label();
         this.cboBook = new System.Windows.Forms.ComboBox();
         this.lblCover = new System.Windows.Forms.Label();
         this.picBook = new System.Windows.Forms.PictureBox();
         this.lblList = new System.Windows.Forms.Label();
         this.lstList = new System.Windows.Forms.ListBox();
         this.btnSubmit = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblName
         // 
         this.lblName.Location = new System.Drawing.Point(16, 16);
         this.lblName.Name = "lblName";
         this.lblName.Size = new System.Drawing.Size(48, 21);
         this.lblName.TabIndex = 6;
         this.lblName.Text = "Name:";
         this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtName
         // 
         this.txtName.Location = new System.Drawing.Point(64, 16);
         this.txtName.Name = "txtName";
         this.txtName.Size = new System.Drawing.Size(152, 21);
         this.txtName.TabIndex = 7;
         this.txtName.Text = "";
         // 
         // lblBook
         // 
         this.lblBook.Location = new System.Drawing.Point(16, 48);
         this.lblBook.Name = "lblBook";
         this.lblBook.Size = new System.Drawing.Size(48, 21);
         this.lblBook.TabIndex = 8;
         this.lblBook.Text = "Book:";
         this.lblBook.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // cboBook
         // 
         this.cboBook.Items.AddRange(new object[] {
                                                     "Simply Series",
                                                     "How To Program Series",
                                                     "Developer Series"});
         this.cboBook.Location = new System.Drawing.Point(64, 48);
         this.cboBook.Name = "cboBook";
         this.cboBook.Size = new System.Drawing.Size(152, 21);
         this.cboBook.TabIndex = 9;
         // 
         // lblCover
         // 
         this.lblCover.Location = new System.Drawing.Point(16, 80);
         this.lblCover.Name = "lblCover";
         this.lblCover.Size = new System.Drawing.Size(48, 21);
         this.lblCover.TabIndex = 10;
         this.lblCover.Text = "Picture:";
         this.lblCover.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // picBook
         // 
         this.picBook.Image = ((System.Drawing.Image)(resources.GetObject("picBook.Image")));
         this.picBook.Location = new System.Drawing.Point(64, 80);
         this.picBook.Name = "picBook";
         this.picBook.Size = new System.Drawing.Size(91, 119);
         this.picBook.TabIndex = 11;
         this.picBook.TabStop = false;
         // 
         // lblList
         // 
         this.lblList.Location = new System.Drawing.Point(232, 16);
         this.lblList.Name = "lblList";
         this.lblList.Size = new System.Drawing.Size(100, 21);
         this.lblList.TabIndex = 12;
         this.lblList.Text = "List of controls:";
         this.lblList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lstList
         // 
         this.lstList.Location = new System.Drawing.Point(232, 40);
         this.lstList.Name = "lstList";
         this.lstList.Size = new System.Drawing.Size(120, 160);
         this.lstList.TabIndex = 13;
         // 
         // btnSubmit
         // 
         this.btnSubmit.Location = new System.Drawing.Point(280, 216);
         this.btnSubmit.Name = "btnSubmit";
         this.btnSubmit.Size = new System.Drawing.Size(76, 23);
         this.btnSubmit.TabIndex = 14;
         this.btnSubmit.Text = "Submit";
         // 
         // FrmControlsCollection
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(368, 253);
         this.Controls.Add(this.btnSubmit);
         this.Controls.Add(this.lstList);
         this.Controls.Add(this.lblList);
         this.Controls.Add(this.picBook);
         this.Controls.Add(this.lblCover);
         this.Controls.Add(this.cboBook);
         this.Controls.Add(this.lblBook);
         this.Controls.Add(this.txtName);
         this.Controls.Add(this.lblName);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmControlsCollection";
         this.Text = "Controls Collection";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmControlsCollection() );
      }

   } // end class FrmControlsCollection
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/