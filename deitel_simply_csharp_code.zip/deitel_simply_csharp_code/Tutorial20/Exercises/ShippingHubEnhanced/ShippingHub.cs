using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ShippingHub
{
   /// <summary>
   /// Summary description for FrmShippingHub.
   /// </summary>
   public class FrmShippingHub : System.Windows.Forms.Form
   {
      // Labels for the arrival time
      private System.Windows.Forms.Label lblArrived;
      private System.Windows.Forms.Label lblArrivalTime;

      // GroupBox for the package information
      private System.Windows.Forms.GroupBox fraAddress;

      // Labels for the package ID
      private System.Windows.Forms.Label lblPackageID;
      private System.Windows.Forms.Label lblPackageNumber;

      // Labels, TextBoxes and ComboBox for the full address
      private System.Windows.Forms.Label lblAddress;
      private System.Windows.Forms.TextBox txtAddress;
      private System.Windows.Forms.Label lblCity;
      private System.Windows.Forms.TextBox txtCity;
      private System.Windows.Forms.Label lblState;
      private System.Windows.Forms.ComboBox cboState;
      private System.Windows.Forms.Label lblZip;
      private System.Windows.Forms.TextBox txtZip;

      // GroupBox for choosing packages by state.
      // contains a ComboBox and a ListBox for doing so.
      // also contains Button to ship a package.
      private System.Windows.Forms.GroupBox fraListByState;
      private System.Windows.Forms.ComboBox cboViewPackages;
      private System.Windows.Forms.ListBox lstPackages;
      private System.Windows.Forms.Button btnShip;

      // GroupBox with ListBox inside for displaying package IDs
      private System.Windows.Forms.GroupBox fraPackagesToShip;
      private System.Windows.Forms.ListBox lstTruck; 

      // Buttons to go back one package, scan a new package,
      // add a package, remove a package, edit an existing package
      // and go forward one package.
      private System.Windows.Forms.Button btnBack;
      private System.Windows.Forms.Button btnNew;
      private System.Windows.Forms.Button btnAdd;
      private System.Windows.Forms.Button btnRemove;
      private System.Windows.Forms.Button btnEditUpdate;
      private System.Windows.Forms.Button btnNext;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      private ArrayList m_objList; // list of packages
      private Package m_objPackage; // current package
      private int m_intPosition; // position of current package
      private Random m_objRandom; // random number for package ID
      private int m_intPackageID; // individual package number
      private ArrayList m_objTruckList; // list of shipment
      private int m_intCounter = 0; // count packages on truck

      public FrmShippingHub()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();
         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblArrived = new System.Windows.Forms.Label();
         this.lblArrivalTime = new System.Windows.Forms.Label();
         this.fraAddress = new System.Windows.Forms.GroupBox();
         this.cboState = new System.Windows.Forms.ComboBox();
         this.txtZip = new System.Windows.Forms.TextBox();
         this.lblZip = new System.Windows.Forms.Label();
         this.lblState = new System.Windows.Forms.Label();
         this.txtCity = new System.Windows.Forms.TextBox();
         this.lblCity = new System.Windows.Forms.Label();
         this.txtAddress = new System.Windows.Forms.TextBox();
         this.lblAddress = new System.Windows.Forms.Label();
         this.lblPackageNumber = new System.Windows.Forms.Label();
         this.lblPackageID = new System.Windows.Forms.Label();
         this.fraListByState = new System.Windows.Forms.GroupBox();
         this.btnShip = new System.Windows.Forms.Button();
         this.lstPackages = new System.Windows.Forms.ListBox();
         this.cboViewPackages = new System.Windows.Forms.ComboBox();
         this.btnBack = new System.Windows.Forms.Button();
         this.btnNew = new System.Windows.Forms.Button();
         this.btnAdd = new System.Windows.Forms.Button();
         this.btnRemove = new System.Windows.Forms.Button();
         this.btnEditUpdate = new System.Windows.Forms.Button();
         this.btnNext = new System.Windows.Forms.Button();
         this.fraPackagesToShip = new System.Windows.Forms.GroupBox();
         this.lstTruck = new System.Windows.Forms.ListBox();
         this.fraAddress.SuspendLayout();
         this.fraListByState.SuspendLayout();
         this.fraPackagesToShip.SuspendLayout();
         this.SuspendLayout();
         // 
         // lblArrived
         // 
         this.lblArrived.Location = new System.Drawing.Point(29, 19);
         this.lblArrived.Name = "lblArrived";
         this.lblArrived.Size = new System.Drawing.Size(74, 24);
         this.lblArrived.TabIndex = 8;
         this.lblArrived.Text = "Arrived at:";
         this.lblArrived.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblArrivalTime
         // 
         this.lblArrivalTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblArrivalTime.Location = new System.Drawing.Point(132, 19);
         this.lblArrivalTime.Name = "lblArrivalTime";
         this.lblArrivalTime.Size = new System.Drawing.Size(197, 24);
         this.lblArrivalTime.TabIndex = 9;
         this.lblArrivalTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // fraAddress
         // 
         this.fraAddress.Controls.Add(this.cboState);
         this.fraAddress.Controls.Add(this.txtZip);
         this.fraAddress.Controls.Add(this.lblZip);
         this.fraAddress.Controls.Add(this.lblState);
         this.fraAddress.Controls.Add(this.txtCity);
         this.fraAddress.Controls.Add(this.lblCity);
         this.fraAddress.Controls.Add(this.txtAddress);
         this.fraAddress.Controls.Add(this.lblAddress);
         this.fraAddress.Controls.Add(this.lblPackageNumber);
         this.fraAddress.Controls.Add(this.lblPackageID);
         this.fraAddress.Enabled = false;
         this.fraAddress.Location = new System.Drawing.Point(19, 56);
         this.fraAddress.Name = "fraAddress";
         this.fraAddress.Size = new System.Drawing.Size(551, 178);
         this.fraAddress.TabIndex = 0;
         this.fraAddress.TabStop = false;
         this.fraAddress.Text = "Package Information";
         // 
         // cboState
         // 
         this.cboState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboState.Items.AddRange(new object[] {
                                                      "AL",
                                                      "FL",
                                                      "GA",
                                                      "KY",
                                                      "MS",
                                                      "NC",
                                                      "SC",
                                                      "TN",
                                                      "VA",
                                                      "WV"});
         this.cboState.Location = new System.Drawing.Point(301, 140);
         this.cboState.Name = "cboState";
         this.cboState.Size = new System.Drawing.Size(94, 21);
         this.cboState.Sorted = true;
         this.cboState.TabIndex = 2;
         // 
         // txtZip
         // 
         this.txtZip.Location = new System.Drawing.Point(451, 140);
         this.txtZip.MaxLength = 5;
         this.txtZip.Name = "txtZip";
         this.txtZip.Size = new System.Drawing.Size(76, 21);
         this.txtZip.TabIndex = 3;
         this.txtZip.Text = "";
         // 
         // lblZip
         // 
         this.lblZip.Location = new System.Drawing.Point(414, 140);
         this.lblZip.Name = "lblZip";
         this.lblZip.Size = new System.Drawing.Size(28, 24);
         this.lblZip.TabIndex = 9;
         this.lblZip.Text = "Zip:";
         this.lblZip.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblState
         // 
         this.lblState.Location = new System.Drawing.Point(245, 140);
         this.lblState.Name = "lblState";
         this.lblState.Size = new System.Drawing.Size(47, 24);
         this.lblState.TabIndex = 8;
         this.lblState.Text = "State:";
         this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtCity
         // 
         this.txtCity.Location = new System.Drawing.Point(113, 140);
         this.txtCity.Name = "txtCity";
         this.txtCity.Size = new System.Drawing.Size(117, 21);
         this.txtCity.TabIndex = 1;
         this.txtCity.Text = "";
         // 
         // lblCity
         // 
         this.lblCity.Location = new System.Drawing.Point(19, 140);
         this.lblCity.Name = "lblCity";
         this.lblCity.Size = new System.Drawing.Size(37, 24);
         this.lblCity.TabIndex = 7;
         this.lblCity.Text = "City:";
         this.lblCity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtAddress
         // 
         this.txtAddress.Location = new System.Drawing.Point(114, 87);
         this.txtAddress.Name = "txtAddress";
         this.txtAddress.Size = new System.Drawing.Size(414, 21);
         this.txtAddress.TabIndex = 0;
         this.txtAddress.Text = "";
         // 
         // lblAddress
         // 
         this.lblAddress.Location = new System.Drawing.Point(19, 87);
         this.lblAddress.Name = "lblAddress";
         this.lblAddress.Size = new System.Drawing.Size(66, 25);
         this.lblAddress.TabIndex = 6;
         this.lblAddress.Text = "Address:";
         this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPackageNumber
         // 
         this.lblPackageNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblPackageNumber.Location = new System.Drawing.Point(113, 28);
         this.lblPackageNumber.Name = "lblPackageNumber";
         this.lblPackageNumber.Size = new System.Drawing.Size(414, 27);
         this.lblPackageNumber.TabIndex = 5;
         this.lblPackageNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPackageID
         // 
         this.lblPackageID.Location = new System.Drawing.Point(19, 28);
         this.lblPackageID.Name = "lblPackageID";
         this.lblPackageID.Size = new System.Drawing.Size(84, 24);
         this.lblPackageID.TabIndex = 4;
         this.lblPackageID.Text = "Package ID:";
         this.lblPackageID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // fraListByState
         // 
         this.fraListByState.Controls.Add(this.btnShip);
         this.fraListByState.Controls.Add(this.lstPackages);
         this.fraListByState.Controls.Add(this.cboViewPackages);
         this.fraListByState.Location = new System.Drawing.Point(584, 16);
         this.fraListByState.Name = "fraListByState";
         this.fraListByState.Size = new System.Drawing.Size(141, 208);
         this.fraListByState.TabIndex = 7;
         this.fraListByState.TabStop = false;
         this.fraListByState.Text = "Packages by State";
         // 
         // btnShip
         // 
         this.btnShip.Enabled = false;
         this.btnShip.Location = new System.Drawing.Point(32, 168);
         this.btnShip.Name = "btnShip";
         this.btnShip.Size = new System.Drawing.Size(75, 26);
         this.btnShip.TabIndex = 3;
         this.btnShip.Text = "S&hip";
         // 
         // lstPackages
         // 
         this.lstPackages.Location = new System.Drawing.Point(19, 65);
         this.lstPackages.Name = "lstPackages";
         this.lstPackages.Size = new System.Drawing.Size(103, 82);
         this.lstPackages.TabIndex = 1;
         this.lstPackages.TabStop = false;
         this.lstPackages.DoubleClick += new System.EventHandler(this.lstPackages_DoubleClick);
         // 
         // cboViewPackages
         // 
         this.cboViewPackages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboViewPackages.Items.AddRange(new object[] {
                                                             "AL",
                                                             "FL",
                                                             "GA",
                                                             "KY",
                                                             "MS",
                                                             "NC",
                                                             "SC",
                                                             "TN",
                                                             "VA",
                                                             "WV"});
         this.cboViewPackages.Location = new System.Drawing.Point(19, 29);
         this.cboViewPackages.Name = "cboViewPackages";
         this.cboViewPackages.Size = new System.Drawing.Size(103, 21);
         this.cboViewPackages.Sorted = true;
         this.cboViewPackages.TabIndex = 0;
         this.cboViewPackages.SelectedIndexChanged += new System.EventHandler(this.cboViewPackages_SelectedIndexChanged);
         // 
         // btnBack
         // 
         this.btnBack.Enabled = false;
         this.btnBack.Location = new System.Drawing.Point(19, 253);
         this.btnBack.Name = "btnBack";
         this.btnBack.Size = new System.Drawing.Size(75, 26);
         this.btnBack.TabIndex = 5;
         this.btnBack.TabStop = false;
         this.btnBack.Text = "< &BACK";
         this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
         // 
         // btnNew
         // 
         this.btnNew.Location = new System.Drawing.Point(114, 253);
         this.btnNew.Name = "btnNew";
         this.btnNew.Size = new System.Drawing.Size(75, 26);
         this.btnNew.TabIndex = 1;
         this.btnNew.Text = "&Scan New";
         this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
         // 
         // btnAdd
         // 
         this.btnAdd.Enabled = false;
         this.btnAdd.Location = new System.Drawing.Point(210, 253);
         this.btnAdd.Name = "btnAdd";
         this.btnAdd.Size = new System.Drawing.Size(75, 26);
         this.btnAdd.TabIndex = 2;
         this.btnAdd.TabStop = false;
         this.btnAdd.Text = "&Add";
         this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
         // 
         // btnRemove
         // 
         this.btnRemove.Enabled = false;
         this.btnRemove.Location = new System.Drawing.Point(305, 253);
         this.btnRemove.Name = "btnRemove";
         this.btnRemove.Size = new System.Drawing.Size(75, 26);
         this.btnRemove.TabIndex = 3;
         this.btnRemove.TabStop = false;
         this.btnRemove.Text = "&Remove";
         this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
         // 
         // btnEditUpdate
         // 
         this.btnEditUpdate.Enabled = false;
         this.btnEditUpdate.Location = new System.Drawing.Point(400, 253);
         this.btnEditUpdate.Name = "btnEditUpdate";
         this.btnEditUpdate.Size = new System.Drawing.Size(76, 26);
         this.btnEditUpdate.TabIndex = 4;
         this.btnEditUpdate.TabStop = false;
         this.btnEditUpdate.Text = "&Edit";
         this.btnEditUpdate.Click += new System.EventHandler(this.btnEditUpdate_Click);
         // 
         // btnNext
         // 
         this.btnNext.Enabled = false;
         this.btnNext.Location = new System.Drawing.Point(496, 253);
         this.btnNext.Name = "btnNext";
         this.btnNext.Size = new System.Drawing.Size(75, 26);
         this.btnNext.TabIndex = 6;
         this.btnNext.TabStop = false;
         this.btnNext.Text = "&NEXT >";
         this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
         // 
         // fraPackagesToShip
         // 
         this.fraPackagesToShip.Controls.Add(this.lstTruck);
         this.fraPackagesToShip.Location = new System.Drawing.Point(584, 240);
         this.fraPackagesToShip.Name = "fraPackagesToShip";
         this.fraPackagesToShip.Size = new System.Drawing.Size(141, 128);
         this.fraPackagesToShip.TabIndex = 10;
         this.fraPackagesToShip.TabStop = false;
         this.fraPackagesToShip.Text = "Packages to Ship";
         // 
         // lstTruck
         // 
         this.lstTruck.Location = new System.Drawing.Point(19, 40);
         this.lstTruck.Name = "lstTruck";
         this.lstTruck.Size = new System.Drawing.Size(103, 69);
         this.lstTruck.TabIndex = 0;
         this.lstTruck.TabStop = false;
         // 
         // FrmShippingHub
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(736, 381);
         this.Controls.Add(this.fraPackagesToShip);
         this.Controls.Add(this.btnNext);
         this.Controls.Add(this.btnEditUpdate);
         this.Controls.Add(this.btnRemove);
         this.Controls.Add(this.btnAdd);
         this.Controls.Add(this.btnNew);
         this.Controls.Add(this.btnBack);
         this.Controls.Add(this.fraAddress);
         this.Controls.Add(this.lblArrivalTime);
         this.Controls.Add(this.lblArrived);
         this.Controls.Add(this.fraListByState);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmShippingHub";
         this.Text = "Shipping Hub";
         this.Load += new System.EventHandler(this.FrmShippingHub_Load);
         this.fraAddress.ResumeLayout(false);
         this.fraListByState.ResumeLayout(false);
         this.fraPackagesToShip.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmShippingHub() );
      }

      // Form Load event
      private void FrmShippingHub_Load(
         object sender, System.EventArgs e )
      {
         m_intPosition = 0; // set initial position to zero
         m_objRandom = new Random(); // create new Random object
         m_intPackageID = m_objRandom.Next(
            1, 100000 ); // new package ID

         // show first state in ComboBox (using the Items property)
         cboState.Text = Convert.ToString( 
            cboState.Items[ 0 ] );
         m_objList = new ArrayList(); // list of packages
         m_objTruckList = new ArrayList(); // truck list

      } // end method FrmShippingHub_Load

      // New Button Click event
      private void btnNew_Click( 
         object sender, System.EventArgs e )
      {
         m_intPackageID++; // increment package ID
         m_objPackage = new Package(
            m_intPackageID ); // create package

         ClearControls(); // clear fields

         // display package number and arrival time
         lblPackageNumber.Text =
            m_objPackage.PackageNumber.ToString();
         lblArrivalTime.Text =
            m_objPackage.ArrivalTime.ToString();

         // only allow user to add package
         fraAddress.Enabled = true; // disable GroupBox and controls
         SetButtons( false ); // enable/disable Buttons
         btnAdd.Enabled = true; // enable Add Button
         btnNew.Enabled = false; // disable Scan New Button
         txtAddress.Focus(); // transfer focus to txtAddress TextBox
 
      } // end method btnNew_Click

      // Add Button Click event
      private void btnAdd_Click( 
         object sender, System.EventArgs e )
      {
         SetPackage(); // set Package properties from TextBoxes
         m_objList.Add( m_objPackage ); // add package to ArrayList

         // disable GroupBox and its controls
         fraAddress.Enabled = false; 
         SetButtons( true ); // enable appropriate Buttons

         // package cannot be added until Scan New is clicked
         btnAdd.Enabled = false; // disable Add Button

         // if package's state displayed, add ID to ListBox
         if ( cboState.Text == cboViewPackages.Text )
         {
            lstPackages.Items.Add( m_objPackage.PackageNumber );
         }

         cboViewPackages.Text = m_objPackage.State; // list packages
         btnNew.Enabled = true; // enable Scan New Button

      } // end method btnAdd_Click

      // Back Button Click event
      private void btnBack_Click( 
         object sender, System.EventArgs e )
      {
         // move backward one package in the list
         if ( m_intPosition > 0 )
         {
            m_intPosition--;
         }
         else // wrap to end of list
         {
            m_intPosition = m_objList.Count - 1;
         }

         LoadPackage(); // load package data from item in list
      
      } // end method btnBack_Click

      // Next Button Click event
      private void btnNext_Click( 
         object sender, System.EventArgs e )
      {
         // move forward one package in the list
         if ( m_intPosition < m_objList.Count - 1 )
         {
            m_intPosition++;
         }
         else
         {
            m_intPosition = 0; // wrap to beginning of list
         }

         LoadPackage(); // load package data from item in list

      } // end method btnNext_Click

      // Remove Button Click Event
      private void btnRemove_Click(
         object sender, System.EventArgs e )
      {
         // remove ID from ListBox if state displayed
         if ( cboState.Text == cboViewPackages.Text )
         {
            lstPackages.Items.Remove( m_objPackage.PackageNumber );
         }
      
         // remove package from list
         m_objList.RemoveAt( m_intPosition );

         // load next package in list if there is one
         if ( m_objList.Count > 0 )
         {
            // if not at first position, go to previous one
            if ( m_intPosition > 0 )
            {
               m_intPosition--;
            }
            
            LoadPackage(); //load package data from item in list
         }
         else
         {
            ClearControls(); // clear fields
         }

         SetButtons( true ); // enable appropriate Buttons

      } // end method btnRemove_Click

      // Edit Button Click event
      private void btnEditUpdate_Click( 
         object sender, System.EventArgs e )
      {
         // when Button reads "Edit", allow user to
         // edit package information only
         if ( btnEditUpdate.Text == "&Edit" )
         {
            fraAddress.Enabled = true;
            SetButtons( false );
            btnEditUpdate.Enabled = true;

            // change Button text from "Edit" to "Update"
            btnEditUpdate.Text = "&Update";
         }
         else
         {
            // when Button reads "Update" remove the old package
            // data and add new data from TextBoxes
            SetPackage();
            m_objList.RemoveAt( m_intPosition );
            m_objList.Insert( m_intPosition, m_objPackage );

            // display state in ComboBox
            cboViewPackages.Text = m_objPackage.State;

            // when done, return to normal operating state
            fraAddress.Enabled = false; // disable GroupBox
            SetButtons( true ); // enable appropriate Buttons

            // change Button text from "Update" to "Edit"
            btnEditUpdate.Text = "&Edit";

         } // end if

      } // end method btnEditUpdate_Click

      // set package properties
      private void SetPackage()
      {
         m_objPackage.Address = txtAddress.Text;
         m_objPackage.City = txtCity.Text;
         m_objPackage.State =
            Convert.ToString( cboState.SelectedItem );
         m_objPackage.Zip = Int32.Parse( txtZip.Text );

      } // end method SetPackage

      // load package information into Form
      private void LoadPackage()
      {
         // retrieve package from list
         m_objPackage = ( Package ) m_objList[ m_intPosition ];

         // display package data
         txtAddress.Text = m_objPackage.Address;
         txtCity.Text = m_objPackage.City;
         cboState.Text = m_objPackage.State;
         txtZip.Text = m_objPackage.Zip.ToString( "00000" );
         lblArrivalTime.Text = 
            m_objPackage.ArrivalTime.ToString();
         lblPackageNumber.Text =
            m_objPackage.PackageNumber.ToString();

      } // end method LoadPackage

      // clear all the input controls on the Form
      private void ClearControls()
      {
         txtAddress.Clear();
         txtCity.Clear();
         txtZip.Clear();
         cboState.SelectedText = "";
         lblArrivalTime.Text = "";
         lblPackageNumber.Text = "";

      } // end method ClearControls

      // enable/disable Buttons
      private void SetButtons( bool blnState )
      {
         btnRemove.Enabled = blnState;
         btnEditUpdate.Enabled = blnState;
         btnNext.Enabled = blnState;
         btnBack.Enabled = blnState;

         // disable navigation if not multiple packages
         if ( m_objList.Count < 1 )
         {
            btnNext.Enabled = false;
            btnBack.Enabled = false;
         }

         // if no items, disable Remove and Edit/Update Buttons
         if ( m_objList.Count == 0 )
         {
            btnEditUpdate.Enabled = false;
            btnRemove.Enabled = false;
         }

      } // end method SetButtons                                           

      // event raised when user selects a new state in ComboBox
      private void cboViewPackages_SelectedIndexChanged(
         object sender, System.EventArgs e )
      {
         string strState =
            Convert.ToString( cboViewPackages.SelectedItem );

         lstPackages.Items.Clear(); // clear ListBox

         // list all packages for current state in ListBox
         foreach ( Package objViewPackage in m_objList)
         {
            // determine if state package is being shipped to
            // matches the state selected in the ComboBox
            if ( objViewPackage.State == strState )
            {
               // add package number to the ListBox
               lstPackages.Items.Add( 
                  objViewPackage.PackageNumber );
            }

         } // end foreach

      } // end method cboViewPackages_SelectedIndexChanged

      // display package information for selected package
      private void lstPackages_DoubleClick( 
         object sender, System.EventArgs e )
      {
         // place code from Exercise 20.12 (Modified Shipping Hub)
         // here
     
      } // end method lstPackages_DoubleClick

   } // end class FrmShippingHub
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/