using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace AdvancedPainter
{
   /// <summary>
   /// Summary description for FrmAdvancedPainter.
   /// </summary>
   public class FrmAdvancedPainter : System.Windows.Forms.Form
   {
      // GroupBox containing RadioButtons to choose color
      private System.Windows.Forms.GroupBox grpColor;
      private System.Windows.Forms.RadioButton radBlack;
      private System.Windows.Forms.RadioButton radGreen;
      private System.Windows.Forms.RadioButton radBlue;
      private System.Windows.Forms.RadioButton radRed;

      // GroupBox containing RadioButtons to choose size
      private System.Windows.Forms.GroupBox grpSize;
      private System.Windows.Forms.RadioButton radLarge;
      private System.Windows.Forms.RadioButton radMedium;
      private System.Windows.Forms.RadioButton radSmall;

      // Panel for drawing area
      private System.Windows.Forms.Panel pnlPainter;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // create Color object and initialize to Black
      private Color m_clrBrushColor = Color.Black;

      // specify whether application should paint
      private bool m_blnShouldPaint = false;

      // specify whether application should erase
      private bool m_blnShouldErase = false;

      // diameter of MouseDown circle (initially set to small)
      private int m_intDiameter = 4;

      public FrmAdvancedPainter()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.grpColor = new System.Windows.Forms.GroupBox();
         this.radBlack = new System.Windows.Forms.RadioButton();
         this.radGreen = new System.Windows.Forms.RadioButton();
         this.radBlue = new System.Windows.Forms.RadioButton();
         this.radRed = new System.Windows.Forms.RadioButton();
         this.grpSize = new System.Windows.Forms.GroupBox();
         this.radLarge = new System.Windows.Forms.RadioButton();
         this.radMedium = new System.Windows.Forms.RadioButton();
         this.radSmall = new System.Windows.Forms.RadioButton();
         this.pnlPainter = new System.Windows.Forms.Panel();
         this.grpColor.SuspendLayout();
         this.grpSize.SuspendLayout();
         this.SuspendLayout();
         // 
         // grpColor
         // 
         this.grpColor.Controls.Add(this.radBlack);
         this.grpColor.Controls.Add(this.radGreen);
         this.grpColor.Controls.Add(this.radBlue);
         this.grpColor.Controls.Add(this.radRed);
         this.grpColor.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.grpColor.Location = new System.Drawing.Point(8, 8);
         this.grpColor.Name = "grpColor";
         this.grpColor.Size = new System.Drawing.Size(96, 152);
         this.grpColor.TabIndex = 5;
         this.grpColor.TabStop = false;
         this.grpColor.Text = "Color";
         // 
         // radBlack
         // 
         this.radBlack.Checked = true;
         this.radBlack.Location = new System.Drawing.Point(16, 120);
         this.radBlack.Name = "radBlack";
         this.radBlack.Size = new System.Drawing.Size(56, 24);
         this.radBlack.TabIndex = 3;
         this.radBlack.TabStop = true;
         this.radBlack.Text = "Black";
         // 
         // radGreen
         // 
         this.radGreen.Location = new System.Drawing.Point(16, 88);
         this.radGreen.Name = "radGreen";
         this.radGreen.Size = new System.Drawing.Size(64, 24);
         this.radGreen.TabIndex = 2;
         this.radGreen.Text = "Green";
         // 
         // radBlue
         // 
         this.radBlue.Location = new System.Drawing.Point(16, 56);
         this.radBlue.Name = "radBlue";
         this.radBlue.Size = new System.Drawing.Size(56, 24);
         this.radBlue.TabIndex = 1;
         this.radBlue.Text = "Blue";
         // 
         // radRed
         // 
         this.radRed.Location = new System.Drawing.Point(16, 24);
         this.radRed.Name = "radRed";
         this.radRed.Size = new System.Drawing.Size(56, 24);
         this.radRed.TabIndex = 0;
         this.radRed.Text = "Red";
         // 
         // grpSize
         // 
         this.grpSize.Controls.Add(this.radLarge);
         this.grpSize.Controls.Add(this.radMedium);
         this.grpSize.Controls.Add(this.radSmall);
         this.grpSize.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.grpSize.Location = new System.Drawing.Point(8, 168);
         this.grpSize.Name = "grpSize";
         this.grpSize.Size = new System.Drawing.Size(96, 112);
         this.grpSize.TabIndex = 6;
         this.grpSize.TabStop = false;
         this.grpSize.Text = "Size";
         // 
         // radLarge
         // 
         this.radLarge.Location = new System.Drawing.Point(16, 80);
         this.radLarge.Name = "radLarge";
         this.radLarge.Size = new System.Drawing.Size(64, 24);
         this.radLarge.TabIndex = 2;
         this.radLarge.Text = "Large";
         // 
         // radMedium
         // 
         this.radMedium.Location = new System.Drawing.Point(16, 56);
         this.radMedium.Name = "radMedium";
         this.radMedium.Size = new System.Drawing.Size(72, 16);
         this.radMedium.TabIndex = 1;
         this.radMedium.Text = "Medium";
         // 
         // radSmall
         // 
         this.radSmall.Checked = true;
         this.radSmall.Location = new System.Drawing.Point(16, 24);
         this.radSmall.Name = "radSmall";
         this.radSmall.Size = new System.Drawing.Size(64, 24);
         this.radSmall.TabIndex = 0;
         this.radSmall.TabStop = true;
         this.radSmall.Text = "Small";
         // 
         // pnlPainter
         // 
         this.pnlPainter.BackColor = System.Drawing.Color.White;
         this.pnlPainter.Location = new System.Drawing.Point(112, 8);
         this.pnlPainter.Name = "pnlPainter";
         this.pnlPainter.Size = new System.Drawing.Size(336, 272);
         this.pnlPainter.TabIndex = 7;
         // 
         // FrmAdvancedPainter
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(456, 285);
         this.Controls.Add(this.pnlPainter);
         this.Controls.Add(this.grpColor);
         this.Controls.Add(this.grpSize);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmAdvancedPainter";
         this.Text = "Advanced Painter";
         this.grpColor.ResumeLayout(false);
         this.grpSize.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmAdvancedPainter() );
      }

   } // end class FrmAdvancedPainter
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/