using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace LineLength
{
   /// <summary>
   /// Summary description for FrmLineLength.
   /// </summary>
   public class FrmLineLength : System.Windows.Forms.Form
   {
      // Labels to display length of line drawn
      private System.Windows.Forms.Label lblOutput;
      private System.Windows.Forms.Label lblLength;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmLineLength()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblOutput = new System.Windows.Forms.Label();
         this.lblLength = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // lblOutput
         // 
         this.lblOutput.Location = new System.Drawing.Point(8, 240);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(64, 24);
         this.lblOutput.TabIndex = 1;
         this.lblOutput.Text = "Length =";
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblLength
         // 
         this.lblLength.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblLength.Location = new System.Drawing.Point(72, 240);
         this.lblLength.Name = "lblLength";
         this.lblLength.Size = new System.Drawing.Size(48, 24);
         this.lblLength.TabIndex = 2;
         this.lblLength.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // FrmLineLength
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(292, 273);
         this.Controls.Add(this.lblLength);
         this.Controls.Add(this.lblOutput);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmLineLength";
         this.Text = "Line Length";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmLineLength() );
      }

   } // end class FrmLineLength
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
