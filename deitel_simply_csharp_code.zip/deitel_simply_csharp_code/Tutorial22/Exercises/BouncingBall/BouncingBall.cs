using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace BouncingBall
{
   /// <summary>
   /// Summary description for FrmBouncingBall.
   /// </summary>
   public class FrmBouncingBall : System.Windows.Forms.Form
   {
      // Timer to control the speed of the ball
      private System.Windows.Forms.Timer tmrMoveBall;

      // Timer to control the size of the paddle
      private System.Windows.Forms.Timer tmrShrinkSlider;

      private System.ComponentModel.IContainer components;

      private int intX; // ball's x-coordinate
      private int intY; // ball's y-coordinate
      private int intRectangleX; // paddle's x-coordinate
      private int intRectangleWidth; // paddle's width

      private int intDeltaX; // ball's x rate of change
      private int intDeltaY; // ball's y rate of change

      private bool xLeft; //  tests if ball can move left
      private bool yUp; // tests if ball can move up

      private const int intMAX_X = 400; // x boundary
      private const int intMAX_Y = 400; // y boundary

      // object to generate random numbers
      private Random objRandom = new Random();

      public FrmBouncingBall()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.tmrMoveBall = new System.Windows.Forms.Timer(this.components);
         this.tmrShrinkSlider = new System.Windows.Forms.Timer(this.components);
         // 
         // tmrMoveBall
         // 
         this.tmrMoveBall.Interval = 20;
         this.tmrMoveBall.Tick += new System.EventHandler(this.tmrMoveBall_Tick);
         // 
         // tmrShrinkSlider
         // 
         this.tmrShrinkSlider.Interval = 30000;
         this.tmrShrinkSlider.Tick += new System.EventHandler(this.tmrShrinkSlider_Tick);
         // 
         // FrmBouncingBall
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(400, 400);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmBouncingBall";
         this.Text = "Bouncing Ball";
         this.Load += new System.EventHandler(this.FrmBouncingBall_Load);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmBouncingBall() );
      }

      // handles Form's Load event
      private void FrmBouncingBall_Load( 
         object sender, System.EventArgs e )
      {
         intX = objRandom.Next( 100, 301 ); // ball's initial x
         intY = objRandom.Next( 100, 301 ); // ball's initial y
         intRectangleX = 175; // rectangle's intial x position
         intRectangleWidth = 80; // rectangle's intial width

         xLeft = false; // ball can move left
         yUp = false; // ball can move up
         intDeltaX = 2; // move ball 2 positions right
         intDeltaY = 2; // move ball 2 positions down
      
      } // end method FrmBouncingBall_Load

      // method to draw the ball and paddle
      protected override void OnPaint( PaintEventArgs paintEvent )
      {
         // create graphics object
         Graphics objGraphic = CreateGraphics();

         // create new bruch
         SolidBrush objBrush = new SolidBrush( Color.Blue );

         // draw ball
         objGraphic.FillEllipse( objBrush, intX, intY, 10, 10 );

         // set color for, and draw paddle
         objBrush.Color = Color.Brown;
         objGraphic.FillRectangle(
            objBrush, intRectangleX, 380, intRectangleWidth, 15 );
      
      } // end method OnPaint

      // move the ball every tick
      private void tmrMoveBall_Tick( 
         object sender, System.EventArgs e )
      {
         // determine new x position
         if ( xLeft == true )
         {
            intX += intDeltaX;
         }
         else 
         {
            intX -= intDeltaX;
         }
      
         // determine new y position
         if ( yUp )
         {
            intY += intDeltaY;
         }
         else 
         {
            intY -= intDeltaY;
         }

         if ( intY <= 0 )
         {
            yUp = true;
            intDeltaY = objRandom.Next( 2, 6 );
         }
         else if ( intY >= 370 && intX >= intRectangleX 
            && intX <= ( intRectangleX + intRectangleWidth ) )
         {
            yUp = false;
            intDeltaY = objRandom.Next( 2, 6 );
         }
         else if ( intY >= 410 ) // end game if ball hits floor
         {
            tmrMoveBall.Enabled = false;
            tmrShrinkSlider.Enabled = false;
            MessageBox.Show( "Game Over" );
         }

         if ( intX <= 0 )
         {
            xLeft = true;
            intDeltaX = objRandom.Next( 2, 6 );
         }
         else if ( intX >= intMAX_X - 10 )
         {
            xLeft = false;
            intDeltaX = objRandom.Next( 2, 6 );
         }

         Invalidate(); // Refresh Form
      
      } // end method tmrMoveBall_Tick

      // shrinks the paddle every 30 seconds
      private void tmrShrinkSlider_Tick( 
         object sender, System.EventArgs e )
      {
         // shrink paddle if paddle greater than twice ball's width
         if ( intRectangleWidth >= 20 )
         {
            intRectangleWidth = intRectangleWidth / 2;
         }
      
      } // end method tmrShrinkSlider_Tick

   } // end class FrmBouncingBall
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/