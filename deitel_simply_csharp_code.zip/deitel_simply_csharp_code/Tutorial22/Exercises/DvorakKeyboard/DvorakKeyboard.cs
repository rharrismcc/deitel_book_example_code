using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DvorakKeyboard
{
   /// <summary>
   /// Summary description for FrmDvorakKeyboard.
   /// </summary>
   public class FrmDvorakKeyboard : System.Windows.Forms.Form
   {
      // Label to display directions to the user
      private System.Windows.Forms.Label lblPrompt;

      // TextBox to display output from typing
      private System.Windows.Forms.RichTextBox txtOutput;

      // Buttons to represent keys on the keyboard
      private System.Windows.Forms.Button btnP;
      private System.Windows.Forms.Button btnY;
      private System.Windows.Forms.Button btnF;
      private System.Windows.Forms.Button btnG;
      private System.Windows.Forms.Button btnC;
      private System.Windows.Forms.Button btnR;
      private System.Windows.Forms.Button btnL;
      private System.Windows.Forms.Button btnA;
      private System.Windows.Forms.Button btnO;
      private System.Windows.Forms.Button btnE;
      private System.Windows.Forms.Button btnU;
      private System.Windows.Forms.Button btnI;
      private System.Windows.Forms.Button btnD;
      private System.Windows.Forms.Button btnH;
      private System.Windows.Forms.Button btnT;
      private System.Windows.Forms.Button btnN;
      private System.Windows.Forms.Button btnS;
      private System.Windows.Forms.Button btnQ;
      private System.Windows.Forms.Button btnJ;
      private System.Windows.Forms.Button btnK;
      private System.Windows.Forms.Button btnX;
      private System.Windows.Forms.Button btnB;
      private System.Windows.Forms.Button btnM;
      private System.Windows.Forms.Button btnW;
      private System.Windows.Forms.Button btnV;
      private System.Windows.Forms.Button btnZ;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // reference to last Button pressed
      Button m_btnLastButton;

      public FrmDvorakKeyboard()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblPrompt = new System.Windows.Forms.Label();
         this.txtOutput = new System.Windows.Forms.RichTextBox();
         this.btnP = new System.Windows.Forms.Button();
         this.btnY = new System.Windows.Forms.Button();
         this.btnF = new System.Windows.Forms.Button();
         this.btnG = new System.Windows.Forms.Button();
         this.btnC = new System.Windows.Forms.Button();
         this.btnR = new System.Windows.Forms.Button();
         this.btnL = new System.Windows.Forms.Button();
         this.btnA = new System.Windows.Forms.Button();
         this.btnO = new System.Windows.Forms.Button();
         this.btnE = new System.Windows.Forms.Button();
         this.btnU = new System.Windows.Forms.Button();
         this.btnI = new System.Windows.Forms.Button();
         this.btnD = new System.Windows.Forms.Button();
         this.btnH = new System.Windows.Forms.Button();
         this.btnT = new System.Windows.Forms.Button();
         this.btnN = new System.Windows.Forms.Button();
         this.btnS = new System.Windows.Forms.Button();
         this.btnQ = new System.Windows.Forms.Button();
         this.btnJ = new System.Windows.Forms.Button();
         this.btnK = new System.Windows.Forms.Button();
         this.btnX = new System.Windows.Forms.Button();
         this.btnB = new System.Windows.Forms.Button();
         this.btnM = new System.Windows.Forms.Button();
         this.btnW = new System.Windows.Forms.Button();
         this.btnV = new System.Windows.Forms.Button();
         this.btnZ = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblPrompt
         // 
         this.lblPrompt.Location = new System.Drawing.Point(16, 8);
         this.lblPrompt.Name = "lblPrompt";
         this.lblPrompt.Size = new System.Drawing.Size(248, 56);
         this.lblPrompt.TabIndex = 65;
         this.lblPrompt.Text = "Type some text using your keyboard. We will display your text and highlight the k" +
            "eys as you go. Note: Clicking the Buttons with your mouse will not perform any a" +
            "ction.";
         // 
         // txtOutput
         // 
         this.txtOutput.AcceptsTab = true;
         this.txtOutput.Font = new System.Drawing.Font("Tahoma", 10.2F);
         this.txtOutput.Location = new System.Drawing.Point(16, 72);
         this.txtOutput.Name = "txtOutput";
         this.txtOutput.ReadOnly = true;
         this.txtOutput.Size = new System.Drawing.Size(248, 136);
         this.txtOutput.TabIndex = 66;
         this.txtOutput.Text = "";
         this.txtOutput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtOutput_KeyUp);
         // 
         // btnP
         // 
         this.btnP.Location = new System.Drawing.Point(80, 216);
         this.btnP.Name = "btnP";
         this.btnP.Size = new System.Drawing.Size(24, 23);
         this.btnP.TabIndex = 67;
         this.btnP.Text = "P";
         // 
         // btnY
         // 
         this.btnY.Location = new System.Drawing.Point(104, 216);
         this.btnY.Name = "btnY";
         this.btnY.Size = new System.Drawing.Size(24, 23);
         this.btnY.TabIndex = 68;
         this.btnY.Text = "Y";
         // 
         // btnF
         // 
         this.btnF.Location = new System.Drawing.Point(128, 216);
         this.btnF.Name = "btnF";
         this.btnF.Size = new System.Drawing.Size(24, 23);
         this.btnF.TabIndex = 69;
         this.btnF.Text = "F";
         // 
         // btnG
         // 
         this.btnG.Location = new System.Drawing.Point(152, 216);
         this.btnG.Name = "btnG";
         this.btnG.Size = new System.Drawing.Size(24, 23);
         this.btnG.TabIndex = 70;
         this.btnG.Text = "G";
         // 
         // btnC
         // 
         this.btnC.Location = new System.Drawing.Point(176, 216);
         this.btnC.Name = "btnC";
         this.btnC.Size = new System.Drawing.Size(24, 23);
         this.btnC.TabIndex = 71;
         this.btnC.Text = "C";
         // 
         // btnR
         // 
         this.btnR.Location = new System.Drawing.Point(200, 216);
         this.btnR.Name = "btnR";
         this.btnR.Size = new System.Drawing.Size(24, 23);
         this.btnR.TabIndex = 72;
         this.btnR.Text = "R";
         // 
         // btnL
         // 
         this.btnL.Location = new System.Drawing.Point(224, 216);
         this.btnL.Name = "btnL";
         this.btnL.Size = new System.Drawing.Size(24, 23);
         this.btnL.TabIndex = 73;
         this.btnL.Text = "L";
         // 
         // btnA
         // 
         this.btnA.Location = new System.Drawing.Point(16, 240);
         this.btnA.Name = "btnA";
         this.btnA.Size = new System.Drawing.Size(24, 23);
         this.btnA.TabIndex = 74;
         this.btnA.Text = "A";
         // 
         // btnO
         // 
         this.btnO.Location = new System.Drawing.Point(40, 240);
         this.btnO.Name = "btnO";
         this.btnO.Size = new System.Drawing.Size(24, 23);
         this.btnO.TabIndex = 75;
         this.btnO.Text = "O";
         // 
         // btnE
         // 
         this.btnE.Location = new System.Drawing.Point(64, 240);
         this.btnE.Name = "btnE";
         this.btnE.Size = new System.Drawing.Size(24, 23);
         this.btnE.TabIndex = 76;
         this.btnE.Text = "E";
         // 
         // btnU
         // 
         this.btnU.Location = new System.Drawing.Point(88, 240);
         this.btnU.Name = "btnU";
         this.btnU.Size = new System.Drawing.Size(24, 23);
         this.btnU.TabIndex = 77;
         this.btnU.Text = "U";
         // 
         // btnI
         // 
         this.btnI.Location = new System.Drawing.Point(112, 240);
         this.btnI.Name = "btnI";
         this.btnI.Size = new System.Drawing.Size(24, 23);
         this.btnI.TabIndex = 78;
         this.btnI.Text = "I";
         // 
         // btnD
         // 
         this.btnD.Location = new System.Drawing.Point(136, 240);
         this.btnD.Name = "btnD";
         this.btnD.Size = new System.Drawing.Size(24, 23);
         this.btnD.TabIndex = 79;
         this.btnD.Text = "D";
         // 
         // btnH
         // 
         this.btnH.Location = new System.Drawing.Point(160, 240);
         this.btnH.Name = "btnH";
         this.btnH.Size = new System.Drawing.Size(24, 23);
         this.btnH.TabIndex = 80;
         this.btnH.Text = "H";
         // 
         // btnT
         // 
         this.btnT.Location = new System.Drawing.Point(184, 240);
         this.btnT.Name = "btnT";
         this.btnT.Size = new System.Drawing.Size(24, 23);
         this.btnT.TabIndex = 81;
         this.btnT.Text = "T";
         // 
         // btnN
         // 
         this.btnN.Location = new System.Drawing.Point(208, 240);
         this.btnN.Name = "btnN";
         this.btnN.Size = new System.Drawing.Size(24, 23);
         this.btnN.TabIndex = 82;
         this.btnN.Text = "N";
         // 
         // btnS
         // 
         this.btnS.Location = new System.Drawing.Point(232, 240);
         this.btnS.Name = "btnS";
         this.btnS.Size = new System.Drawing.Size(24, 23);
         this.btnS.TabIndex = 83;
         this.btnS.Text = "S";
         // 
         // btnQ
         // 
         this.btnQ.Location = new System.Drawing.Point(56, 264);
         this.btnQ.Name = "btnQ";
         this.btnQ.Size = new System.Drawing.Size(24, 23);
         this.btnQ.TabIndex = 84;
         this.btnQ.Text = "Q";
         // 
         // btnJ
         // 
         this.btnJ.Location = new System.Drawing.Point(80, 264);
         this.btnJ.Name = "btnJ";
         this.btnJ.Size = new System.Drawing.Size(24, 23);
         this.btnJ.TabIndex = 85;
         this.btnJ.Text = "J";
         // 
         // btnK
         // 
         this.btnK.Location = new System.Drawing.Point(104, 264);
         this.btnK.Name = "btnK";
         this.btnK.Size = new System.Drawing.Size(24, 23);
         this.btnK.TabIndex = 86;
         this.btnK.Text = "K";
         // 
         // btnX
         // 
         this.btnX.Location = new System.Drawing.Point(128, 264);
         this.btnX.Name = "btnX";
         this.btnX.Size = new System.Drawing.Size(24, 23);
         this.btnX.TabIndex = 87;
         this.btnX.Text = "X";
         // 
         // btnB
         // 
         this.btnB.Location = new System.Drawing.Point(152, 264);
         this.btnB.Name = "btnB";
         this.btnB.Size = new System.Drawing.Size(24, 23);
         this.btnB.TabIndex = 88;
         this.btnB.Text = "B";
         // 
         // btnM
         // 
         this.btnM.Location = new System.Drawing.Point(176, 264);
         this.btnM.Name = "btnM";
         this.btnM.Size = new System.Drawing.Size(24, 23);
         this.btnM.TabIndex = 89;
         this.btnM.Text = "M";
         // 
         // btnW
         // 
         this.btnW.Location = new System.Drawing.Point(200, 264);
         this.btnW.Name = "btnW";
         this.btnW.Size = new System.Drawing.Size(24, 23);
         this.btnW.TabIndex = 90;
         this.btnW.Text = "W";
         // 
         // btnV
         // 
         this.btnV.Location = new System.Drawing.Point(224, 264);
         this.btnV.Name = "btnV";
         this.btnV.Size = new System.Drawing.Size(24, 23);
         this.btnV.TabIndex = 91;
         this.btnV.Text = "V";
         // 
         // btnZ
         // 
         this.btnZ.Location = new System.Drawing.Point(248, 264);
         this.btnZ.Name = "btnZ";
         this.btnZ.Size = new System.Drawing.Size(24, 23);
         this.btnZ.TabIndex = 92;
         this.btnZ.Text = "Z";
         // 
         // FrmDvorakKeyboard
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(288, 301);
         this.Controls.Add(this.btnZ);
         this.Controls.Add(this.btnV);
         this.Controls.Add(this.btnW);
         this.Controls.Add(this.btnM);
         this.Controls.Add(this.btnB);
         this.Controls.Add(this.btnX);
         this.Controls.Add(this.btnK);
         this.Controls.Add(this.btnJ);
         this.Controls.Add(this.btnQ);
         this.Controls.Add(this.btnS);
         this.Controls.Add(this.btnN);
         this.Controls.Add(this.btnT);
         this.Controls.Add(this.btnH);
         this.Controls.Add(this.btnD);
         this.Controls.Add(this.btnI);
         this.Controls.Add(this.btnU);
         this.Controls.Add(this.btnE);
         this.Controls.Add(this.btnO);
         this.Controls.Add(this.btnA);
         this.Controls.Add(this.btnL);
         this.Controls.Add(this.btnR);
         this.Controls.Add(this.btnC);
         this.Controls.Add(this.btnG);
         this.Controls.Add(this.btnF);
         this.Controls.Add(this.btnY);
         this.Controls.Add(this.btnP);
         this.Controls.Add(this.txtOutput);
         this.Controls.Add(this.lblPrompt);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmDvorakKeyboard";
         this.Text = "Dvorak Keyboard";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmDvorakKeyboard() );
      }

      // handles TextBox's KeyUp event
      private void txtOutput_KeyUp( 
         object sender, System.Windows.Forms.KeyEventArgs e )
      {
         ResetColor();

      } // end method txtOutput_KeyUp

      // highlight Button passed as argument
      private void ChangeColor( Button btnButton )
      {
         ResetColor();
         btnButton.BackColor = Color.LightGoldenrodYellow;
         m_btnLastButton = btnButton;

      } // end method ChangeColor

      // changes m_btnLastButton's color if it refers to a Button
      private void ResetColor()
      {
         if ( m_btnLastButton != null )
         {
            m_btnLastButton.BackColor = SystemColors.Control;
         }

      } // end method ResetColor

   } // end class FrmDvorakKeyboard
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/