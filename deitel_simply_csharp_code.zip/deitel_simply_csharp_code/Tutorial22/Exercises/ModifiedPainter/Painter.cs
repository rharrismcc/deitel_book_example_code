using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Painter
{
   /// <summary>
   /// Summary description for FrmPainter.
   /// </summary>
   public class FrmPainter : System.Windows.Forms.Form
   {
      // TextBox to input text to accompany drawing
      private System.Windows.Forms.TextBox txtOutput;

      // MainMenu to set options
      private System.Windows.Forms.MainMenu mnuMainMenu;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // specify whether moving the mouse should erase
      private bool m_blnShouldErase = false;

      // specify whether moving the mouse should draw
      private bool m_blnShouldPaint = false;

      // diameter of MouseDown circle
      private int m_intDiameter;

      private Color m_paintColor; // paint color
      private Color m_backgroundColor; // background color

      // declare Graphics object
      private Graphics m_objGraphic;

      public FrmPainter()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.txtOutput = new System.Windows.Forms.TextBox();
         this.mnuMainMenu = new System.Windows.Forms.MainMenu();
         this.SuspendLayout();
         // 
         // txtOutput
         // 
         this.txtOutput.Location = new System.Drawing.Point(16, 16);
         this.txtOutput.Multiline = true;
         this.txtOutput.Name = "txtOutput";
         this.txtOutput.Size = new System.Drawing.Size(288, 64);
         this.txtOutput.TabIndex = 1;
         this.txtOutput.Text = "";
         // 
         // FrmPainter
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(320, 313);
         this.Controls.Add(this.txtOutput);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Menu = this.mnuMainMenu;
         this.Name = "FrmPainter";
         this.Text = "Painter";
         this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FrmPainter_MouseDown);
         this.Load += new System.EventHandler(this.FrmPainter_Load);
         this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FrmPainter_MouseUp);
         this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FrmPainter_MouseMove);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmPainter() );
      }

      // handles FrmPainter's Load event
      private void FrmPainter_Load( 
         object sender, System.EventArgs e )
      {
         m_blnShouldErase = false; // should not be painting
         m_blnShouldPaint = false; // should not be erasing
         m_intDiameter = 8; // set paint size
         m_paintColor = Color.BlueViolet; // set paint color
         m_backgroundColor = FrmPainter.DefaultBackColor;

         // create Graphics object
         m_objGraphic = CreateGraphics();
      
      } // end method FrmPainter_Load

      // handles FrmPainter's MouseDown event
      private void FrmPainter_MouseDown(
         object sender, System.Windows.Forms.MouseEventArgs e )
      {
         // draw on Form if the left button is held down
         if ( e.Button == MouseButtons.Left )
         {
            m_blnShouldPaint = true;
         }
         // erase blue-violet circles if right button is held down
         else if ( e.Button == MouseButtons.Right)
         {
            m_blnShouldErase = true;
         }

      } // end method FrmPainter_MouseDown

      private void FrmPainter_MouseUp(
         object sender, System.Windows.Forms.MouseEventArgs e)
      {
         m_blnShouldPaint = false; // do not draw on the Form
         m_blnShouldErase = false; // do not erase

      } // end method FrmPainter_MouseUp

      private void FrmPainter_MouseMove(
         object sender, System.Windows.Forms.MouseEventArgs e)
      {
         // draw circle if left mouse button is pressed
         if ( m_blnShouldPaint == true )
         {
            m_objGraphic.FillEllipse( 
               new SolidBrush( m_paintColor ),
               e.X, e.Y, m_intDiameter, m_intDiameter );
         }
         // mouse pointer "erases" if right mouse button is pressed
         else if ( m_blnShouldErase == true )
         {
            m_objGraphic.FillEllipse( 
               new SolidBrush( m_backgroundColor ),
               e.X, e.Y, m_intDiameter, m_intDiameter );
         }

      } // end method FrmPainter_MouseMove

   } // end class FrmPainter
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/