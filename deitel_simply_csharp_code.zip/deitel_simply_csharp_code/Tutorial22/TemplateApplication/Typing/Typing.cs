using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Typing
{
   /// <summary>
   /// Summary description for FrmTypingApplication.
   /// </summary>
   public class FrmTypingApplication : System.Windows.Forms.Form
   {
      // Label displaying the prompt
      private System.Windows.Forms.Label lblPrompt;

      // RichTextBox displaying the user's key strokes
      private System.Windows.Forms.RichTextBox txtOutput;

      // Buttons representing the first row of keys
      private System.Windows.Forms.Button btnF1;
      private System.Windows.Forms.Button btnF2;
      private System.Windows.Forms.Button btnF3;
      private System.Windows.Forms.Button btnF4;
      private System.Windows.Forms.Button btnF5;
      private System.Windows.Forms.Button btnF6;
      private System.Windows.Forms.Button btnF7;
      private System.Windows.Forms.Button btnF8;
      private System.Windows.Forms.Button btnF9;
      private System.Windows.Forms.Button btnF10;
      private System.Windows.Forms.Button btnF11;
      private System.Windows.Forms.Button btnF12;

      // Buttons representing the second row of keys
      private System.Windows.Forms.Button btnTilde;
      private System.Windows.Forms.Button btn1;
      private System.Windows.Forms.Button btn2;
      private System.Windows.Forms.Button btn3;
      private System.Windows.Forms.Button btn4;
      private System.Windows.Forms.Button btn5;
      private System.Windows.Forms.Button btn6;
      private System.Windows.Forms.Button btn7;
      private System.Windows.Forms.Button btn8;
      private System.Windows.Forms.Button btn9;
      private System.Windows.Forms.Button btn0;
      private System.Windows.Forms.Button btnHyphen;
      private System.Windows.Forms.Button btnPlus;
      private System.Windows.Forms.Button btnBackspace;

      // Buttons representing the third row of keys
      private System.Windows.Forms.Button btnTab;
      private System.Windows.Forms.Button btnQ;
      private System.Windows.Forms.Button btnW;
      private System.Windows.Forms.Button btnE;
      private System.Windows.Forms.Button btnR;
      private System.Windows.Forms.Button btnT;
      private System.Windows.Forms.Button btnY;
      private System.Windows.Forms.Button btnU;
      private System.Windows.Forms.Button btnI;
      private System.Windows.Forms.Button btnO;
      private System.Windows.Forms.Button btnP;
      private System.Windows.Forms.Button btnLeftBrace;
      private System.Windows.Forms.Button btnRightBrace;
      private System.Windows.Forms.Button btnSlash;

      // Buttons representing the fourth row of keys
      private System.Windows.Forms.Button btnCaps;
      private System.Windows.Forms.Button btnA;
      private System.Windows.Forms.Button btnS;
      private System.Windows.Forms.Button btnD;
      private System.Windows.Forms.Button btnF;
      private System.Windows.Forms.Button btnG;
      private System.Windows.Forms.Button btnH;
      private System.Windows.Forms.Button btnJ;
      private System.Windows.Forms.Button btnK;
      private System.Windows.Forms.Button btnL;
      private System.Windows.Forms.Button btnColon;
      private System.Windows.Forms.Button btnQuote;
      private System.Windows.Forms.Button btnEnter;

      // Buttons representing the fifth row of keys
      private System.Windows.Forms.Button btnZ;
      private System.Windows.Forms.Button btnX;
      private System.Windows.Forms.Button btnC;
      private System.Windows.Forms.Button btnV;
      private System.Windows.Forms.Button btnB;
      private System.Windows.Forms.Button btnN;
      private System.Windows.Forms.Button btnM;
      private System.Windows.Forms.Button btnComma;
      private System.Windows.Forms.Button btnPeriod;
      private System.Windows.Forms.Button btnQuestion;

      // Buttons representing the sixth row of keys
      private System.Windows.Forms.Button btnCtrlLeft;
      private System.Windows.Forms.Button btnFn;
      private System.Windows.Forms.Button btnAltLeft;
      private System.Windows.Forms.Button btnSpace;

      // Buttons representing the directional arrows
      private System.Windows.Forms.Button btnUp;
      private System.Windows.Forms.Button btnDown;
      private System.Windows.Forms.Button btnLeft;
      private System.Windows.Forms.Button btnRight;
      private System.Windows.Forms.Button btnShiftLeft;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // reference to last Button pressed
      private Button m_btnLastButton;

      public FrmTypingApplication()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblPrompt = new System.Windows.Forms.Label();
         this.txtOutput = new System.Windows.Forms.RichTextBox();
         this.btnF1 = new System.Windows.Forms.Button();
         this.btnF2 = new System.Windows.Forms.Button();
         this.btnF3 = new System.Windows.Forms.Button();
         this.btnF4 = new System.Windows.Forms.Button();
         this.btnF5 = new System.Windows.Forms.Button();
         this.btnF6 = new System.Windows.Forms.Button();
         this.btnF7 = new System.Windows.Forms.Button();
         this.btnF8 = new System.Windows.Forms.Button();
         this.btnF9 = new System.Windows.Forms.Button();
         this.btnF10 = new System.Windows.Forms.Button();
         this.btnF11 = new System.Windows.Forms.Button();
         this.btnF12 = new System.Windows.Forms.Button();
         this.btn1 = new System.Windows.Forms.Button();
         this.btn2 = new System.Windows.Forms.Button();
         this.btn3 = new System.Windows.Forms.Button();
         this.btn4 = new System.Windows.Forms.Button();
         this.btn5 = new System.Windows.Forms.Button();
         this.btn6 = new System.Windows.Forms.Button();
         this.btn7 = new System.Windows.Forms.Button();
         this.btn8 = new System.Windows.Forms.Button();
         this.btn9 = new System.Windows.Forms.Button();
         this.btn0 = new System.Windows.Forms.Button();
         this.btnTilde = new System.Windows.Forms.Button();
         this.btnHyphen = new System.Windows.Forms.Button();
         this.btnPlus = new System.Windows.Forms.Button();
         this.btnBackspace = new System.Windows.Forms.Button();
         this.btnTab = new System.Windows.Forms.Button();
         this.btnSlash = new System.Windows.Forms.Button();
         this.btnCaps = new System.Windows.Forms.Button();
         this.btnEnter = new System.Windows.Forms.Button();
         this.btnShiftLeft = new System.Windows.Forms.Button();
         this.btnCtrlLeft = new System.Windows.Forms.Button();
         this.btnFn = new System.Windows.Forms.Button();
         this.btnAltLeft = new System.Windows.Forms.Button();
         this.btnSpace = new System.Windows.Forms.Button();
         this.btnQ = new System.Windows.Forms.Button();
         this.btnW = new System.Windows.Forms.Button();
         this.btnE = new System.Windows.Forms.Button();
         this.btnR = new System.Windows.Forms.Button();
         this.btnT = new System.Windows.Forms.Button();
         this.btnY = new System.Windows.Forms.Button();
         this.btnU = new System.Windows.Forms.Button();
         this.btnI = new System.Windows.Forms.Button();
         this.btnO = new System.Windows.Forms.Button();
         this.btnP = new System.Windows.Forms.Button();
         this.btnLeftBrace = new System.Windows.Forms.Button();
         this.btnRightBrace = new System.Windows.Forms.Button();
         this.btnA = new System.Windows.Forms.Button();
         this.btnS = new System.Windows.Forms.Button();
         this.btnD = new System.Windows.Forms.Button();
         this.btnF = new System.Windows.Forms.Button();
         this.btnG = new System.Windows.Forms.Button();
         this.btnH = new System.Windows.Forms.Button();
         this.btnJ = new System.Windows.Forms.Button();
         this.btnK = new System.Windows.Forms.Button();
         this.btnL = new System.Windows.Forms.Button();
         this.btnColon = new System.Windows.Forms.Button();
         this.btnQuote = new System.Windows.Forms.Button();
         this.btnZ = new System.Windows.Forms.Button();
         this.btnX = new System.Windows.Forms.Button();
         this.btnC = new System.Windows.Forms.Button();
         this.btnV = new System.Windows.Forms.Button();
         this.btnB = new System.Windows.Forms.Button();
         this.btnN = new System.Windows.Forms.Button();
         this.btnM = new System.Windows.Forms.Button();
         this.btnComma = new System.Windows.Forms.Button();
         this.btnPeriod = new System.Windows.Forms.Button();
         this.btnQuestion = new System.Windows.Forms.Button();
         this.btnUp = new System.Windows.Forms.Button();
         this.btnDown = new System.Windows.Forms.Button();
         this.btnLeft = new System.Windows.Forms.Button();
         this.btnRight = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblPrompt
         // 
         this.lblPrompt.Location = new System.Drawing.Point(32, 8);
         this.lblPrompt.Name = "lblPrompt";
         this.lblPrompt.Size = new System.Drawing.Size(408, 40);
         this.lblPrompt.TabIndex = 0;
         this.lblPrompt.Text = "Type some text using your keyboard. We will display your text and highlight the k" +
            "eys as you go. Note: Clicking the Buttons with your mouse will not perform any a" +
            "ction.";
         // 
         // txtOutput
         // 
         this.txtOutput.AcceptsTab = true;
         this.txtOutput.Font = new System.Drawing.Font("Tahoma", 10.2F);
         this.txtOutput.Location = new System.Drawing.Point(32, 64);
         this.txtOutput.Name = "txtOutput";
         this.txtOutput.ReadOnly = true;
         this.txtOutput.Size = new System.Drawing.Size(408, 136);
         this.txtOutput.TabIndex = 1;
         this.txtOutput.Text = "";
         this.txtOutput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOutput_KeyDown);
         this.txtOutput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOutput_KeyPress);
         this.txtOutput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtOutput_KeyUp);
         // 
         // btnF1
         // 
         this.btnF1.Location = new System.Drawing.Point(48, 216);
         this.btnF1.Name = "btnF1";
         this.btnF1.Size = new System.Drawing.Size(32, 23);
         this.btnF1.TabIndex = 2;
         this.btnF1.Text = "F1";
         // 
         // btnF2
         // 
         this.btnF2.Location = new System.Drawing.Point(80, 216);
         this.btnF2.Name = "btnF2";
         this.btnF2.Size = new System.Drawing.Size(32, 23);
         this.btnF2.TabIndex = 3;
         this.btnF2.Text = "F2";
         // 
         // btnF3
         // 
         this.btnF3.Location = new System.Drawing.Point(112, 216);
         this.btnF3.Name = "btnF3";
         this.btnF3.Size = new System.Drawing.Size(32, 23);
         this.btnF3.TabIndex = 4;
         this.btnF3.Text = "F3";
         // 
         // btnF4
         // 
         this.btnF4.Location = new System.Drawing.Point(144, 216);
         this.btnF4.Name = "btnF4";
         this.btnF4.Size = new System.Drawing.Size(32, 23);
         this.btnF4.TabIndex = 5;
         this.btnF4.Text = "F4";
         // 
         // btnF5
         // 
         this.btnF5.Location = new System.Drawing.Point(176, 216);
         this.btnF5.Name = "btnF5";
         this.btnF5.Size = new System.Drawing.Size(32, 23);
         this.btnF5.TabIndex = 6;
         this.btnF5.Text = "F5";
         // 
         // btnF6
         // 
         this.btnF6.Location = new System.Drawing.Point(208, 216);
         this.btnF6.Name = "btnF6";
         this.btnF6.Size = new System.Drawing.Size(32, 23);
         this.btnF6.TabIndex = 7;
         this.btnF6.Text = "F6";
         // 
         // btnF7
         // 
         this.btnF7.Location = new System.Drawing.Point(240, 216);
         this.btnF7.Name = "btnF7";
         this.btnF7.Size = new System.Drawing.Size(32, 23);
         this.btnF7.TabIndex = 8;
         this.btnF7.Text = "F7";
         // 
         // btnF8
         // 
         this.btnF8.Location = new System.Drawing.Point(272, 216);
         this.btnF8.Name = "btnF8";
         this.btnF8.Size = new System.Drawing.Size(32, 23);
         this.btnF8.TabIndex = 9;
         this.btnF8.Text = "F8";
         // 
         // btnF9
         // 
         this.btnF9.Location = new System.Drawing.Point(304, 216);
         this.btnF9.Name = "btnF9";
         this.btnF9.Size = new System.Drawing.Size(32, 23);
         this.btnF9.TabIndex = 10;
         this.btnF9.Text = "F9";
         // 
         // btnF10
         // 
         this.btnF10.Location = new System.Drawing.Point(336, 216);
         this.btnF10.Name = "btnF10";
         this.btnF10.Size = new System.Drawing.Size(32, 23);
         this.btnF10.TabIndex = 11;
         this.btnF10.Text = "F10";
         // 
         // btnF11
         // 
         this.btnF11.Location = new System.Drawing.Point(368, 216);
         this.btnF11.Name = "btnF11";
         this.btnF11.Size = new System.Drawing.Size(32, 23);
         this.btnF11.TabIndex = 12;
         this.btnF11.Text = "F11";
         // 
         // btnF12
         // 
         this.btnF12.Location = new System.Drawing.Point(400, 216);
         this.btnF12.Name = "btnF12";
         this.btnF12.Size = new System.Drawing.Size(32, 23);
         this.btnF12.TabIndex = 13;
         this.btnF12.Text = "F12";
         // 
         // btn1
         // 
         this.btn1.Location = new System.Drawing.Point(80, 240);
         this.btn1.Name = "btn1";
         this.btn1.Size = new System.Drawing.Size(24, 23);
         this.btn1.TabIndex = 15;
         this.btn1.Text = "1";
         // 
         // btn2
         // 
         this.btn2.Location = new System.Drawing.Point(104, 240);
         this.btn2.Name = "btn2";
         this.btn2.Size = new System.Drawing.Size(24, 23);
         this.btn2.TabIndex = 16;
         this.btn2.Text = "2";
         // 
         // btn3
         // 
         this.btn3.Location = new System.Drawing.Point(128, 240);
         this.btn3.Name = "btn3";
         this.btn3.Size = new System.Drawing.Size(24, 23);
         this.btn3.TabIndex = 17;
         this.btn3.Text = "3";
         // 
         // btn4
         // 
         this.btn4.Location = new System.Drawing.Point(152, 240);
         this.btn4.Name = "btn4";
         this.btn4.Size = new System.Drawing.Size(24, 23);
         this.btn4.TabIndex = 18;
         this.btn4.Text = "4";
         // 
         // btn5
         // 
         this.btn5.Location = new System.Drawing.Point(176, 240);
         this.btn5.Name = "btn5";
         this.btn5.Size = new System.Drawing.Size(24, 23);
         this.btn5.TabIndex = 19;
         this.btn5.Text = "5";
         // 
         // btn6
         // 
         this.btn6.Location = new System.Drawing.Point(200, 240);
         this.btn6.Name = "btn6";
         this.btn6.Size = new System.Drawing.Size(24, 23);
         this.btn6.TabIndex = 20;
         this.btn6.Text = "6";
         // 
         // btn7
         // 
         this.btn7.Location = new System.Drawing.Point(224, 240);
         this.btn7.Name = "btn7";
         this.btn7.Size = new System.Drawing.Size(24, 23);
         this.btn7.TabIndex = 21;
         this.btn7.Text = "7";
         // 
         // btn8
         // 
         this.btn8.Location = new System.Drawing.Point(248, 240);
         this.btn8.Name = "btn8";
         this.btn8.Size = new System.Drawing.Size(24, 23);
         this.btn8.TabIndex = 22;
         this.btn8.Text = "8";
         // 
         // btn9
         // 
         this.btn9.Location = new System.Drawing.Point(272, 240);
         this.btn9.Name = "btn9";
         this.btn9.Size = new System.Drawing.Size(24, 23);
         this.btn9.TabIndex = 23;
         this.btn9.Text = "9";
         // 
         // btn0
         // 
         this.btn0.Location = new System.Drawing.Point(296, 240);
         this.btn0.Name = "btn0";
         this.btn0.Size = new System.Drawing.Size(24, 23);
         this.btn0.TabIndex = 24;
         this.btn0.Text = "0";
         // 
         // btnTilde
         // 
         this.btnTilde.Location = new System.Drawing.Point(32, 240);
         this.btnTilde.Name = "btnTilde";
         this.btnTilde.Size = new System.Drawing.Size(48, 23);
         this.btnTilde.TabIndex = 14;
         this.btnTilde.Text = "~";
         // 
         // btnHyphen
         // 
         this.btnHyphen.Location = new System.Drawing.Point(320, 240);
         this.btnHyphen.Name = "btnHyphen";
         this.btnHyphen.Size = new System.Drawing.Size(24, 23);
         this.btnHyphen.TabIndex = 25;
         this.btnHyphen.Text = "-";
         // 
         // btnPlus
         // 
         this.btnPlus.Location = new System.Drawing.Point(344, 240);
         this.btnPlus.Name = "btnPlus";
         this.btnPlus.Size = new System.Drawing.Size(24, 23);
         this.btnPlus.TabIndex = 26;
         this.btnPlus.Text = "+";
         // 
         // btnBackspace
         // 
         this.btnBackspace.Location = new System.Drawing.Point(368, 240);
         this.btnBackspace.Name = "btnBackspace";
         this.btnBackspace.Size = new System.Drawing.Size(72, 23);
         this.btnBackspace.TabIndex = 27;
         this.btnBackspace.Text = "Backspace";
         // 
         // btnTab
         // 
         this.btnTab.Location = new System.Drawing.Point(32, 264);
         this.btnTab.Name = "btnTab";
         this.btnTab.Size = new System.Drawing.Size(64, 23);
         this.btnTab.TabIndex = 28;
         this.btnTab.Text = "Tab";
         // 
         // btnSlash
         // 
         this.btnSlash.Location = new System.Drawing.Point(384, 264);
         this.btnSlash.Name = "btnSlash";
         this.btnSlash.Size = new System.Drawing.Size(56, 23);
         this.btnSlash.TabIndex = 41;
         this.btnSlash.Text = "\\";
         // 
         // btnCaps
         // 
         this.btnCaps.Location = new System.Drawing.Point(32, 288);
         this.btnCaps.Name = "btnCaps";
         this.btnCaps.Size = new System.Drawing.Size(72, 23);
         this.btnCaps.TabIndex = 42;
         this.btnCaps.Text = "Caps Lock";
         // 
         // btnEnter
         // 
         this.btnEnter.Location = new System.Drawing.Point(368, 288);
         this.btnEnter.Name = "btnEnter";
         this.btnEnter.Size = new System.Drawing.Size(72, 23);
         this.btnEnter.TabIndex = 54;
         this.btnEnter.Text = "Enter";
         // 
         // btnShiftLeft
         // 
         this.btnShiftLeft.Location = new System.Drawing.Point(32, 312);
         this.btnShiftLeft.Name = "btnShiftLeft";
         this.btnShiftLeft.Size = new System.Drawing.Size(88, 23);
         this.btnShiftLeft.TabIndex = 55;
         this.btnShiftLeft.Text = "Shift";
         // 
         // btnCtrlLeft
         // 
         this.btnCtrlLeft.Location = new System.Drawing.Point(32, 336);
         this.btnCtrlLeft.Name = "btnCtrlLeft";
         this.btnCtrlLeft.Size = new System.Drawing.Size(56, 23);
         this.btnCtrlLeft.TabIndex = 66;
         this.btnCtrlLeft.Text = "Ctrl";
         // 
         // btnFn
         // 
         this.btnFn.Location = new System.Drawing.Point(88, 336);
         this.btnFn.Name = "btnFn";
         this.btnFn.Size = new System.Drawing.Size(32, 23);
         this.btnFn.TabIndex = 67;
         this.btnFn.Text = "Fn";
         // 
         // btnAltLeft
         // 
         this.btnAltLeft.Location = new System.Drawing.Point(120, 336);
         this.btnAltLeft.Name = "btnAltLeft";
         this.btnAltLeft.Size = new System.Drawing.Size(32, 23);
         this.btnAltLeft.TabIndex = 68;
         this.btnAltLeft.Text = "Alt";
         // 
         // btnSpace
         // 
         this.btnSpace.Location = new System.Drawing.Point(152, 336);
         this.btnSpace.Name = "btnSpace";
         this.btnSpace.Size = new System.Drawing.Size(144, 23);
         this.btnSpace.TabIndex = 69;
         // 
         // btnQ
         // 
         this.btnQ.Location = new System.Drawing.Point(96, 264);
         this.btnQ.Name = "btnQ";
         this.btnQ.Size = new System.Drawing.Size(24, 23);
         this.btnQ.TabIndex = 29;
         this.btnQ.Text = "Q";
         // 
         // btnW
         // 
         this.btnW.Location = new System.Drawing.Point(120, 264);
         this.btnW.Name = "btnW";
         this.btnW.Size = new System.Drawing.Size(24, 23);
         this.btnW.TabIndex = 30;
         this.btnW.Text = "W";
         // 
         // btnE
         // 
         this.btnE.Location = new System.Drawing.Point(144, 264);
         this.btnE.Name = "btnE";
         this.btnE.Size = new System.Drawing.Size(24, 23);
         this.btnE.TabIndex = 31;
         this.btnE.Text = "E";
         // 
         // btnR
         // 
         this.btnR.Location = new System.Drawing.Point(168, 264);
         this.btnR.Name = "btnR";
         this.btnR.Size = new System.Drawing.Size(24, 23);
         this.btnR.TabIndex = 32;
         this.btnR.Text = "R";
         // 
         // btnT
         // 
         this.btnT.Location = new System.Drawing.Point(192, 264);
         this.btnT.Name = "btnT";
         this.btnT.Size = new System.Drawing.Size(24, 23);
         this.btnT.TabIndex = 33;
         this.btnT.Text = "T";
         // 
         // btnY
         // 
         this.btnY.Location = new System.Drawing.Point(216, 264);
         this.btnY.Name = "btnY";
         this.btnY.Size = new System.Drawing.Size(24, 23);
         this.btnY.TabIndex = 34;
         this.btnY.Text = "Y";
         // 
         // btnU
         // 
         this.btnU.Location = new System.Drawing.Point(240, 264);
         this.btnU.Name = "btnU";
         this.btnU.Size = new System.Drawing.Size(24, 23);
         this.btnU.TabIndex = 35;
         this.btnU.Text = "U";
         // 
         // btnI
         // 
         this.btnI.Location = new System.Drawing.Point(264, 264);
         this.btnI.Name = "btnI";
         this.btnI.Size = new System.Drawing.Size(24, 23);
         this.btnI.TabIndex = 36;
         this.btnI.Text = "I";
         // 
         // btnO
         // 
         this.btnO.Location = new System.Drawing.Point(288, 264);
         this.btnO.Name = "btnO";
         this.btnO.Size = new System.Drawing.Size(24, 23);
         this.btnO.TabIndex = 37;
         this.btnO.Text = "O";
         // 
         // btnP
         // 
         this.btnP.Location = new System.Drawing.Point(312, 264);
         this.btnP.Name = "btnP";
         this.btnP.Size = new System.Drawing.Size(24, 23);
         this.btnP.TabIndex = 38;
         this.btnP.Text = "P";
         // 
         // btnLeftBrace
         // 
         this.btnLeftBrace.Location = new System.Drawing.Point(336, 264);
         this.btnLeftBrace.Name = "btnLeftBrace";
         this.btnLeftBrace.Size = new System.Drawing.Size(24, 23);
         this.btnLeftBrace.TabIndex = 39;
         this.btnLeftBrace.Text = "[";
         // 
         // btnRightBrace
         // 
         this.btnRightBrace.Location = new System.Drawing.Point(360, 264);
         this.btnRightBrace.Name = "btnRightBrace";
         this.btnRightBrace.Size = new System.Drawing.Size(24, 23);
         this.btnRightBrace.TabIndex = 40;
         this.btnRightBrace.Text = "]";
         // 
         // btnA
         // 
         this.btnA.Location = new System.Drawing.Point(104, 288);
         this.btnA.Name = "btnA";
         this.btnA.Size = new System.Drawing.Size(24, 23);
         this.btnA.TabIndex = 43;
         this.btnA.Text = "A";
         // 
         // btnS
         // 
         this.btnS.Location = new System.Drawing.Point(128, 288);
         this.btnS.Name = "btnS";
         this.btnS.Size = new System.Drawing.Size(24, 23);
         this.btnS.TabIndex = 44;
         this.btnS.Text = "S";
         // 
         // btnD
         // 
         this.btnD.Location = new System.Drawing.Point(152, 288);
         this.btnD.Name = "btnD";
         this.btnD.Size = new System.Drawing.Size(24, 23);
         this.btnD.TabIndex = 45;
         this.btnD.Text = "D";
         // 
         // btnF
         // 
         this.btnF.Location = new System.Drawing.Point(176, 288);
         this.btnF.Name = "btnF";
         this.btnF.Size = new System.Drawing.Size(24, 23);
         this.btnF.TabIndex = 46;
         this.btnF.Text = "F";
         // 
         // btnG
         // 
         this.btnG.Location = new System.Drawing.Point(200, 288);
         this.btnG.Name = "btnG";
         this.btnG.Size = new System.Drawing.Size(24, 23);
         this.btnG.TabIndex = 47;
         this.btnG.Text = "G";
         // 
         // btnH
         // 
         this.btnH.Location = new System.Drawing.Point(224, 288);
         this.btnH.Name = "btnH";
         this.btnH.Size = new System.Drawing.Size(24, 23);
         this.btnH.TabIndex = 48;
         this.btnH.Text = "H";
         // 
         // btnJ
         // 
         this.btnJ.Location = new System.Drawing.Point(248, 288);
         this.btnJ.Name = "btnJ";
         this.btnJ.Size = new System.Drawing.Size(24, 23);
         this.btnJ.TabIndex = 49;
         this.btnJ.Text = "J";
         // 
         // btnK
         // 
         this.btnK.Location = new System.Drawing.Point(272, 288);
         this.btnK.Name = "btnK";
         this.btnK.Size = new System.Drawing.Size(24, 23);
         this.btnK.TabIndex = 50;
         this.btnK.Text = "K";
         // 
         // btnL
         // 
         this.btnL.Location = new System.Drawing.Point(296, 288);
         this.btnL.Name = "btnL";
         this.btnL.Size = new System.Drawing.Size(24, 23);
         this.btnL.TabIndex = 51;
         this.btnL.Text = "L";
         // 
         // btnColon
         // 
         this.btnColon.Location = new System.Drawing.Point(320, 288);
         this.btnColon.Name = "btnColon";
         this.btnColon.Size = new System.Drawing.Size(24, 23);
         this.btnColon.TabIndex = 52;
         this.btnColon.Text = ":";
         // 
         // btnQuote
         // 
         this.btnQuote.Location = new System.Drawing.Point(344, 288);
         this.btnQuote.Name = "btnQuote";
         this.btnQuote.Size = new System.Drawing.Size(24, 23);
         this.btnQuote.TabIndex = 53;
         this.btnQuote.Text = "\"";
         // 
         // btnZ
         // 
         this.btnZ.Location = new System.Drawing.Point(120, 312);
         this.btnZ.Name = "btnZ";
         this.btnZ.Size = new System.Drawing.Size(24, 23);
         this.btnZ.TabIndex = 56;
         this.btnZ.Text = "Z";
         // 
         // btnX
         // 
         this.btnX.Location = new System.Drawing.Point(144, 312);
         this.btnX.Name = "btnX";
         this.btnX.Size = new System.Drawing.Size(24, 23);
         this.btnX.TabIndex = 57;
         this.btnX.Text = "X";
         // 
         // btnC
         // 
         this.btnC.Location = new System.Drawing.Point(168, 312);
         this.btnC.Name = "btnC";
         this.btnC.Size = new System.Drawing.Size(24, 23);
         this.btnC.TabIndex = 58;
         this.btnC.Text = "C";
         // 
         // btnV
         // 
         this.btnV.Location = new System.Drawing.Point(192, 312);
         this.btnV.Name = "btnV";
         this.btnV.Size = new System.Drawing.Size(24, 23);
         this.btnV.TabIndex = 59;
         this.btnV.Text = "V";
         // 
         // btnB
         // 
         this.btnB.Location = new System.Drawing.Point(216, 312);
         this.btnB.Name = "btnB";
         this.btnB.Size = new System.Drawing.Size(24, 23);
         this.btnB.TabIndex = 60;
         this.btnB.Text = "B";
         // 
         // btnN
         // 
         this.btnN.Location = new System.Drawing.Point(240, 312);
         this.btnN.Name = "btnN";
         this.btnN.Size = new System.Drawing.Size(24, 23);
         this.btnN.TabIndex = 61;
         this.btnN.Text = "N";
         // 
         // btnM
         // 
         this.btnM.Location = new System.Drawing.Point(264, 312);
         this.btnM.Name = "btnM";
         this.btnM.Size = new System.Drawing.Size(24, 23);
         this.btnM.TabIndex = 62;
         this.btnM.Text = "M";
         // 
         // btnComma
         // 
         this.btnComma.Location = new System.Drawing.Point(288, 312);
         this.btnComma.Name = "btnComma";
         this.btnComma.Size = new System.Drawing.Size(24, 23);
         this.btnComma.TabIndex = 63;
         this.btnComma.Text = ",";
         // 
         // btnPeriod
         // 
         this.btnPeriod.Location = new System.Drawing.Point(312, 312);
         this.btnPeriod.Name = "btnPeriod";
         this.btnPeriod.Size = new System.Drawing.Size(24, 23);
         this.btnPeriod.TabIndex = 64;
         this.btnPeriod.Text = ".";
         // 
         // btnQuestion
         // 
         this.btnQuestion.Location = new System.Drawing.Point(336, 312);
         this.btnQuestion.Name = "btnQuestion";
         this.btnQuestion.Size = new System.Drawing.Size(24, 23);
         this.btnQuestion.TabIndex = 65;
         this.btnQuestion.Text = "?";
         // 
         // btnUp
         // 
         this.btnUp.Location = new System.Drawing.Point(384, 312);
         this.btnUp.Name = "btnUp";
         this.btnUp.Size = new System.Drawing.Size(24, 23);
         this.btnUp.TabIndex = 70;
         this.btnUp.Text = "^";
         // 
         // btnDown
         // 
         this.btnDown.Location = new System.Drawing.Point(384, 336);
         this.btnDown.Name = "btnDown";
         this.btnDown.Size = new System.Drawing.Size(24, 23);
         this.btnDown.TabIndex = 71;
         this.btnDown.Text = "v";
         // 
         // btnLeft
         // 
         this.btnLeft.Location = new System.Drawing.Point(360, 336);
         this.btnLeft.Name = "btnLeft";
         this.btnLeft.Size = new System.Drawing.Size(24, 23);
         this.btnLeft.TabIndex = 72;
         this.btnLeft.Text = "<";
         // 
         // btnRight
         // 
         this.btnRight.Location = new System.Drawing.Point(408, 336);
         this.btnRight.Name = "btnRight";
         this.btnRight.Size = new System.Drawing.Size(24, 23);
         this.btnRight.TabIndex = 73;
         this.btnRight.Text = ">";
         // 
         // FrmTypingApplication
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(472, 369);
         this.Controls.Add(this.btnRight);
         this.Controls.Add(this.btnLeft);
         this.Controls.Add(this.btnDown);
         this.Controls.Add(this.btnUp);
         this.Controls.Add(this.btnQuestion);
         this.Controls.Add(this.btnPeriod);
         this.Controls.Add(this.btnComma);
         this.Controls.Add(this.btnM);
         this.Controls.Add(this.btnN);
         this.Controls.Add(this.btnB);
         this.Controls.Add(this.btnV);
         this.Controls.Add(this.btnC);
         this.Controls.Add(this.btnX);
         this.Controls.Add(this.btnZ);
         this.Controls.Add(this.btnQuote);
         this.Controls.Add(this.btnColon);
         this.Controls.Add(this.btnL);
         this.Controls.Add(this.btnK);
         this.Controls.Add(this.btnJ);
         this.Controls.Add(this.btnH);
         this.Controls.Add(this.btnG);
         this.Controls.Add(this.btnF);
         this.Controls.Add(this.btnD);
         this.Controls.Add(this.btnS);
         this.Controls.Add(this.btnA);
         this.Controls.Add(this.btnRightBrace);
         this.Controls.Add(this.btnLeftBrace);
         this.Controls.Add(this.btnP);
         this.Controls.Add(this.btnO);
         this.Controls.Add(this.btnI);
         this.Controls.Add(this.btnU);
         this.Controls.Add(this.btnY);
         this.Controls.Add(this.btnT);
         this.Controls.Add(this.btnR);
         this.Controls.Add(this.btnE);
         this.Controls.Add(this.btnW);
         this.Controls.Add(this.btnQ);
         this.Controls.Add(this.btnSpace);
         this.Controls.Add(this.btnAltLeft);
         this.Controls.Add(this.btnFn);
         this.Controls.Add(this.btnCtrlLeft);
         this.Controls.Add(this.btnShiftLeft);
         this.Controls.Add(this.btnEnter);
         this.Controls.Add(this.btnCaps);
         this.Controls.Add(this.btnSlash);
         this.Controls.Add(this.btnTab);
         this.Controls.Add(this.btnBackspace);
         this.Controls.Add(this.btnPlus);
         this.Controls.Add(this.btnHyphen);
         this.Controls.Add(this.btnTilde);
         this.Controls.Add(this.btn1);
         this.Controls.Add(this.btn2);
         this.Controls.Add(this.btn3);
         this.Controls.Add(this.btn4);
         this.Controls.Add(this.btn5);
         this.Controls.Add(this.btn6);
         this.Controls.Add(this.btn7);
         this.Controls.Add(this.btn8);
         this.Controls.Add(this.btn9);
         this.Controls.Add(this.btn0);
         this.Controls.Add(this.btnF1);
         this.Controls.Add(this.btnF2);
         this.Controls.Add(this.btnF3);
         this.Controls.Add(this.btnF4);
         this.Controls.Add(this.btnF5);
         this.Controls.Add(this.btnF6);
         this.Controls.Add(this.btnF7);
         this.Controls.Add(this.btnF8);
         this.Controls.Add(this.btnF9);
         this.Controls.Add(this.btnF10);
         this.Controls.Add(this.btnF11);
         this.Controls.Add(this.btnF12);
         this.Controls.Add(this.txtOutput);
         this.Controls.Add(this.lblPrompt);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmTypingApplication";
         this.Text = "Typing Application";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmTypingApplication() );
      }

      // handles Form's KeyDown Event
      private void txtOutput_KeyDown(
         object sender, System.Windows.Forms.KeyEventArgs e )
      {
         switch ( e.KeyData )
         {
            // following case tests if backspace was pressed









            // following cases test if whitespace key was pressed





            case Keys.Tab: // Tab key
               ChangeColor( btnTab );
               txtOutput.Text += "\t";
               break;

            case Keys.Space: // space bar
               ChangeColor( btnSpace );
               txtOutput.Text += " ";
               break;

            // following cases test if number key was pressed
            case Keys.D0: // 0 key
               ChangeColor( btn0 );
               txtOutput.Text += "0";
               break;

            case Keys.D1:
               ChangeColor( btn1 );
               txtOutput.Text += "1";
               break;

            case Keys.D2:
               ChangeColor( btn2 );
               txtOutput.Text += "2";
               break;

            case Keys.D3:
               ChangeColor( btn3 );
               txtOutput.Text += "3";
               break;

            case Keys.D4:
               ChangeColor( btn4 );
               txtOutput.Text += "4";
               break;

            case Keys.D5:
               ChangeColor( btn5 );
               txtOutput.Text += "5";
               break;

            case Keys.D6:
               ChangeColor( btn6 );
               txtOutput.Text += "6";
               break;

            case Keys.D7:
               ChangeColor( btn7 );
               txtOutput.Text += "7";
               break;

            case Keys.D8:
               ChangeColor( btn8 );
               txtOutput.Text += "8";
               break;

            case Keys.D9:
               ChangeColor( btn9 );
               txtOutput.Text += "9";
               break;

            // following cases test if one of the F keys was pressed
            case Keys.F1: // F1 key
               ChangeColor( btnF1 );
               break;

            case Keys.F2: // F2 key
               ChangeColor( btnF2 );
               break;

            case Keys.F3: // F3 key
               ChangeColor( btnF3 );
               break;

            case Keys.F4: // F4 key
               ChangeColor( btnF4 );
               break;

            case Keys.F5: // F5 key
               ChangeColor( btnF5 );
               break;

            case Keys.F6: // F6 key
               ChangeColor( btnF6 );
               break;

            case Keys.F7: // F7 key
               ChangeColor( btnF7 );
               break;

            case Keys.F8: // F8 key
               ChangeColor( btnF8 );
               break;

            case Keys.F9: // F9 key
               ChangeColor( btnF9 );
               break;

            case Keys.F10: // F10 key
               ChangeColor( btnF10 );
               break;

            case Keys.F11: // F11 key
               ChangeColor( btnF11 );
               break;

            case Keys.F12: // F12 key
               ChangeColor( btnF12 );
               break;

            // following cases test if a special 
            // character key was pressed
            case Keys.OemOpenBrackets: // left square bracket
               ChangeColor( btnLeftBrace );
               txtOutput.Text += "[";
               break;

            case Keys.OemCloseBrackets: // right square bracket
               ChangeColor( btnRightBrace );
               txtOutput.Text += "]";
               break;

            case Keys.Oemplus: // plus sign
               ChangeColor( btnPlus );
               txtOutput.Text += "+";
               break;

            case Keys.OemMinus: // minus sign
               ChangeColor( btnHyphen );
               txtOutput.Text += "-";
               break;

            case Keys.Oemtilde: // tilde (~)
               ChangeColor( btnTilde );
               txtOutput.Text += "~";
               break;

            case Keys.OemPipe: // backslash
               ChangeColor( btnSlash );
               txtOutput.Text += "\\";
               break;

            case Keys.OemSemicolon: // colon
               ChangeColor( btnColon );
               txtOutput.Text += ":";
               break;

            case Keys.OemQuotes: // quotation marks
               ChangeColor( btnQuote );
               txtOutput.Text += "\"";
               break;

            case Keys.OemPeriod: // period
               ChangeColor( btnPeriod );
               txtOutput.Text += ".";
               break;

            case Keys.Oemcomma: // comma
               ChangeColor( btnComma );
               txtOutput.Text += ",";
               break;

            case Keys.OemQuestion: // question mark
               ChangeColor( btnQuestion );
               txtOutput.Text += "?";
               break;

            case Keys.CapsLock: // Caps Lock key
               ChangeColor( btnCaps );
               break;

            // following cases test if one of the 
            // arrow keys was pressed
            case Keys.Down: // down arrow
               ChangeColor( btnDown );
               break;

            case Keys.Up: // up arrow
               ChangeColor( btnUp );
               break;

            case Keys.Left: // left arrow
               ChangeColor( btnLeft );
               break;

            case Keys.Right: // right arrow
               ChangeColor( btnRight );
               break;

            // following cases test if a modifier key was pressed
            case ( ( Keys ) 65552 ): // Shift key
               ChangeColor( btnShiftLeft );
               break;

            case ( ( Keys ) 131089 ): // Control key
               ChangeColor( btnCtrlLeft );
               break;

            case ( ( Keys ) 262162 ): // Alt key
               ChangeColor( btnAltLeft );
               break;

         } // end switch e.KeyData
         
      } // end method txtOutput_KeyDown

      // handles Form's KeyPress event
      private void txtOutput_KeyPress(
         object sender, System.Windows.Forms.KeyPressEventArgs e )
      {
      
         // convert pressed key to uppercase


            // following cases test if key pressed was a letter










            case ( ( char ) Keys.C ): // c key
               ChangeColor( btnC );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.D ): // d key
               ChangeColor( btnD );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.E ): // e key
               ChangeColor( btnE );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.F ): // f key
               ChangeColor( btnF );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.G ): // g key
               ChangeColor( btnG );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.H ): // h key
               ChangeColor( btnH );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.I ): // i key
               ChangeColor( btnI );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.J ): // j key
               ChangeColor( btnJ );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.K ): // k key
               ChangeColor( btnK );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.L ): // l key
               ChangeColor( btnL );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.M ): // m key
               ChangeColor( btnM );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.N ): // n key
               ChangeColor( btnN );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.O ): // o key
               ChangeColor( btnO );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.P ): // p key
               ChangeColor( btnP );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.Q ): // q key
               ChangeColor( btnQ );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.R ): // r key
               ChangeColor( btnR );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.S ): // s key
               ChangeColor( btnS );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.T ): // t key
               ChangeColor( btnT );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.U ): // u key
               ChangeColor( btnU );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.V ): // v key
               ChangeColor( btnV );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.W ): // w key
               ChangeColor( btnW );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.X ): // x key
               ChangeColor( btnX );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.Y ): // y key
               ChangeColor( btnY );
               txtOutput.Text += e.KeyChar;
               break;

            case ( ( char ) Keys.Z ): // z key
               ChangeColor( btnZ );
               txtOutput.Text += e.KeyChar;
               break;

         } // end switch -- ends test for letters

      } // end method txtOutput_KeyPress

      // handles Form's KeyUp event
      private void txtOutput_KeyUp(
         object sender, System.Windows.Forms.KeyEventArgs e )
      {
      
      } // end method txtOutput_KeyUp

      // highlight Button passed as argument
      private void ChangeColor( Button btnButton )
      {
         ResetColor();
         btnButton.BackColor = Color.LightGoldenrodYellow;
         m_btnLastButton = btnButton;

      } // end method ChangeColor

      // changes m_btnLastButton's color if it refers to a Button
      private void ResetColor()
      {
         if ( m_btnLastButton != null )
         { 
            m_btnLastButton.BackColor = SystemColors.Control;
         }
 
      }

   } // end class FrmTypingApplication
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel + Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
