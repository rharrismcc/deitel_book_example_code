using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Anagram
{
   /// <summary>
   /// Summary description for FrmAnagram.
   /// </summary>
   public class FrmAnagram : System.Windows.Forms.Form
   {
      // Label to display the anagram
      private System.Windows.Forms.Label lblAnagram;

      // Label and TextBox to input a guess
      private System.Windows.Forms.Label lblGuess;
      private System.Windows.Forms.TextBox txtGuess;

      // Button to submit a guess
      private System.Windows.Forms.Button btnSubmit;

      // Label to display the result of a guess
      private System.Windows.Forms.Label lblResult;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // array of words to be scrambled
      private string[] m_strAnagram = {
         "controls", "events", "properties", "visual", "program",
         "application", "namespace", "debugger", "database", "files",
         "inheritance","assembly", "multimedia", "methods",
         "classes","arrays", "strings", "collections", 
         "integration", "structures" };

      private Random m_objRandom = new Random(); // random number
      private int m_intRandomNumber; // random index variable
      private string m_strScrambled; // randomly chosen word

      public FrmAnagram()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblAnagram = new System.Windows.Forms.Label();
         this.lblGuess = new System.Windows.Forms.Label();
         this.txtGuess = new System.Windows.Forms.TextBox();
         this.btnSubmit = new System.Windows.Forms.Button();
         this.lblResult = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // lblAnagram
         // 
         this.lblAnagram.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblAnagram.Location = new System.Drawing.Point(16, 16);
         this.lblAnagram.Name = "lblAnagram";
         this.lblAnagram.Size = new System.Drawing.Size(140, 21);
         this.lblAnagram.TabIndex = 1;
         this.lblAnagram.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblGuess
         // 
         this.lblGuess.Location = new System.Drawing.Point(16, 72);
         this.lblGuess.Name = "lblGuess";
         this.lblGuess.Size = new System.Drawing.Size(72, 21);
         this.lblGuess.TabIndex = 2;
         this.lblGuess.Text = "Your guess:";
         this.lblGuess.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtGuess
         // 
         this.txtGuess.Location = new System.Drawing.Point(16, 96);
         this.txtGuess.Name = "txtGuess";
         this.txtGuess.Size = new System.Drawing.Size(140, 21);
         this.txtGuess.TabIndex = 3;
         this.txtGuess.Text = "";
         // 
         // btnSubmit
         // 
         this.btnSubmit.Location = new System.Drawing.Point(48, 136);
         this.btnSubmit.Name = "btnSubmit";
         this.btnSubmit.Size = new System.Drawing.Size(74, 23);
         this.btnSubmit.TabIndex = 5;
         this.btnSubmit.Text = "Submit";
         // 
         // lblResult
         // 
         this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblResult.Location = new System.Drawing.Point(16, 184);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(140, 21);
         this.lblResult.TabIndex = 6;
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // FrmAnagram
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(172, 213);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.btnSubmit);
         this.Controls.Add(this.txtGuess);
         this.Controls.Add(this.lblGuess);
         this.Controls.Add(this.lblAnagram);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmAnagram";
         this.Text = "Anagram Game";
         this.Load += new System.EventHandler(this.FrmAnagram_Load);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmAnagram() );
      }

      // generate new scrambled word
      private void FrmAnagram_Load( 
         object sender, System.EventArgs e )
      {
         GenerateAnagram();

      } // end method FrmAnagram_Load

      // scramble words
      private void GenerateAnagram()
      {

      }

   } // end class FrmAnagram
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/