using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Encryption
{
   /// <summary>
   /// Summary description for FrmEncryption.
   /// </summary>
   public class FrmEncryption : System.Windows.Forms.Form
   {
      // Label and TextBox to input text to encrypt
      private System.Windows.Forms.Label lblInstruction;
      private System.Windows.Forms.TextBox txtPlainText;

      // RadioButtons to choose type of encryption
      private System.Windows.Forms.RadioButton radSubstitution;
      private System.Windows.Forms.RadioButton radTransposition;

      // Labels to output the encrypted text
      private System.Windows.Forms.Label lblResult;
      private System.Windows.Forms.Label lblCipherText;

      // Button to perform the encryption
      private System.Windows.Forms.Button btnEncrypt;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmEncryption()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblInstruction = new System.Windows.Forms.Label();
         this.txtPlainText = new System.Windows.Forms.TextBox();
         this.radSubstitution = new System.Windows.Forms.RadioButton();
         this.radTransposition = new System.Windows.Forms.RadioButton();
         this.lblResult = new System.Windows.Forms.Label();
         this.lblCipherText = new System.Windows.Forms.Label();
         this.btnEncrypt = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblInstruction
         // 
         this.lblInstruction.Location = new System.Drawing.Point(16, 16);
         this.lblInstruction.Name = "lblInstruction";
         this.lblInstruction.Size = new System.Drawing.Size(112, 21);
         this.lblInstruction.TabIndex = 1;
         this.lblInstruction.Text = "Enter text to encrypt:";
         this.lblInstruction.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtPlainText
         // 
         this.txtPlainText.Location = new System.Drawing.Point(136, 16);
         this.txtPlainText.Name = "txtPlainText";
         this.txtPlainText.Size = new System.Drawing.Size(216, 21);
         this.txtPlainText.TabIndex = 2;
         this.txtPlainText.Text = "";
         // 
         // radSubstitution
         // 
         this.radSubstitution.Checked = true;
         this.radSubstitution.Location = new System.Drawing.Point(24, 56);
         this.radSubstitution.Name = "radSubstitution";
         this.radSubstitution.Size = new System.Drawing.Size(120, 24);
         this.radSubstitution.TabIndex = 3;
         this.radSubstitution.TabStop = true;
         this.radSubstitution.Text = "Substitution Cipher";
         // 
         // radTransposition
         // 
         this.radTransposition.Location = new System.Drawing.Point(184, 56);
         this.radTransposition.Name = "radTransposition";
         this.radTransposition.Size = new System.Drawing.Size(128, 24);
         this.radTransposition.TabIndex = 4;
         this.radTransposition.Text = "Transposition Cipher";
         // 
         // lblResult
         // 
         this.lblResult.Location = new System.Drawing.Point(16, 96);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(100, 21);
         this.lblResult.TabIndex = 5;
         this.lblResult.Text = "Encrypted text:";
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblCipherText
         // 
         this.lblCipherText.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblCipherText.Location = new System.Drawing.Point(136, 96);
         this.lblCipherText.Name = "lblCipherText";
         this.lblCipherText.Size = new System.Drawing.Size(216, 21);
         this.lblCipherText.TabIndex = 8;
         // 
         // btnEncrypt
         // 
         this.btnEncrypt.Location = new System.Drawing.Point(280, 128);
         this.btnEncrypt.Name = "btnEncrypt";
         this.btnEncrypt.TabIndex = 9;
         this.btnEncrypt.Text = "Encrypt";
         // 
         // FrmEncryption
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(368, 165);
         this.Controls.Add(this.btnEncrypt);
         this.Controls.Add(this.lblCipherText);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.radTransposition);
         this.Controls.Add(this.radSubstitution);
         this.Controls.Add(this.txtPlainText);
         this.Controls.Add(this.lblInstruction);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmEncryption";
         this.Text = "Encryption";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmEncryption() );
      }

      // using the substitution cipher
      private void SubstitutionCipher()
      {
         // normal alphabet string
         string strNormalAlphabet = 
            "abcdefghijklmnopqrstuvwxyz .!?,";

         // substitution alphabet string
         string strCipherAlphabet =
            "cdefg.hijk!lmn opqr?stuv,wxyzab";

         int intIndex1; // index variable in for loop
         int intIndex2; // inner index variable
         string strPlain; // string entered by the user
         string strCipher; // encrypted string

         lblCipherText.Text = ""; // clear output TextBox

      } // end method SubstitutionCipher

      // using the transposition cipher
      private void TranspositionCipher()
      {

      }

   } // end class FrmEncryption
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/