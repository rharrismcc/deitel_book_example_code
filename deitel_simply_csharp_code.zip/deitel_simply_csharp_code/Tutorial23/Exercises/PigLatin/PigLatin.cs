using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PigLatin
{
   /// <summary>
   /// Summary description for FrmPigLatin.
   /// </summary>
   public class FrmPigLatin : System.Windows.Forms.Form
   {
      // Label and TextBox to input English phrase
      private System.Windows.Forms.Label lblInput;
      private System.Windows.Forms.TextBox txtInput;

      // Label and TextBox to output Pig Latin phrase
      private System.Windows.Forms.Label lblOutput;
      private System.Windows.Forms.TextBox txtOutput;

      // Button to translate from English to Pig Latin
      private System.Windows.Forms.Button btnTranslate;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmPigLatin()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblInput = new System.Windows.Forms.Label();
         this.txtInput = new System.Windows.Forms.TextBox();
         this.lblOutput = new System.Windows.Forms.Label();
         this.txtOutput = new System.Windows.Forms.TextBox();
         this.btnTranslate = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblInput
         // 
         this.lblInput.Location = new System.Drawing.Point(8, 16);
         this.lblInput.Name = "lblInput";
         this.lblInput.Size = new System.Drawing.Size(96, 23);
         this.lblInput.TabIndex = 1;
         this.lblInput.Text = "Enter a sentence:";
         this.lblInput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtInput
         // 
         this.txtInput.Location = new System.Drawing.Point(104, 16);
         this.txtInput.Name = "txtInput";
         this.txtInput.Size = new System.Drawing.Size(296, 21);
         this.txtInput.TabIndex = 2;
         this.txtInput.Text = "";
         // 
         // lblOutput
         // 
         this.lblOutput.Location = new System.Drawing.Point(8, 56);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(88, 23);
         this.lblOutput.TabIndex = 3;
         this.lblOutput.Text = "Pig Latin:";
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtOutput
         // 
         this.txtOutput.Location = new System.Drawing.Point(104, 56);
         this.txtOutput.Name = "txtOutput";
         this.txtOutput.Size = new System.Drawing.Size(296, 21);
         this.txtOutput.TabIndex = 4;
         this.txtOutput.Text = "";
         // 
         // btnTranslate
         // 
         this.btnTranslate.Location = new System.Drawing.Point(328, 96);
         this.btnTranslate.Name = "btnTranslate";
         this.btnTranslate.TabIndex = 5;
         this.btnTranslate.Text = "Translate";
         this.btnTranslate.Click += new System.EventHandler(this.btnTranslate_Click);
         // 
         // FrmPigLatin
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(416, 133);
         this.Controls.Add(this.btnTranslate);
         this.Controls.Add(this.txtOutput);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.txtInput);
         this.Controls.Add(this.lblInput);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmPigLatin";
         this.Text = "Pig Latin";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmPigLatin() );
      }

      // recieve sentence from user and send to TranslateToPigLatin
      private void btnTranslate_Click( 
         object sender, System.EventArgs e )
      {
         // retrieve English phrase from user
         string strPhrase = txtInput.Text;

         // display output
         txtOutput.Text = TranslateToPigLatin( strPhrase );

      } // end method btnTranslate_Click

      // translates the string input by the user 
      // from English to pig Latin
      private string TranslateToPigLatin( string strEnglishPhrase )
      {
         string[] strWords; // array to hold each word
         string strSuffix; // suffix for the end of each word
         int intIndex; // index to iterate through the array
         string strTemporary; // temporary string

      } // end method TranslateToPigLatin

   } // end class FrmPigLatin
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/