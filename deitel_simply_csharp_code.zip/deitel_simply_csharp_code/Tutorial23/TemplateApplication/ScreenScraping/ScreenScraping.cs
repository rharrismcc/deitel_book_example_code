using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ScreenScraping
{
   /// <summary>
   /// Summary description for FrmScreenScraping.
   /// </summary>
   public class FrmScreenScraping : System.Windows.Forms.Form
   {
      // Label and ComboBox for choosing item
      private System.Windows.Forms.Label lblItem;
      private System.Windows.Forms.ComboBox cboItems;

      // Labels for displaying price
      private System.Windows.Forms.Label lblPrice;
      private System.Windows.Forms.Label lblResult;

      // Button for searching for price
      private System.Windows.Forms.Button btnSearch;

      // Labels to display HTML
      private System.Windows.Forms.Label lblSource;
      private System.Windows.Forms.Label lblHTML;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // string of HTML to extract prices from
      string strHTML = "<HTML><BODY><TABLE>" +
                     "<TR><TD>Antique Rocking Chair</TD>" +
                     "<TD>&&euro;82.67</TD></TR>" +
                     "<TR><TD>Silver Teapot</TD>" +
                     "<TD>&&euro;64.55</TD></TR>" +
                     "<TR><TD>Gold Pocket Watch</TD>" +
                     "<TD>&&euro;128.83</TD></TR>" +
                     "</TABLE></BODY></HTML>";

      public FrmScreenScraping()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblItem = new System.Windows.Forms.Label();
         this.cboItems = new System.Windows.Forms.ComboBox();
         this.lblPrice = new System.Windows.Forms.Label();
         this.lblResult = new System.Windows.Forms.Label();
         this.btnSearch = new System.Windows.Forms.Button();
         this.lblSource = new System.Windows.Forms.Label();
         this.lblHTML = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // lblItem
         // 
         this.lblItem.Location = new System.Drawing.Point(8, 16);
         this.lblItem.Name = "lblItem";
         this.lblItem.Size = new System.Drawing.Size(40, 21);
         this.lblItem.TabIndex = 1;
         this.lblItem.Text = "Item:";
         this.lblItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // cboItems
         // 
         this.cboItems.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboItems.Items.AddRange(new object[] {
                                                      "Antique Rocking Chair",
                                                      "Silver Teapot",
                                                      "Gold Pocket Watch"});
         this.cboItems.Location = new System.Drawing.Point(56, 16);
         this.cboItems.Name = "cboItems";
         this.cboItems.Size = new System.Drawing.Size(184, 21);
         this.cboItems.TabIndex = 5;
         // 
         // lblPrice
         // 
         this.lblPrice.Location = new System.Drawing.Point(8, 48);
         this.lblPrice.Name = "lblPrice";
         this.lblPrice.Size = new System.Drawing.Size(40, 21);
         this.lblPrice.TabIndex = 1;
         this.lblPrice.Text = "Price:";
         this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblResult
         // 
         this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblResult.Location = new System.Drawing.Point(56, 48);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(96, 21);
         this.lblResult.TabIndex = 2;
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // btnSearch
         // 
         this.btnSearch.Location = new System.Drawing.Point(160, 48);
         this.btnSearch.Name = "btnSearch";
         this.btnSearch.Size = new System.Drawing.Size(80, 23);
         this.btnSearch.TabIndex = 4;
         this.btnSearch.Text = "&Search";
         // 
         // lblSource
         // 
         this.lblSource.Location = new System.Drawing.Point(8, 80);
         this.lblSource.Name = "lblSource";
         this.lblSource.Size = new System.Drawing.Size(48, 16);
         this.lblSource.TabIndex = 1;
         this.lblSource.Text = "Source:";
         this.lblSource.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblHTML
         // 
         this.lblHTML.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblHTML.Location = new System.Drawing.Point(16, 104);
         this.lblHTML.Name = "lblHTML";
         this.lblHTML.Size = new System.Drawing.Size(224, 112);
         this.lblHTML.TabIndex = 6;
         // 
         // FrmScreenScraping
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(256, 229);
         this.Controls.Add(this.lblHTML);
         this.Controls.Add(this.lblSource);
         this.Controls.Add(this.btnSearch);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.lblPrice);
         this.Controls.Add(this.cboItems);
         this.Controls.Add(this.lblItem);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmScreenScraping";
         this.Text = "Screen Scraping";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmScreenScraping() );
      }

   } // end class FrmScreenScraping
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
