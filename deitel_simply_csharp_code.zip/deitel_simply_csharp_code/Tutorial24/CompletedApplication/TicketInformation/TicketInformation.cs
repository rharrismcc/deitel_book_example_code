using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace TicketInformation
{
   /// <summary>
   /// Summary description for FrmEvents.
   /// </summary>
   public class FrmEvents : System.Windows.Forms.Form
   {
      // Label and MonthCalendar to choose a date
      private System.Windows.Forms.Label lblDate;
      private System.Windows.Forms.MonthCalendar mvwDate;

      // Label and ComboBox to choose an event
      private System.Windows.Forms.Label lblEvent;
      private System.Windows.Forms.ComboBox cboEvent;

      // Label and TextBox to input a description
      private System.Windows.Forms.Label lblDescription;
      private System.Windows.Forms.TextBox txtDescription;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // stores information for up to 10 events
      private string[,] m_strData = new string[ 10, 5 ];

      // number of events on a given day
      private int m_intNumberOfEvents;

      public FrmEvents()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblDate = new System.Windows.Forms.Label();
         this.lblEvent = new System.Windows.Forms.Label();
         this.cboEvent = new System.Windows.Forms.ComboBox();
         this.lblDescription = new System.Windows.Forms.Label();
         this.txtDescription = new System.Windows.Forms.TextBox();
         this.mvwDate = new System.Windows.Forms.MonthCalendar();
         this.SuspendLayout();
         // 
         // lblDate
         // 
         this.lblDate.Location = new System.Drawing.Point(16, 16);
         this.lblDate.Name = "lblDate";
         this.lblDate.Size = new System.Drawing.Size(88, 16);
         this.lblDate.TabIndex = 0;
         this.lblDate.Text = "Select the date:";
         // 
         // lblEvent
         // 
         this.lblEvent.Location = new System.Drawing.Point(16, 208);
         this.lblEvent.Name = "lblEvent";
         this.lblEvent.Size = new System.Drawing.Size(80, 16);
         this.lblEvent.TabIndex = 1;
         this.lblEvent.Text = "Pick an event:";
         // 
         // cboEvent
         // 
         this.cboEvent.Location = new System.Drawing.Point(16, 224);
         this.cboEvent.Name = "cboEvent";
         this.cboEvent.TabIndex = 2;
         this.cboEvent.SelectedIndexChanged += new System.EventHandler(this.cboEvent_SelectedIndexChanged);
         // 
         // lblDescription
         // 
         this.lblDescription.Location = new System.Drawing.Point(16, 264);
         this.lblDescription.Name = "lblDescription";
         this.lblDescription.Size = new System.Drawing.Size(80, 16);
         this.lblDescription.TabIndex = 3;
         this.lblDescription.Text = "Description:";
         // 
         // txtDescription
         // 
         this.txtDescription.Location = new System.Drawing.Point(16, 280);
         this.txtDescription.Multiline = true;
         this.txtDescription.Name = "txtDescription";
         this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.txtDescription.Size = new System.Drawing.Size(200, 80);
         this.txtDescription.TabIndex = 4;
         this.txtDescription.Text = "";
         // 
         // mvwDate
         // 
         this.mvwDate.Location = new System.Drawing.Point(16, 32);
         this.mvwDate.Name = "mvwDate";
         this.mvwDate.TabIndex = 5;
         this.mvwDate.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.mvwDate_DateChanged);
         // 
         // FrmEvents
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(232, 373);
         this.Controls.Add(this.mvwDate);
         this.Controls.Add(this.txtDescription);
         this.Controls.Add(this.lblDescription);
         this.Controls.Add(this.cboEvent);
         this.Controls.Add(this.lblEvent);
         this.Controls.Add(this.lblDate);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmEvents";
         this.Text = "Ticket Information";
         this.Load += new System.EventHandler(this.FrmEvents_Load);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmEvents() );
      }

      // populates ComboBox with current day's events (if any)
      private void CreateEventList()
      {
         int intCount; // counter

         // stores event information in array m_strData
         // and assigns number of events to m_intNumberOfEvents
         ExtractData( mvwDate.SelectionStart );

         // remove any items in ComboBox
         cboEvent.Items.Clear();

         // add each new event name to ComboBox
         if ( m_intNumberOfEvents > 0 )
         {
            for ( intCount = 0; intCount < m_intNumberOfEvents;
               intCount++ )
            {
               // extract and display event name
               cboEvent.Items.Add( m_strData[ intCount, 3 ] );
            }

            // inform user that events are scheduled
            cboEvent.Text = " - Events - ";
            txtDescription.Text = "Pick an event.";
         }

         // inform user that no events are scheduled
         else
         {
            cboEvent.Text = " - No Events - ";
            txtDescription.Text = "No events today.";
         }
      
      } // end method CreateEventList

      // extracts event data for a specified day from calendar.txt
      // and returns number of events during that day
      private void ExtractData( DateTime dtmDay )
      {
         // set to selected date in MonthCalendar control
         int intChosenDay = dtmDay.Day;
         int intFileDay; // day of event from file
         int intLineNumbers; // counts lines to skip

         m_intNumberOfEvents = 0; // set number of events to 0

         // initialize StreamReader to read lines from file
         StreamReader objInput = 
            new StreamReader( "calendar.txt" );

         // read first line before entering loop
         string strLine = objInput.ReadLine();

         // loop through lines in file
         while ( objInput.Peek() > -1 &&
            m_intNumberOfEvents < 10 )
         {
            intFileDay = Int32.Parse( strLine ); // extract day

            // if event scheduled for specified day,
            // store information
            if ( intFileDay == intChosenDay )
            {
               m_strData[ m_intNumberOfEvents, 0 ] = strLine;
               m_strData[ m_intNumberOfEvents, 1 ] = 
                  objInput.ReadLine();
               m_strData[ m_intNumberOfEvents, 2 ] = 
                  objInput.ReadLine();
               m_strData[ m_intNumberOfEvents, 3 ] = 
                  objInput.ReadLine();
               m_strData[ m_intNumberOfEvents, 4 ] = 
                  objInput.ReadLine();
               m_intNumberOfEvents++;
            }
            else
            {
               // skip to next event in file
               for ( intLineNumbers = 0; intLineNumbers <= 3;
                  intLineNumbers++ )
                  strLine = objInput.ReadLine();
            }

            // read day of next event in file
            strLine = objInput.ReadLine();

         } // end while

      } // end method ExtractData

      // handles Form's Load event
      private void FrmEvents_Load( 
         object sender, System.EventArgs e )
      {
         // display any events scheduled for today in ComboBox
         CreateEventList();

      } // end method FrmEvents_Load

      // handles MonthCalendar's DateChanged event
      private void mvwDate_DateChanged(
         object sender, System.Windows.Forms.DateRangeEventArgs e )
      {
         // display any events for the specified date in ComboBox
         CreateEventList();

      } // end method mvwDate_DateChanged

      // handles ComboBox's SelectedIndexChanged event
      private void cboEvent_SelectedIndexChanged( 
         object sender, System.EventArgs e )
      {
         // place time, price and description of event in TextBox
         txtDescription.Text = 
            m_strData[ cboEvent.SelectedIndex, 1 ];
         txtDescription.Text += "\r\n";
         txtDescription.Text += "Price: $" +
            m_strData[ cboEvent.SelectedIndex, 2 ];
         txtDescription.Text += "\r\n";
         txtDescription.Text += 
            m_strData[ cboEvent.SelectedIndex, 4 ];

      } // end method cboEvent_SelectedIndexChanged

   } // end class FrmEvents
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/