using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace BirthdaySaver
{
   /// <summary>
   /// Summary description for FrmBirthdaySaver.
   /// </summary>
   public class FrmBirthdaySaver : System.Windows.Forms.Form
   {
      // Label and TextBox to input first name
      private System.Windows.Forms.Label lblFirstName;
      private System.Windows.Forms.TextBox txtFirstName;

      // Label and TextBox to input last name
      private System.Windows.Forms.Label lblLastName;
      private System.Windows.Forms.TextBox txtLastName;

      // Label and DateTimePicker to choose birthday
      private System.Windows.Forms.Label lblBirthday;
      private System.Windows.Forms.DateTimePicker dtpBirthday;

      // Button to open a file
      private System.Windows.Forms.Button btnOpen;

      // Button to put an entry into the file
      private System.Windows.Forms.Button btnEnter;

      // Button to close a file
      private System.Windows.Forms.Button btnClose;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmBirthdaySaver()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblFirstName = new System.Windows.Forms.Label();
         this.txtFirstName = new System.Windows.Forms.TextBox();
         this.lblLastName = new System.Windows.Forms.Label();
         this.txtLastName = new System.Windows.Forms.TextBox();
         this.lblBirthday = new System.Windows.Forms.Label();
         this.dtpBirthday = new System.Windows.Forms.DateTimePicker();
         this.btnOpen = new System.Windows.Forms.Button();
         this.btnEnter = new System.Windows.Forms.Button();
         this.btnClose = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblFirstName
         // 
         this.lblFirstName.Location = new System.Drawing.Point(16, 8);
         this.lblFirstName.Name = "lblFirstName";
         this.lblFirstName.Size = new System.Drawing.Size(64, 21);
         this.lblFirstName.TabIndex = 1;
         this.lblFirstName.Text = "First name:";
         this.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtFirstName
         // 
         this.txtFirstName.Location = new System.Drawing.Point(96, 8);
         this.txtFirstName.Name = "txtFirstName";
         this.txtFirstName.TabIndex = 2;
         this.txtFirstName.Text = "";
         this.txtFirstName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblLastName
         // 
         this.lblLastName.Location = new System.Drawing.Point(16, 40);
         this.lblLastName.Name = "lblLastName";
         this.lblLastName.Size = new System.Drawing.Size(64, 21);
         this.lblLastName.TabIndex = 3;
         this.lblLastName.Text = "Last name:";
         this.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtLastName
         // 
         this.txtLastName.Location = new System.Drawing.Point(96, 40);
         this.txtLastName.Name = "txtLastName";
         this.txtLastName.TabIndex = 4;
         this.txtLastName.Text = "";
         this.txtLastName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblBirthday
         // 
         this.lblBirthday.Location = new System.Drawing.Point(16, 72);
         this.lblBirthday.Name = "lblBirthday";
         this.lblBirthday.Size = new System.Drawing.Size(56, 21);
         this.lblBirthday.TabIndex = 5;
         this.lblBirthday.Text = "Birthday:";
         this.lblBirthday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // dtpBirthday
         // 
         this.dtpBirthday.CustomFormat = "MM/dd/yyyy";
         this.dtpBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
         this.dtpBirthday.Location = new System.Drawing.Point(96, 72);
         this.dtpBirthday.Name = "dtpBirthday";
         this.dtpBirthday.ShowUpDown = true;
         this.dtpBirthday.Size = new System.Drawing.Size(100, 21);
         this.dtpBirthday.TabIndex = 6;
         // 
         // btnOpen
         // 
         this.btnOpen.Location = new System.Drawing.Point(208, 8);
         this.btnOpen.Name = "btnOpen";
         this.btnOpen.TabIndex = 7;
         this.btnOpen.Text = "Open File...";
         // 
         // btnEnter
         // 
         this.btnEnter.Enabled = false;
         this.btnEnter.Location = new System.Drawing.Point(208, 40);
         this.btnEnter.Name = "btnEnter";
         this.btnEnter.TabIndex = 8;
         this.btnEnter.Text = "Enter";
         // 
         // btnClose
         // 
         this.btnClose.Enabled = false;
         this.btnClose.Location = new System.Drawing.Point(208, 72);
         this.btnClose.Name = "btnClose";
         this.btnClose.TabIndex = 9;
         this.btnClose.Text = "Close File";
         // 
         // FrmBirthdaySaver
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(296, 101);
         this.Controls.Add(this.btnClose);
         this.Controls.Add(this.btnEnter);
         this.Controls.Add(this.btnOpen);
         this.Controls.Add(this.dtpBirthday);
         this.Controls.Add(this.lblBirthday);
         this.Controls.Add(this.txtLastName);
         this.Controls.Add(this.lblLastName);
         this.Controls.Add(this.txtFirstName);
         this.Controls.Add(this.lblFirstName);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmBirthdaySaver";
         this.Text = "Birthday Saver";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmBirthdaySaver() );
      }

   } // end class FrmBirthdaySaver
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/