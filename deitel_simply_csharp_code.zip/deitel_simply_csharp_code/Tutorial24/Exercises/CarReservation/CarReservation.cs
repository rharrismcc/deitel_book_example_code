using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CarReservation
{
   /// <summary>
   /// Summary description for FrmCarReservation.
   /// </summary>
   public class FrmCarReservation : System.Windows.Forms.Form
   {
      // Label to select date of reservation
      private System.Windows.Forms.Label lblSelect;

      // Label and TextBox to input name
      private System.Windows.Forms.Label lblName;
      private System.Windows.Forms.TextBox txtName;

      // Button to reserve a car
      private System.Windows.Forms.Button btnReserve;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmCarReservation()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblSelect = new System.Windows.Forms.Label();
         this.lblName = new System.Windows.Forms.Label();
         this.txtName = new System.Windows.Forms.TextBox();
         this.btnReserve = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblSelect
         // 
         this.lblSelect.Location = new System.Drawing.Point(16, 16);
         this.lblSelect.Name = "lblSelect";
         this.lblSelect.Size = new System.Drawing.Size(88, 16);
         this.lblSelect.TabIndex = 2;
         this.lblSelect.Text = "Select the date:";
         // 
         // lblName
         // 
         this.lblName.Location = new System.Drawing.Point(16, 200);
         this.lblName.Name = "lblName";
         this.lblName.Size = new System.Drawing.Size(48, 16);
         this.lblName.TabIndex = 3;
         this.lblName.Text = "Name:";
         // 
         // txtName
         // 
         this.txtName.Location = new System.Drawing.Point(64, 200);
         this.txtName.Name = "txtName";
         this.txtName.Size = new System.Drawing.Size(144, 21);
         this.txtName.TabIndex = 4;
         this.txtName.Text = "";
         // 
         // btnReserve
         // 
         this.btnReserve.Location = new System.Drawing.Point(48, 232);
         this.btnReserve.Name = "btnReserve";
         this.btnReserve.Size = new System.Drawing.Size(136, 23);
         this.btnReserve.TabIndex = 7;
         this.btnReserve.Text = "Reserve Car";
         // 
         // FrmCarReservation
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(224, 269);
         this.Controls.Add(this.btnReserve);
         this.Controls.Add(this.txtName);
         this.Controls.Add(this.lblName);
         this.Controls.Add(this.lblSelect);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCarReservation";
         this.Text = "Car Reservation";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCarReservation() );
      }
      
   } // end class FrmCarReservation
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/