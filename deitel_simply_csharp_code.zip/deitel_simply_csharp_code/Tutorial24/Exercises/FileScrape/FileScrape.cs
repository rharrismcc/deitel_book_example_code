using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace FileScrape
{
   /// <summary>
   /// Summary description for FrmFileScrape.
   /// </summary>
   public class FrmFileScrape : System.Windows.Forms.Form
   {
      // Label and TextBox to displays the file path
      private System.Windows.Forms.Label lblPath;
      private System.Windows.Forms.TextBox txtPath;

      // Label and TextBox that displays the book price
      // found in the HTML file
      private System.Windows.Forms.Label lblResult;
      private System.Windows.Forms.TextBox txtPrice;

      // Button to open an HTML file
      private System.Windows.Forms.Button btnOpen;

      // Button to search the HTML file for the book price
      private System.Windows.Forms.Button btnSearch;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmFileScrape()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblPath = new System.Windows.Forms.Label();
         this.txtPath = new System.Windows.Forms.TextBox();
         this.lblResult = new System.Windows.Forms.Label();
         this.txtPrice = new System.Windows.Forms.TextBox();
         this.btnOpen = new System.Windows.Forms.Button();
         this.btnSearch = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblPath
         // 
         this.lblPath.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblPath.Location = new System.Drawing.Point(16, 16);
         this.lblPath.Name = "lblPath";
         this.lblPath.Size = new System.Drawing.Size(56, 23);
         this.lblPath.TabIndex = 4;
         this.lblPath.Text = "File path:";
         this.lblPath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtPath
         // 
         this.txtPath.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtPath.Location = new System.Drawing.Point(80, 16);
         this.txtPath.Multiline = true;
         this.txtPath.Name = "txtPath";
         this.txtPath.ReadOnly = true;
         this.txtPath.Size = new System.Drawing.Size(176, 23);
         this.txtPath.TabIndex = 7;
         this.txtPath.Text = "";
         // 
         // lblResult
         // 
         this.lblResult.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblResult.Location = new System.Drawing.Point(16, 56);
         this.lblResult.Name = "lblResult";
         this.lblResult.Size = new System.Drawing.Size(128, 23);
         this.lblResult.TabIndex = 8;
         this.lblResult.Text = "The price of the book is: ";
         this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtPrice
         // 
         this.txtPrice.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtPrice.Location = new System.Drawing.Point(152, 56);
         this.txtPrice.Name = "txtPrice";
         this.txtPrice.ReadOnly = true;
         this.txtPrice.Size = new System.Drawing.Size(104, 21);
         this.txtPrice.TabIndex = 9;
         this.txtPrice.Text = "";
         this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // btnOpen
         // 
         this.btnOpen.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnOpen.Location = new System.Drawing.Point(272, 16);
         this.btnOpen.Name = "btnOpen";
         this.btnOpen.TabIndex = 10;
         this.btnOpen.Text = "Open...";
         // 
         // btnSearch
         // 
         this.btnSearch.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnSearch.Location = new System.Drawing.Point(272, 56);
         this.btnSearch.Name = "btnSearch";
         this.btnSearch.TabIndex = 11;
         this.btnSearch.Text = "Search";
         // 
         // FrmFileScrape
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(360, 93);
         this.Controls.Add(this.btnSearch);
         this.Controls.Add(this.btnOpen);
         this.Controls.Add(this.txtPrice);
         this.Controls.Add(this.lblResult);
         this.Controls.Add(this.txtPath);
         this.Controls.Add(this.lblPath);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmFileScrape";
         this.Text = "Book Price";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmFileScrape() );
      }

   } // end class FrmFileScrape
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/