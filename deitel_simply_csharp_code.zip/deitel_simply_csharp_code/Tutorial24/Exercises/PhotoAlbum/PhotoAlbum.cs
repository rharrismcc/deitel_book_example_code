using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace PhotoAlbum
{
   /// <summary>
   /// Summary description for FrmPhotoAlbum.
   /// </summary>
   public class FrmPhotoAlbum : System.Windows.Forms.Form
   {
      // PictureBox and TextBox to display a picture and its
      // description
      private System.Windows.Forms.PictureBox picMain;
      private System.Windows.Forms.TextBox txtDescription;

      // PictureBox to display and Button to move to the previous
      // picture
      private System.Windows.Forms.PictureBox picPrevious;
      private System.Windows.Forms.Button btnPrevious;

      // PictureBox to display and Button to move to the next
      // picture
      private System.Windows.Forms.PictureBox picNext;
      private System.Windows.Forms.Button btnNext;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmPhotoAlbum()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.picMain = new System.Windows.Forms.PictureBox();
         this.txtDescription = new System.Windows.Forms.TextBox();
         this.picPrevious = new System.Windows.Forms.PictureBox();
         this.btnPrevious = new System.Windows.Forms.Button();
         this.picNext = new System.Windows.Forms.PictureBox();
         this.btnNext = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // picMain
         // 
         this.picMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.picMain.Location = new System.Drawing.Point(16, 16);
         this.picMain.Name = "picMain";
         this.picMain.Size = new System.Drawing.Size(273, 357);
         this.picMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
         this.picMain.TabIndex = 2;
         this.picMain.TabStop = false;
         // 
         // txtDescription
         // 
         this.txtDescription.Location = new System.Drawing.Point(16, 392);
         this.txtDescription.Multiline = true;
         this.txtDescription.Name = "txtDescription";
         this.txtDescription.ReadOnly = true;
         this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.txtDescription.Size = new System.Drawing.Size(272, 48);
         this.txtDescription.TabIndex = 8;
         this.txtDescription.Text = "";
         // 
         // picPrevious
         // 
         this.picPrevious.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.picPrevious.Location = new System.Drawing.Point(320, 32);
         this.picPrevious.Name = "picPrevious";
         this.picPrevious.Size = new System.Drawing.Size(91, 119);
         this.picPrevious.TabIndex = 9;
         this.picPrevious.TabStop = false;
         // 
         // btnPrevious
         // 
         this.btnPrevious.Location = new System.Drawing.Point(320, 160);
         this.btnPrevious.Name = "btnPrevious";
         this.btnPrevious.Size = new System.Drawing.Size(91, 23);
         this.btnPrevious.TabIndex = 10;
         this.btnPrevious.Text = "Previous Image";
         // 
         // picNext
         // 
         this.picNext.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.picNext.Location = new System.Drawing.Point(320, 240);
         this.picNext.Name = "picNext";
         this.picNext.Size = new System.Drawing.Size(91, 119);
         this.picNext.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
         this.picNext.TabIndex = 11;
         this.picNext.TabStop = false;
         // 
         // btnNext
         // 
         this.btnNext.Location = new System.Drawing.Point(320, 368);
         this.btnNext.Name = "btnNext";
         this.btnNext.Size = new System.Drawing.Size(91, 23);
         this.btnNext.TabIndex = 12;
         this.btnNext.Text = "Next Image";
         // 
         // FrmPhotoAlbum
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(424, 453);
         this.Controls.Add(this.btnNext);
         this.Controls.Add(this.picNext);
         this.Controls.Add(this.btnPrevious);
         this.Controls.Add(this.picPrevious);
         this.Controls.Add(this.txtDescription);
         this.Controls.Add(this.picMain);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmPhotoAlbum";
         this.Text = "Photo Album";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmPhotoAlbum() );
      }

   } // end class FrmPhotoAlbum
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/