using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TicketInformation
{
   /// <summary>
   /// Summary description for FrmEvents.
   /// </summary>
   public class FrmEvents : System.Windows.Forms.Form
   {
      // Label to choose a date
      private System.Windows.Forms.Label lblDate;

      // Label and ComboBox to choose an event
      private System.Windows.Forms.Label lblEvent;
      private System.Windows.Forms.ComboBox cboEvent;

      // Label and TextBox to input a description
      private System.Windows.Forms.Label lblDescription;
      private System.Windows.Forms.TextBox txtDescription;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmEvents()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblDate = new System.Windows.Forms.Label();
         this.lblEvent = new System.Windows.Forms.Label();
         this.cboEvent = new System.Windows.Forms.ComboBox();
         this.lblDescription = new System.Windows.Forms.Label();
         this.txtDescription = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // lblDate
         // 
         this.lblDate.Location = new System.Drawing.Point(16, 16);
         this.lblDate.Name = "lblDate";
         this.lblDate.Size = new System.Drawing.Size(88, 16);
         this.lblDate.TabIndex = 0;
         this.lblDate.Text = "Select the date:";
         // 
         // lblEvent
         // 
         this.lblEvent.Location = new System.Drawing.Point(16, 208);
         this.lblEvent.Name = "lblEvent";
         this.lblEvent.Size = new System.Drawing.Size(80, 16);
         this.lblEvent.TabIndex = 1;
         this.lblEvent.Text = "Pick an event:";
         // 
         // cboEvent
         // 
         this.cboEvent.Location = new System.Drawing.Point(16, 224);
         this.cboEvent.Name = "cboEvent";
         this.cboEvent.TabIndex = 2;
         // 
         // lblDescription
         // 
         this.lblDescription.Location = new System.Drawing.Point(16, 264);
         this.lblDescription.Name = "lblDescription";
         this.lblDescription.Size = new System.Drawing.Size(80, 16);
         this.lblDescription.TabIndex = 3;
         this.lblDescription.Text = "Description:";
         // 
         // txtDescription
         // 
         this.txtDescription.Location = new System.Drawing.Point(16, 280);
         this.txtDescription.Multiline = true;
         this.txtDescription.Name = "txtDescription";
         this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.txtDescription.Size = new System.Drawing.Size(200, 80);
         this.txtDescription.TabIndex = 4;
         this.txtDescription.Text = "";
         // 
         // FrmEvents
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(232, 373);
         this.Controls.Add(this.txtDescription);
         this.Controls.Add(this.lblDescription);
         this.Controls.Add(this.cboEvent);
         this.Controls.Add(this.lblEvent);
         this.Controls.Add(this.lblDate);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmEvents";
         this.Text = "Ticket Information";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmEvents() );
      }

      // populates ComboBox with current day's events (if any)
      private void CreateEventList()
      {
      
      } // end method CreateEventList

      // extracts event data for a specified day from calendar.txt
      // and returns number of events during that day
      private void ExtractData( DateTime dtmDay )
      {

      }

   } // end class FrmEvents
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/