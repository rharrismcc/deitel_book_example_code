using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WriteEvent
{
   /// <summary>
   /// Summary description for FrmWriteEvent.
   /// </summary>
   public class FrmWriteEvent : System.Windows.Forms.Form
   {
      // Label and NumericUpDown to choose day
      private System.Windows.Forms.Label lblDay;
      private System.Windows.Forms.NumericUpDown updDay;

      // Label and DateTimePicker to choose time
      private System.Windows.Forms.Label lblTime;
      private System.Windows.Forms.DateTimePicker dtpTime;

      // Label and TextBox to input price
      private System.Windows.Forms.Label lblPrice;
      private System.Windows.Forms.TextBox txtPrice;

      // Label and TextBox to input event
      private System.Windows.Forms.Label lblEvent;
      private System.Windows.Forms.TextBox txtEvent;

      // Label and TextBox to input description
      private System.Windows.Forms.Label lblDescription;
      private System.Windows.Forms.TextBox txtDescription;

      // Button to open an existing file
      private System.Windows.Forms.Button btnOpenFile;

      // Button to write data to the file
      private System.Windows.Forms.Button btnEnter;

      // Button to close a file
      private System.Windows.Forms.Button btnCloseFile;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmWriteEvent()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblDay = new System.Windows.Forms.Label();
         this.updDay = new System.Windows.Forms.NumericUpDown();
         this.lblTime = new System.Windows.Forms.Label();
         this.dtpTime = new System.Windows.Forms.DateTimePicker();
         this.lblPrice = new System.Windows.Forms.Label();
         this.txtPrice = new System.Windows.Forms.TextBox();
         this.lblEvent = new System.Windows.Forms.Label();
         this.txtEvent = new System.Windows.Forms.TextBox();
         this.lblDescription = new System.Windows.Forms.Label();
         this.txtDescription = new System.Windows.Forms.TextBox();
         this.btnOpenFile = new System.Windows.Forms.Button();
         this.btnEnter = new System.Windows.Forms.Button();
         this.btnCloseFile = new System.Windows.Forms.Button();
         ((System.ComponentModel.ISupportInitialize)(this.updDay)).BeginInit();
         this.SuspendLayout();
         // 
         // lblDay
         // 
         this.lblDay.Location = new System.Drawing.Point(32, 13);
         this.lblDay.Name = "lblDay";
         this.lblDay.Size = new System.Drawing.Size(32, 21);
         this.lblDay.TabIndex = 9;
         this.lblDay.Text = "Day:";
         this.lblDay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // updDay
         // 
         this.updDay.Location = new System.Drawing.Point(104, 16);
         this.updDay.Maximum = new System.Decimal(new int[] {
                                                               31,
                                                               0,
                                                               0,
                                                               0});
         this.updDay.Minimum = new System.Decimal(new int[] {
                                                               1,
                                                               0,
                                                               0,
                                                               0});
         this.updDay.Name = "updDay";
         this.updDay.ReadOnly = true;
         this.updDay.TabIndex = 4;
         this.updDay.Value = new System.Decimal(new int[] {
                                                             1,
                                                             0,
                                                             0,
                                                             0});
         // 
         // lblTime
         // 
         this.lblTime.Location = new System.Drawing.Point(32, 45);
         this.lblTime.Name = "lblTime";
         this.lblTime.Size = new System.Drawing.Size(40, 21);
         this.lblTime.TabIndex = 10;
         this.lblTime.Text = "Time:";
         this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // dtpTime
         // 
         this.dtpTime.CustomFormat = "h:mm tt";
         this.dtpTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
         this.dtpTime.Location = new System.Drawing.Point(104, 48);
         this.dtpTime.Name = "dtpTime";
         this.dtpTime.ShowUpDown = true;
         this.dtpTime.Size = new System.Drawing.Size(120, 21);
         this.dtpTime.TabIndex = 5;
         this.dtpTime.Value = new System.DateTime(2003, 6, 6, 0, 0, 0, 0);
         // 
         // lblPrice
         // 
         this.lblPrice.Location = new System.Drawing.Point(32, 77);
         this.lblPrice.Name = "lblPrice";
         this.lblPrice.Size = new System.Drawing.Size(40, 21);
         this.lblPrice.TabIndex = 11;
         this.lblPrice.Text = "Price:";
         this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtPrice
         // 
         this.txtPrice.Location = new System.Drawing.Point(104, 80);
         this.txtPrice.Name = "txtPrice";
         this.txtPrice.Size = new System.Drawing.Size(120, 21);
         this.txtPrice.TabIndex = 6;
         this.txtPrice.Text = "";
         // 
         // lblEvent
         // 
         this.lblEvent.Location = new System.Drawing.Point(32, 109);
         this.lblEvent.Name = "lblEvent";
         this.lblEvent.Size = new System.Drawing.Size(40, 21);
         this.lblEvent.TabIndex = 12;
         this.lblEvent.Text = "Event:";
         this.lblEvent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtEvent
         // 
         this.txtEvent.Location = new System.Drawing.Point(104, 112);
         this.txtEvent.Name = "txtEvent";
         this.txtEvent.Size = new System.Drawing.Size(120, 21);
         this.txtEvent.TabIndex = 7;
         this.txtEvent.Text = "";
         // 
         // lblDescription
         // 
         this.lblDescription.Location = new System.Drawing.Point(32, 141);
         this.lblDescription.Name = "lblDescription";
         this.lblDescription.Size = new System.Drawing.Size(64, 23);
         this.lblDescription.TabIndex = 12;
         this.lblDescription.Text = "Description:";
         this.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtDescription
         // 
         this.txtDescription.Location = new System.Drawing.Point(104, 144);
         this.txtDescription.Multiline = true;
         this.txtDescription.Name = "txtDescription";
         this.txtDescription.Size = new System.Drawing.Size(120, 48);
         this.txtDescription.TabIndex = 8;
         this.txtDescription.Text = "";
         // 
         // btnOpenFile
         // 
         this.btnOpenFile.Location = new System.Drawing.Point(16, 208);
         this.btnOpenFile.Name = "btnOpenFile";
         this.btnOpenFile.Size = new System.Drawing.Size(72, 23);
         this.btnOpenFile.TabIndex = 0;
         this.btnOpenFile.Text = "&Open File...";
         // 
         // btnEnter
         // 
         this.btnEnter.Enabled = false;
         this.btnEnter.Location = new System.Drawing.Point(104, 208);
         this.btnEnter.Name = "btnEnter";
         this.btnEnter.Size = new System.Drawing.Size(48, 23);
         this.btnEnter.TabIndex = 2;
         this.btnEnter.Text = "&Enter";
         // 
         // btnCloseFile
         // 
         this.btnCloseFile.Enabled = false;
         this.btnCloseFile.Location = new System.Drawing.Point(168, 208);
         this.btnCloseFile.Name = "btnCloseFile";
         this.btnCloseFile.Size = new System.Drawing.Size(72, 23);
         this.btnCloseFile.TabIndex = 3;
         this.btnCloseFile.Text = "&Close File";
         // 
         // FrmWriteEvent
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(256, 245);
         this.Controls.Add(this.btnCloseFile);
         this.Controls.Add(this.btnEnter);
         this.Controls.Add(this.btnOpenFile);
         this.Controls.Add(this.txtDescription);
         this.Controls.Add(this.lblDescription);
         this.Controls.Add(this.txtEvent);
         this.Controls.Add(this.lblEvent);
         this.Controls.Add(this.txtPrice);
         this.Controls.Add(this.lblPrice);
         this.Controls.Add(this.dtpTime);
         this.Controls.Add(this.lblTime);
         this.Controls.Add(this.updDay);
         this.Controls.Add(this.lblDay);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmWriteEvent";
         this.Text = "Write Event";
         ((System.ComponentModel.ISupportInitialize)(this.updDay)).EndInit();
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmWriteEvent() );
      }

   } // end class FrmWriteEvent
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
