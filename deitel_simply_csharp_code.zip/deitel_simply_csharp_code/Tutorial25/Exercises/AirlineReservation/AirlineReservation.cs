using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace AirlineReservation
{
   /// <summary>
   /// Summary description for FrmAirlineReservation.
   /// </summary>
   public class FrmAirlineReservation : System.Windows.Forms.Form
   {
      // Label and ComboBox to choose a flight
      private System.Windows.Forms.Label lblChooseFlight;
      private System.Windows.Forms.ComboBox cboChooseAFlight;

      // Button to view flight information
      private System.Windows.Forms.Button btnViewFlightInformation;

      // GroupBox containing flight information
      private System.Windows.Forms.GroupBox fraFlightInformation;

      // Labels to display date of flight, departure city, and
      // arrival city
      private System.Windows.Forms.Label lblDate;
      private System.Windows.Forms.Label lblDateOutput;
      private System.Windows.Forms.Label lblDeparture;
      private System.Windows.Forms.Label lblDepartureOutput;
      private System.Windows.Forms.Label lblArrival;
      private System.Windows.Forms.Label lblArrivalOutput;

      // GroupBox containing ListBox to display passenger list
      private System.Windows.Forms.GroupBox fraPassengerList;
      private System.Windows.Forms.ListBox lstDisplay;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmAirlineReservation()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblChooseFlight = new System.Windows.Forms.Label();
         this.cboChooseAFlight = new System.Windows.Forms.ComboBox();
         this.btnViewFlightInformation = new System.Windows.Forms.Button();
         this.fraFlightInformation = new System.Windows.Forms.GroupBox();
         this.lblArrivalOutput = new System.Windows.Forms.Label();
         this.lblDepartureOutput = new System.Windows.Forms.Label();
         this.lblDateOutput = new System.Windows.Forms.Label();
         this.lblArrival = new System.Windows.Forms.Label();
         this.lblDeparture = new System.Windows.Forms.Label();
         this.lblDate = new System.Windows.Forms.Label();
         this.fraPassengerList = new System.Windows.Forms.GroupBox();
         this.lstDisplay = new System.Windows.Forms.ListBox();
         this.fraFlightInformation.SuspendLayout();
         this.fraPassengerList.SuspendLayout();
         this.SuspendLayout();
         // 
         // lblChooseFlight
         // 
         this.lblChooseFlight.Location = new System.Drawing.Point(24, 16);
         this.lblChooseFlight.Name = "lblChooseFlight";
         this.lblChooseFlight.Size = new System.Drawing.Size(88, 16);
         this.lblChooseFlight.TabIndex = 1;
         this.lblChooseFlight.Text = "Choose a Flight:";
         // 
         // cboChooseAFlight
         // 
         this.cboChooseAFlight.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboChooseAFlight.Location = new System.Drawing.Point(128, 16);
         this.cboChooseAFlight.Name = "cboChooseAFlight";
         this.cboChooseAFlight.Size = new System.Drawing.Size(72, 21);
         this.cboChooseAFlight.TabIndex = 2;
         // 
         // btnViewFlightInformation
         // 
         this.btnViewFlightInformation.Location = new System.Drawing.Point(224, 16);
         this.btnViewFlightInformation.Name = "btnViewFlightInformation";
         this.btnViewFlightInformation.Size = new System.Drawing.Size(136, 24);
         this.btnViewFlightInformation.TabIndex = 3;
         this.btnViewFlightInformation.Text = "&View Flight Information";
         // 
         // fraFlightInformation
         // 
         this.fraFlightInformation.Controls.Add(this.lblArrivalOutput);
         this.fraFlightInformation.Controls.Add(this.lblDepartureOutput);
         this.fraFlightInformation.Controls.Add(this.lblDateOutput);
         this.fraFlightInformation.Controls.Add(this.lblArrival);
         this.fraFlightInformation.Controls.Add(this.lblDeparture);
         this.fraFlightInformation.Controls.Add(this.lblDate);
         this.fraFlightInformation.Controls.Add(this.fraPassengerList);
         this.fraFlightInformation.Location = new System.Drawing.Point(16, 56);
         this.fraFlightInformation.Name = "fraFlightInformation";
         this.fraFlightInformation.Size = new System.Drawing.Size(344, 152);
         this.fraFlightInformation.TabIndex = 4;
         this.fraFlightInformation.TabStop = false;
         this.fraFlightInformation.Text = "Flight Information";
         // 
         // lblArrivalOutput
         // 
         this.lblArrivalOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblArrivalOutput.Location = new System.Drawing.Point(96, 96);
         this.lblArrivalOutput.Name = "lblArrivalOutput";
         this.lblArrivalOutput.Size = new System.Drawing.Size(88, 16);
         this.lblArrivalOutput.TabIndex = 7;
         // 
         // lblDepartureOutput
         // 
         this.lblDepartureOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblDepartureOutput.Location = new System.Drawing.Point(96, 64);
         this.lblDepartureOutput.Name = "lblDepartureOutput";
         this.lblDepartureOutput.Size = new System.Drawing.Size(88, 16);
         this.lblDepartureOutput.TabIndex = 6;
         // 
         // lblDateOutput
         // 
         this.lblDateOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblDateOutput.Location = new System.Drawing.Point(96, 32);
         this.lblDateOutput.Name = "lblDateOutput";
         this.lblDateOutput.Size = new System.Drawing.Size(88, 16);
         this.lblDateOutput.TabIndex = 5;
         // 
         // lblArrival
         // 
         this.lblArrival.Location = new System.Drawing.Point(16, 96);
         this.lblArrival.Name = "lblArrival";
         this.lblArrival.Size = new System.Drawing.Size(80, 16);
         this.lblArrival.TabIndex = 2;
         this.lblArrival.Text = "Arrival City:";
         this.lblArrival.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblDeparture
         // 
         this.lblDeparture.Location = new System.Drawing.Point(16, 64);
         this.lblDeparture.Name = "lblDeparture";
         this.lblDeparture.Size = new System.Drawing.Size(80, 16);
         this.lblDeparture.TabIndex = 1;
         this.lblDeparture.Text = "Departure City:";
         this.lblDeparture.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblDate
         // 
         this.lblDate.Location = new System.Drawing.Point(16, 32);
         this.lblDate.Name = "lblDate";
         this.lblDate.Size = new System.Drawing.Size(80, 16);
         this.lblDate.TabIndex = 0;
         this.lblDate.Text = "Date: ";
         this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // fraPassengerList
         // 
         this.fraPassengerList.Controls.Add(this.lstDisplay);
         this.fraPassengerList.Location = new System.Drawing.Point(200, 16);
         this.fraPassengerList.Name = "fraPassengerList";
         this.fraPassengerList.Size = new System.Drawing.Size(128, 120);
         this.fraPassengerList.TabIndex = 4;
         this.fraPassengerList.TabStop = false;
         this.fraPassengerList.Text = "Passenger List";
         // 
         // lstDisplay
         // 
         this.lstDisplay.Location = new System.Drawing.Point(16, 24);
         this.lstDisplay.Name = "lstDisplay";
         this.lstDisplay.Size = new System.Drawing.Size(96, 82);
         this.lstDisplay.TabIndex = 0;
         // 
         // FrmAirlineReservation
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(376, 229);
         this.Controls.Add(this.fraFlightInformation);
         this.Controls.Add(this.btnViewFlightInformation);
         this.Controls.Add(this.cboChooseAFlight);
         this.Controls.Add(this.lblChooseFlight);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmAirlineReservation";
         this.Text = "Airline Reservation";
         this.fraFlightInformation.ResumeLayout(false);
         this.fraPassengerList.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmAirlineReservation() );
      }

   } // end class FrmAirlineReservation
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/