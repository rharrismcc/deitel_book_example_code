using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace RestaurantBillCalculator
{
   /// <summary>
   /// Summary description for FrmRestaurantBillCalculator.
   /// </summary>
   public class FrmRestaurantBillCalculator : System.Windows.Forms.Form
   {
      // Label to display title
      private System.Windows.Forms.Label lblFoodHouse;

      // GroupBox containing Labels and TextBoxes to enter
      // table number and waiter name
      private System.Windows.Forms.GroupBox fraWaiterInformation;
      private System.Windows.Forms.Label lblTableNumber;
      private System.Windows.Forms.TextBox txtTableNumber;
      private System.Windows.Forms.Label lblWaiterName;
      private System.Windows.Forms.TextBox txtWaiterName;

      // GroupBox containing Labels and ComboBoxes for
      // choosing menu items
      private System.Windows.Forms.GroupBox fraMenuItems;
      private System.Windows.Forms.Label lblBeverage;
      private System.Windows.Forms.ComboBox cboBeverage;
      private System.Windows.Forms.Label lblAppetizer;
      private System.Windows.Forms.ComboBox cboAppetizer;
      private System.Windows.Forms.Label lblMainCourse;
      private System.Windows.Forms.ComboBox cboMainCourse;
      private System.Windows.Forms.Label lblDessert;
      private System.Windows.Forms.ComboBox cboDessert;

      // Button to calculate the bill
      private System.Windows.Forms.Button btnCalculateBill;

      // Labels and TextBoxes to display the subtotal, tax,
      // and total bill
      private System.Windows.Forms.Label lblSubtotal;
      private System.Windows.Forms.Label lblSubtotalResult;
      private System.Windows.Forms.Label lblTax;
      private System.Windows.Forms.Label lblTaxResult;
      private System.Windows.Forms.Label lblTotal;
      private System.Windows.Forms.Label lblTotalResult;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // hold all items on running bill
      private ArrayList m_objBillItems = new ArrayList();

      public FrmRestaurantBillCalculator()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.fraWaiterInformation = new System.Windows.Forms.GroupBox();
         this.lblWaiterName = new System.Windows.Forms.Label();
         this.lblTableNumber = new System.Windows.Forms.Label();
         this.txtTableNumber = new System.Windows.Forms.TextBox();
         this.txtWaiterName = new System.Windows.Forms.TextBox();
         this.lblFoodHouse = new System.Windows.Forms.Label();
         this.fraMenuItems = new System.Windows.Forms.GroupBox();
         this.cboDessert = new System.Windows.Forms.ComboBox();
         this.lblDessert = new System.Windows.Forms.Label();
         this.cboMainCourse = new System.Windows.Forms.ComboBox();
         this.lblMainCourse = new System.Windows.Forms.Label();
         this.cboAppetizer = new System.Windows.Forms.ComboBox();
         this.lblAppetizer = new System.Windows.Forms.Label();
         this.cboBeverage = new System.Windows.Forms.ComboBox();
         this.lblBeverage = new System.Windows.Forms.Label();
         this.btnCalculateBill = new System.Windows.Forms.Button();
         this.lblSubtotal = new System.Windows.Forms.Label();
         this.lblSubtotalResult = new System.Windows.Forms.Label();
         this.lblTax = new System.Windows.Forms.Label();
         this.lblTaxResult = new System.Windows.Forms.Label();
         this.lblTotal = new System.Windows.Forms.Label();
         this.lblTotalResult = new System.Windows.Forms.Label();
         this.fraWaiterInformation.SuspendLayout();
         this.fraMenuItems.SuspendLayout();
         this.SuspendLayout();
         // 
         // fraWaiterInformation
         // 
         this.fraWaiterInformation.Controls.Add(this.lblWaiterName);
         this.fraWaiterInformation.Controls.Add(this.lblTableNumber);
         this.fraWaiterInformation.Controls.Add(this.txtTableNumber);
         this.fraWaiterInformation.Controls.Add(this.txtWaiterName);
         this.fraWaiterInformation.Location = new System.Drawing.Point(16, 48);
         this.fraWaiterInformation.Name = "fraWaiterInformation";
         this.fraWaiterInformation.Size = new System.Drawing.Size(232, 88);
         this.fraWaiterInformation.TabIndex = 20;
         this.fraWaiterInformation.TabStop = false;
         this.fraWaiterInformation.Text = "Waiter Information";
         // 
         // lblWaiterName
         // 
         this.lblWaiterName.Location = new System.Drawing.Point(40, 56);
         this.lblWaiterName.Name = "lblWaiterName";
         this.lblWaiterName.Size = new System.Drawing.Size(80, 16);
         this.lblWaiterName.TabIndex = 1;
         this.lblWaiterName.Text = "Waiter name:";
         this.lblWaiterName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTableNumber
         // 
         this.lblTableNumber.Location = new System.Drawing.Point(40, 24);
         this.lblTableNumber.Name = "lblTableNumber";
         this.lblTableNumber.Size = new System.Drawing.Size(80, 16);
         this.lblTableNumber.TabIndex = 3;
         this.lblTableNumber.Text = "Table number:";
         this.lblTableNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtTableNumber
         // 
         this.txtTableNumber.Location = new System.Drawing.Point(184, 24);
         this.txtTableNumber.Name = "txtTableNumber";
         this.txtTableNumber.Size = new System.Drawing.Size(32, 21);
         this.txtTableNumber.TabIndex = 4;
         this.txtTableNumber.Text = "";
         this.txtTableNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtWaiterName
         // 
         this.txtWaiterName.Location = new System.Drawing.Point(128, 56);
         this.txtWaiterName.Name = "txtWaiterName";
         this.txtWaiterName.Size = new System.Drawing.Size(88, 21);
         this.txtWaiterName.TabIndex = 2;
         this.txtWaiterName.Text = "";
         this.txtWaiterName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // lblFoodHouse
         // 
         this.lblFoodHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblFoodHouse.Location = new System.Drawing.Point(72, 8);
         this.lblFoodHouse.Name = "lblFoodHouse";
         this.lblFoodHouse.Size = new System.Drawing.Size(128, 24);
         this.lblFoodHouse.TabIndex = 5;
         this.lblFoodHouse.Text = "Restaurant";
         this.lblFoodHouse.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // fraMenuItems
         // 
         this.fraMenuItems.Controls.Add(this.cboDessert);
         this.fraMenuItems.Controls.Add(this.lblDessert);
         this.fraMenuItems.Controls.Add(this.cboMainCourse);
         this.fraMenuItems.Controls.Add(this.lblMainCourse);
         this.fraMenuItems.Controls.Add(this.cboAppetizer);
         this.fraMenuItems.Controls.Add(this.lblAppetizer);
         this.fraMenuItems.Controls.Add(this.cboBeverage);
         this.fraMenuItems.Controls.Add(this.lblBeverage);
         this.fraMenuItems.Location = new System.Drawing.Point(20, 154);
         this.fraMenuItems.Name = "fraMenuItems";
         this.fraMenuItems.Size = new System.Drawing.Size(232, 152);
         this.fraMenuItems.TabIndex = 21;
         this.fraMenuItems.TabStop = false;
         this.fraMenuItems.Text = "Menu Items";
         // 
         // cboDessert
         // 
         this.cboDessert.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboDessert.Location = new System.Drawing.Point(88, 120);
         this.cboDessert.Name = "cboDessert";
         this.cboDessert.Size = new System.Drawing.Size(128, 21);
         this.cboDessert.TabIndex = 10;
         // 
         // lblDessert
         // 
         this.lblDessert.Location = new System.Drawing.Point(8, 120);
         this.lblDessert.Name = "lblDessert";
         this.lblDessert.Size = new System.Drawing.Size(72, 24);
         this.lblDessert.TabIndex = 11;
         this.lblDessert.Text = "Dessert:";
         this.lblDessert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // cboMainCourse
         // 
         this.cboMainCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboMainCourse.Location = new System.Drawing.Point(88, 88);
         this.cboMainCourse.Name = "cboMainCourse";
         this.cboMainCourse.Size = new System.Drawing.Size(128, 21);
         this.cboMainCourse.TabIndex = 8;
         // 
         // lblMainCourse
         // 
         this.lblMainCourse.Location = new System.Drawing.Point(8, 88);
         this.lblMainCourse.Name = "lblMainCourse";
         this.lblMainCourse.Size = new System.Drawing.Size(72, 24);
         this.lblMainCourse.TabIndex = 9;
         this.lblMainCourse.Text = "Main course:";
         this.lblMainCourse.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // cboAppetizer
         // 
         this.cboAppetizer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboAppetizer.Location = new System.Drawing.Point(88, 56);
         this.cboAppetizer.Name = "cboAppetizer";
         this.cboAppetizer.Size = new System.Drawing.Size(128, 21);
         this.cboAppetizer.TabIndex = 6;
         // 
         // lblAppetizer
         // 
         this.lblAppetizer.Location = new System.Drawing.Point(8, 56);
         this.lblAppetizer.Name = "lblAppetizer";
         this.lblAppetizer.Size = new System.Drawing.Size(72, 24);
         this.lblAppetizer.TabIndex = 7;
         this.lblAppetizer.Text = "Appetizer:";
         this.lblAppetizer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // cboBeverage
         // 
         this.cboBeverage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboBeverage.Location = new System.Drawing.Point(88, 24);
         this.cboBeverage.Name = "cboBeverage";
         this.cboBeverage.Size = new System.Drawing.Size(128, 21);
         this.cboBeverage.TabIndex = 0;
         // 
         // lblBeverage
         // 
         this.lblBeverage.Location = new System.Drawing.Point(8, 24);
         this.lblBeverage.Name = "lblBeverage";
         this.lblBeverage.Size = new System.Drawing.Size(72, 24);
         this.lblBeverage.TabIndex = 5;
         this.lblBeverage.Text = "Beverage:";
         this.lblBeverage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // btnCalculateBill
         // 
         this.btnCalculateBill.Location = new System.Drawing.Point(88, 320);
         this.btnCalculateBill.Name = "btnCalculateBill";
         this.btnCalculateBill.Size = new System.Drawing.Size(80, 24);
         this.btnCalculateBill.TabIndex = 22;
         this.btnCalculateBill.Text = "&Calculate Bill";
         // 
         // lblSubtotal
         // 
         this.lblSubtotal.Location = new System.Drawing.Point(24, 360);
         this.lblSubtotal.Name = "lblSubtotal";
         this.lblSubtotal.Size = new System.Drawing.Size(56, 16);
         this.lblSubtotal.TabIndex = 23;
         this.lblSubtotal.Text = "Subtotal:";
         this.lblSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblSubtotalResult
         // 
         this.lblSubtotalResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblSubtotalResult.Location = new System.Drawing.Point(88, 360);
         this.lblSubtotalResult.Name = "lblSubtotalResult";
         this.lblSubtotalResult.Size = new System.Drawing.Size(80, 16);
         this.lblSubtotalResult.TabIndex = 24;
         this.lblSubtotalResult.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lblTax
         // 
         this.lblTax.Location = new System.Drawing.Point(24, 392);
         this.lblTax.Name = "lblTax";
         this.lblTax.Size = new System.Drawing.Size(56, 16);
         this.lblTax.TabIndex = 25;
         this.lblTax.Text = "Tax:";
         this.lblTax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTaxResult
         // 
         this.lblTaxResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTaxResult.Location = new System.Drawing.Point(88, 392);
         this.lblTaxResult.Name = "lblTaxResult";
         this.lblTaxResult.Size = new System.Drawing.Size(80, 16);
         this.lblTaxResult.TabIndex = 26;
         this.lblTaxResult.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // lblTotal
         // 
         this.lblTotal.Location = new System.Drawing.Point(24, 424);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(56, 16);
         this.lblTotal.TabIndex = 27;
         this.lblTotal.Text = "Total:";
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotalResult
         // 
         this.lblTotalResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalResult.Location = new System.Drawing.Point(88, 424);
         this.lblTotalResult.Name = "lblTotalResult";
         this.lblTotalResult.Size = new System.Drawing.Size(80, 16);
         this.lblTotalResult.TabIndex = 28;
         this.lblTotalResult.TextAlign = System.Drawing.ContentAlignment.TopRight;
         // 
         // FrmRestaurantBillCalculator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(272, 461);
         this.Controls.Add(this.lblTotalResult);
         this.Controls.Add(this.lblTotal);
         this.Controls.Add(this.lblTaxResult);
         this.Controls.Add(this.lblTax);
         this.Controls.Add(this.lblSubtotalResult);
         this.Controls.Add(this.lblSubtotal);
         this.Controls.Add(this.btnCalculateBill);
         this.Controls.Add(this.fraMenuItems);
         this.Controls.Add(this.fraWaiterInformation);
         this.Controls.Add(this.lblFoodHouse);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmRestaurantBillCalculator";
         this.Text = "Restaurant Bill Calculator";
         this.fraWaiterInformation.ResumeLayout(false);
         this.fraMenuItems.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmRestaurantBillCalculator() );
      }

   } // end class FrmRestaurantBillCalculator
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/