using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace StockPortfolio
{
   /// <summary>
   /// Summary description for FrmStockPortfolio.
   /// </summary>
   public class FrmStockPortfolio : System.Windows.Forms.Form
   {
      // Label to display directions to the user
      private System.Windows.Forms.Label lblPrompt;

      // ComboBox to choose a stock name
      private System.Windows.Forms.ComboBox cboStockNames;

      // Button to retrieve stock information
      private System.Windows.Forms.Button btnStockInformation;

      // GroupBox containing stock information, including name,
      // symbol, number of shares, price per share, and total value
      private System.Windows.Forms.GroupBox stockInfoGroupBox;
      private System.Windows.Forms.Label lblName;
      private System.Windows.Forms.Label lblNameOutput;
      private System.Windows.Forms.Label lblSymbol;
      private System.Windows.Forms.Label lblSymbolOutput;
      private System.Windows.Forms.Label lblShareNumber;
      private System.Windows.Forms.Label lblShareNumberOutput;
      private System.Windows.Forms.Label lblSharePrice;
      private System.Windows.Forms.Label lblSharePriceOutput;
      private System.Windows.Forms.Label lblTotal;
      private System.Windows.Forms.Label lblTotalOutput;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmStockPortfolio()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblPrompt = new System.Windows.Forms.Label();
         this.cboStockNames = new System.Windows.Forms.ComboBox();
         this.btnStockInformation = new System.Windows.Forms.Button();
         this.stockInfoGroupBox = new System.Windows.Forms.GroupBox();
         this.lblSymbolOutput = new System.Windows.Forms.Label();
         this.lblTotalOutput = new System.Windows.Forms.Label();
         this.lblSharePriceOutput = new System.Windows.Forms.Label();
         this.lblShareNumberOutput = new System.Windows.Forms.Label();
         this.lblNameOutput = new System.Windows.Forms.Label();
         this.lblSymbol = new System.Windows.Forms.Label();
         this.lblTotal = new System.Windows.Forms.Label();
         this.lblSharePrice = new System.Windows.Forms.Label();
         this.lblShareNumber = new System.Windows.Forms.Label();
         this.lblName = new System.Windows.Forms.Label();
         this.stockInfoGroupBox.SuspendLayout();
         this.SuspendLayout();
         // 
         // lblPrompt
         // 
         this.lblPrompt.Location = new System.Drawing.Point(8, 16);
         this.lblPrompt.Name = "lblPrompt";
         this.lblPrompt.Size = new System.Drawing.Size(264, 32);
         this.lblPrompt.TabIndex = 2;
         this.lblPrompt.Text = "Select the name of the stock for which you want information, and then press the S" +
            "tock Info button.";
         // 
         // cboStockNames
         // 
         this.cboStockNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cboStockNames.Location = new System.Drawing.Point(56, 56);
         this.cboStockNames.Name = "cboStockNames";
         this.cboStockNames.Size = new System.Drawing.Size(168, 21);
         this.cboStockNames.TabIndex = 3;
         // 
         // btnStockInformation
         // 
         this.btnStockInformation.Location = new System.Drawing.Point(88, 88);
         this.btnStockInformation.Name = "btnStockInformation";
         this.btnStockInformation.Size = new System.Drawing.Size(105, 23);
         this.btnStockInformation.TabIndex = 4;
         this.btnStockInformation.Text = "&Stock Information";
         // 
         // stockInfoGroupBox
         // 
         this.stockInfoGroupBox.Controls.Add(this.lblSymbolOutput);
         this.stockInfoGroupBox.Controls.Add(this.lblTotalOutput);
         this.stockInfoGroupBox.Controls.Add(this.lblSharePriceOutput);
         this.stockInfoGroupBox.Controls.Add(this.lblShareNumberOutput);
         this.stockInfoGroupBox.Controls.Add(this.lblNameOutput);
         this.stockInfoGroupBox.Controls.Add(this.lblSymbol);
         this.stockInfoGroupBox.Controls.Add(this.lblTotal);
         this.stockInfoGroupBox.Controls.Add(this.lblSharePrice);
         this.stockInfoGroupBox.Controls.Add(this.lblShareNumber);
         this.stockInfoGroupBox.Controls.Add(this.lblName);
         this.stockInfoGroupBox.Location = new System.Drawing.Point(16, 128);
         this.stockInfoGroupBox.Name = "stockInfoGroupBox";
         this.stockInfoGroupBox.Size = new System.Drawing.Size(244, 192);
         this.stockInfoGroupBox.TabIndex = 5;
         this.stockInfoGroupBox.TabStop = false;
         this.stockInfoGroupBox.Text = "Stock Info";
         // 
         // lblSymbolOutput
         // 
         this.lblSymbolOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblSymbolOutput.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblSymbolOutput.Location = new System.Drawing.Point(112, 56);
         this.lblSymbolOutput.Name = "lblSymbolOutput";
         this.lblSymbolOutput.Size = new System.Drawing.Size(120, 24);
         this.lblSymbolOutput.TabIndex = 9;
         this.lblSymbolOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblTotalOutput
         // 
         this.lblTotalOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblTotalOutput.Location = new System.Drawing.Point(112, 152);
         this.lblTotalOutput.Name = "lblTotalOutput";
         this.lblTotalOutput.Size = new System.Drawing.Size(120, 24);
         this.lblTotalOutput.TabIndex = 8;
         this.lblTotalOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSharePriceOutput
         // 
         this.lblSharePriceOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblSharePriceOutput.Location = new System.Drawing.Point(112, 120);
         this.lblSharePriceOutput.Name = "lblSharePriceOutput";
         this.lblSharePriceOutput.Size = new System.Drawing.Size(120, 24);
         this.lblSharePriceOutput.TabIndex = 7;
         this.lblSharePriceOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblShareNumberOutput
         // 
         this.lblShareNumberOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblShareNumberOutput.Location = new System.Drawing.Point(112, 88);
         this.lblShareNumberOutput.Name = "lblShareNumberOutput";
         this.lblShareNumberOutput.Size = new System.Drawing.Size(120, 24);
         this.lblShareNumberOutput.TabIndex = 6;
         this.lblShareNumberOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblNameOutput
         // 
         this.lblNameOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblNameOutput.Location = new System.Drawing.Point(112, 24);
         this.lblNameOutput.Name = "lblNameOutput";
         this.lblNameOutput.Size = new System.Drawing.Size(120, 24);
         this.lblNameOutput.TabIndex = 5;
         this.lblNameOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSymbol
         // 
         this.lblSymbol.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblSymbol.Location = new System.Drawing.Point(8, 56);
         this.lblSymbol.Name = "lblSymbol";
         this.lblSymbol.Size = new System.Drawing.Size(104, 23);
         this.lblSymbol.TabIndex = 4;
         this.lblSymbol.Text = "Stock symbol:";
         this.lblSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblTotal
         // 
         this.lblTotal.Location = new System.Drawing.Point(8, 152);
         this.lblTotal.Name = "lblTotal";
         this.lblTotal.Size = new System.Drawing.Size(104, 23);
         this.lblTotal.TabIndex = 3;
         this.lblTotal.Text = "Total value:";
         this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblSharePrice
         // 
         this.lblSharePrice.Location = new System.Drawing.Point(8, 120);
         this.lblSharePrice.Name = "lblSharePrice";
         this.lblSharePrice.Size = new System.Drawing.Size(104, 23);
         this.lblSharePrice.TabIndex = 2;
         this.lblSharePrice.Text = "Price per share:";
         this.lblSharePrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblShareNumber
         // 
         this.lblShareNumber.Location = new System.Drawing.Point(8, 88);
         this.lblShareNumber.Name = "lblShareNumber";
         this.lblShareNumber.Size = new System.Drawing.Size(104, 23);
         this.lblShareNumber.TabIndex = 1;
         this.lblShareNumber.Text = "Number of shares:";
         this.lblShareNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblName
         // 
         this.lblName.Location = new System.Drawing.Point(8, 24);
         this.lblName.Name = "lblName";
         this.lblName.Size = new System.Drawing.Size(104, 23);
         this.lblName.TabIndex = 0;
         this.lblName.Text = "Stock name:";
         this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // FrmStockPortfolio
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(280, 341);
         this.Controls.Add(this.stockInfoGroupBox);
         this.Controls.Add(this.btnStockInformation);
         this.Controls.Add(this.cboStockNames);
         this.Controls.Add(this.lblPrompt);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmStockPortfolio";
         this.Text = "Stock Portfolio";
         this.stockInfoGroupBox.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmStockPortfolio() );
      }

      // helper method to compute total value of stock
      // and return it as a string
      private string ComputeTotalValueString( 
         string strShareNumber, string strSharePrice )
      {
         int intShareNumber = Int32.Parse( strShareNumber );
         decimal decSharePrice = Decimal.Parse( strSharePrice );

         // return the total value formatted as a currency
         return String.Format( "{0:C}",
            ( intShareNumber * decSharePrice ) );

      }

   } // end class FrmStockPortfolio
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/