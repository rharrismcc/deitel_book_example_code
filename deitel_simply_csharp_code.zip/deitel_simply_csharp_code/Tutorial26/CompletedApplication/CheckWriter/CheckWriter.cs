using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Printing;

namespace CheckWriter
{
   /// <summary>
   /// Summary description for FrmCheckWriter.
   /// </summary>
   public class FrmCheckWriter : System.Windows.Forms.Form
   {
      // Label to display payer information
      private System.Windows.Forms.TextBox txtPayer;

      // Label and TextBox to display number of check
      private System.Windows.Forms.Label lblNumber;
      private System.Windows.Forms.TextBox txtNumber;

      // Label and DateTimePicker to display date of check
      private System.Windows.Forms.Label lblDate;
      private System.Windows.Forms.DateTimePicker dtpDate;

      // Label and TextBox to display check amount
      private System.Windows.Forms.Label lblAmount;
      private System.Windows.Forms.TextBox txtAmount;

      // Label and TextBox to display recipient
      private System.Windows.Forms.Label lblPayee;
      private System.Windows.Forms.TextBox txtPayee;

      // TextBox and Label to display written check amount
      private System.Windows.Forms.TextBox txtPayment;
      private System.Windows.Forms.Label lblDollars;

      // Label and TextBox to display memo text
      private System.Windows.Forms.Label lblMemo;
      private System.Windows.Forms.TextBox txtMemo;

      // Labels to display MICR numbers
      private System.Windows.Forms.Label lblABA;
      private System.Windows.Forms.Label lblAccount;

      // Labels to display signature
      private System.Windows.Forms.Label lblSigned;
      private System.Windows.Forms.Label lblUnderline;

      // Button to preview the check
      private System.Windows.Forms.Button btnPreview;

      // Button to print the check
      private System.Windows.Forms.Button btnPrint;

      // PrintPreviewDialog to print and preview the check
      private System.Windows.Forms.PrintPreviewDialog objPreview;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      private Font m_objFont; // instance variable to store font

      public FrmCheckWriter()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FrmCheckWriter));
         this.txtPayer = new System.Windows.Forms.TextBox();
         this.lblNumber = new System.Windows.Forms.Label();
         this.txtNumber = new System.Windows.Forms.TextBox();
         this.lblDate = new System.Windows.Forms.Label();
         this.dtpDate = new System.Windows.Forms.DateTimePicker();
         this.lblAmount = new System.Windows.Forms.Label();
         this.txtAmount = new System.Windows.Forms.TextBox();
         this.lblPayee = new System.Windows.Forms.Label();
         this.txtPayee = new System.Windows.Forms.TextBox();
         this.txtPayment = new System.Windows.Forms.TextBox();
         this.lblDollars = new System.Windows.Forms.Label();
         this.lblMemo = new System.Windows.Forms.Label();
         this.txtMemo = new System.Windows.Forms.TextBox();
         this.lblABA = new System.Windows.Forms.Label();
         this.lblAccount = new System.Windows.Forms.Label();
         this.lblSigned = new System.Windows.Forms.Label();
         this.lblUnderline = new System.Windows.Forms.Label();
         this.btnPreview = new System.Windows.Forms.Button();
         this.btnPrint = new System.Windows.Forms.Button();
         this.objPreview = new System.Windows.Forms.PrintPreviewDialog();
         this.SuspendLayout();
         // 
         // txtPayer
         // 
         this.txtPayer.Location = new System.Drawing.Point(16, 8);
         this.txtPayer.Multiline = true;
         this.txtPayer.Name = "txtPayer";
         this.txtPayer.Size = new System.Drawing.Size(120, 56);
         this.txtPayer.TabIndex = 0;
         this.txtPayer.Text = "";
         // 
         // lblNumber
         // 
         this.lblNumber.Location = new System.Drawing.Point(416, 10);
         this.lblNumber.Name = "lblNumber";
         this.lblNumber.Size = new System.Drawing.Size(24, 16);
         this.lblNumber.TabIndex = 1;
         this.lblNumber.Text = "No.";
         // 
         // txtNumber
         // 
         this.txtNumber.Location = new System.Drawing.Point(448, 8);
         this.txtNumber.Name = "txtNumber";
         this.txtNumber.Size = new System.Drawing.Size(24, 21);
         this.txtNumber.TabIndex = 2;
         this.txtNumber.Text = "";
         // 
         // lblDate
         // 
         this.lblDate.Location = new System.Drawing.Point(272, 32);
         this.lblDate.Name = "lblDate";
         this.lblDate.Size = new System.Drawing.Size(32, 16);
         this.lblDate.TabIndex = 3;
         this.lblDate.Text = "Date";
         // 
         // dtpDate
         // 
         this.dtpDate.CustomFormat = "MMMM d, yyyy";
         this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
         this.dtpDate.Location = new System.Drawing.Point(320, 32);
         this.dtpDate.Name = "dtpDate";
         this.dtpDate.Size = new System.Drawing.Size(120, 21);
         this.dtpDate.TabIndex = 4;
         // 
         // lblAmount
         // 
         this.lblAmount.Location = new System.Drawing.Point(248, 56);
         this.lblAmount.Name = "lblAmount";
         this.lblAmount.Size = new System.Drawing.Size(64, 16);
         this.lblAmount.TabIndex = 5;
         this.lblAmount.Text = "Amount    $";
         // 
         // txtAmount
         // 
         this.txtAmount.Location = new System.Drawing.Point(320, 56);
         this.txtAmount.Name = "txtAmount";
         this.txtAmount.Size = new System.Drawing.Size(80, 21);
         this.txtAmount.TabIndex = 6;
         this.txtAmount.Text = "";
         // 
         // lblPayee
         // 
         this.lblPayee.Location = new System.Drawing.Point(34, 96);
         this.lblPayee.Name = "lblPayee";
         this.lblPayee.Size = new System.Drawing.Size(104, 16);
         this.lblPayee.TabIndex = 7;
         this.lblPayee.Text = "Pay to the Order Of";
         // 
         // txtPayee
         // 
         this.txtPayee.Location = new System.Drawing.Point(144, 95);
         this.txtPayee.Name = "txtPayee";
         this.txtPayee.Size = new System.Drawing.Size(288, 21);
         this.txtPayee.TabIndex = 8;
         this.txtPayee.Text = "";
         // 
         // txtPayment
         // 
         this.txtPayment.Location = new System.Drawing.Point(24, 143);
         this.txtPayment.Name = "txtPayment";
         this.txtPayment.Size = new System.Drawing.Size(368, 21);
         this.txtPayment.TabIndex = 9;
         this.txtPayment.Text = "";
         // 
         // lblDollars
         // 
         this.lblDollars.Location = new System.Drawing.Point(398, 144);
         this.lblDollars.Name = "lblDollars";
         this.lblDollars.Size = new System.Drawing.Size(40, 16);
         this.lblDollars.TabIndex = 10;
         this.lblDollars.Text = "Dollars";
         // 
         // lblMemo
         // 
         this.lblMemo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblMemo.Location = new System.Drawing.Point(8, 192);
         this.lblMemo.Name = "lblMemo";
         this.lblMemo.Size = new System.Drawing.Size(48, 16);
         this.lblMemo.TabIndex = 11;
         this.lblMemo.Text = "Memo";
         // 
         // txtMemo
         // 
         this.txtMemo.Location = new System.Drawing.Point(56, 190);
         this.txtMemo.Name = "txtMemo";
         this.txtMemo.Size = new System.Drawing.Size(144, 21);
         this.txtMemo.TabIndex = 12;
         this.txtMemo.Text = "";
         // 
         // lblABA
         // 
         this.lblABA.Location = new System.Drawing.Point(16, 216);
         this.lblABA.Name = "lblABA";
         this.lblABA.TabIndex = 13;
         this.lblABA.Text = "000000000";
         // 
         // lblAccount
         // 
         this.lblAccount.Location = new System.Drawing.Point(128, 216);
         this.lblAccount.Name = "lblAccount";
         this.lblAccount.Size = new System.Drawing.Size(80, 23);
         this.lblAccount.TabIndex = 14;
         this.lblAccount.Text = "123456789";
         // 
         // lblSigned
         // 
         this.lblSigned.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblSigned.Location = new System.Drawing.Point(248, 192);
         this.lblSigned.Name = "lblSigned";
         this.lblSigned.Size = new System.Drawing.Size(48, 16);
         this.lblSigned.TabIndex = 15;
         this.lblSigned.Text = "Signed";
         // 
         // lblUnderline
         // 
         this.lblUnderline.Location = new System.Drawing.Point(296, 193);
         this.lblUnderline.Name = "lblUnderline";
         this.lblUnderline.Size = new System.Drawing.Size(160, 8);
         this.lblUnderline.TabIndex = 16;
         this.lblUnderline.Text = "________________________";
         this.lblUnderline.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
         // 
         // btnPreview
         // 
         this.btnPreview.Location = new System.Drawing.Point(312, 248);
         this.btnPreview.Name = "btnPreview";
         this.btnPreview.TabIndex = 17;
         this.btnPreview.Text = "Preview";
         this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
         // 
         // btnPrint
         // 
         this.btnPrint.Location = new System.Drawing.Point(392, 248);
         this.btnPrint.Name = "btnPrint";
         this.btnPrint.TabIndex = 18;
         this.btnPrint.Text = "Print";
         this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
         // 
         // objPreview
         // 
         this.objPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
         this.objPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
         this.objPreview.ClientSize = new System.Drawing.Size(400, 300);
         this.objPreview.Enabled = true;
         this.objPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("objPreview.Icon")));
         this.objPreview.Location = new System.Drawing.Point(58, 16);
         this.objPreview.MinimumSize = new System.Drawing.Size(375, 250);
         this.objPreview.Name = "objPreview";
         this.objPreview.TransparencyKey = System.Drawing.Color.Empty;
         this.objPreview.Visible = false;
         // 
         // FrmCheckWriter
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(480, 277);
         this.Controls.Add(this.btnPrint);
         this.Controls.Add(this.btnPreview);
         this.Controls.Add(this.lblUnderline);
         this.Controls.Add(this.lblSigned);
         this.Controls.Add(this.lblAccount);
         this.Controls.Add(this.lblABA);
         this.Controls.Add(this.txtMemo);
         this.Controls.Add(this.lblMemo);
         this.Controls.Add(this.lblDollars);
         this.Controls.Add(this.txtPayment);
         this.Controls.Add(this.txtPayee);
         this.Controls.Add(this.lblPayee);
         this.Controls.Add(this.txtAmount);
         this.Controls.Add(this.lblAmount);
         this.Controls.Add(this.dtpDate);
         this.Controls.Add(this.lblDate);
         this.Controls.Add(this.txtNumber);
         this.Controls.Add(this.lblNumber);
         this.Controls.Add(this.txtPayer);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCheckWriter";
         this.Text = "Check Writer";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCheckWriter() );
      }

      // PrintPage event raised for each page to be printed
      private void objPrintDocument_PrintPage(
         object sender, PrintPageEventArgs e )
      {
         float fltYPosition;
         float fltXPosition;

         // represent left margin of page
         float fltLeftMargin = e.MarginBounds.Left;

         // represent top margin of page
         float fltTopMargin = e.MarginBounds.Top;
         string strLine = "";

         // iterate over the form, printing each control
         foreach ( Control objControl in this.Controls )
         {
            // we do not want to print buttons
            if ( objControl.GetType().Name != "Button" )
            {
               strLine = objControl.Text;

               switch ( objControl.Name )
               {
                  // underline the date
                  case "dtpDate":
                     m_objFont = new Font( "Tahoma", ( float ) 8.25,
                        FontStyle.Underline );
                     break;

                  // draw a box around amount
                  case "txtAmount":
                     e.Graphics.DrawRectangle( Pens.Black,
                        txtAmount.Location.X + fltLeftMargin,
                        txtAmount.Location.Y + fltTopMargin - 4,
                        txtAmount.Width, txtAmount.Height );

                     m_objFont = objControl.Font; // default font
                     break;

                  default:
                     m_objFont = objControl.Font; // default font
                     break;

               } // end switch

               // set string positions relative to page margins
               fltXPosition = fltLeftMargin + objControl.Location.X;
               fltYPosition = fltTopMargin + objControl.Location.Y;

               // draw text in graphics object
               e.Graphics.DrawString( strLine, m_objFont,
                  Brushes.Black, fltXPosition, fltYPosition );

            } // end if

         } // end foreach

         // draw box around check
         e.Graphics.DrawRectangle( Pens.Black, fltLeftMargin,
            fltTopMargin, this.Width, this.Height - 60 );

         // indicate that there are no more pages to print
         e.HasMorePages = false;

      } // end method objPrintDocument_PrintPage

      // print document
      private void btnPrint_Click(
         object sender, System.EventArgs e )
      {
         // create new object to assist in printing
         PrintDocument objPrintDocument = new PrintDocument();

         // add PrintPage event handler
         objPrintDocument.PrintPage += new PrintPageEventHandler(
            objPrintDocument_PrintPage );

         // if no printers installed, display error message
         if ( PrinterSettings.InstalledPrinters.Count == 0 )
         {
            ErrorMessage();
            return; // exit event handler
         }

         // print the document
         objPrintDocument.Print();

      } // end method btnPrint_Click

      // display document in print preview dialog
      private void btnPreview_Click(
         object sender, System.EventArgs e )
      {
         // create new object to assist in previewing
         PrintDocument objPrintDocument = new PrintDocument();

         // add PrintPage event handler
         objPrintDocument.PrintPage += new PrintPageEventHandler(
            objPrintDocument_PrintPage );

         // if no printers installed, display error message
         if ( PrinterSettings.InstalledPrinters.Count == 0 )
         {
            ErrorMessage();
            return; // exit event handler
         }

         objPreview.Document = objPrintDocument; // specify document
         objPreview.ShowDialog(); // show print preview

      } // end method btnPreview_Click

      // display an error message to the user
      void ErrorMessage()
      {
         MessageBox.Show( "No printers installed. You must " +
            "have a printer installed to preview or print " +
            "the document.", "Print Error",
            MessageBoxButtons.OK, MessageBoxIcon.Error );

      } // end method ErrorMessage

   } // end class FrmCheckWriter
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
