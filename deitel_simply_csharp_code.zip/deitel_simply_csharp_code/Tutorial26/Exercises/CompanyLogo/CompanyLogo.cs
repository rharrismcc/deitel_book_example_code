using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CompanyLogo
{
   /// <summary>
   /// Summary description for FrmCompanyLogo.
   /// </summary>
   public class FrmCompanyLogo : System.Windows.Forms.Form
   {
      // PictureBox to display the company logo
      private System.Windows.Forms.PictureBox picImage;

      // GroupBox to add shapes to the logo
      private System.Windows.Forms.GroupBox fraShape;

      // RadioButtons to choose a shape to create
      private System.Windows.Forms.RadioButton radRectangle;
      private System.Windows.Forms.RadioButton radFilledRectangle;
      private System.Windows.Forms.RadioButton radEllipse;
      private System.Windows.Forms.RadioButton radFilledEllipse;
      private System.Windows.Forms.RadioButton radLine;

      // Labels and TextBoxes to input two points to connect
      // to create a line segment
      private System.Windows.Forms.Label lblX1;
      private System.Windows.Forms.TextBox txtX1;
      private System.Windows.Forms.Label lblY1;
      private System.Windows.Forms.TextBox txtY1;
      private System.Windows.Forms.Label lblX2;
      private System.Windows.Forms.TextBox txtX2;
      private System.Windows.Forms.Label lblY2;
      private System.Windows.Forms.TextBox txtY2;

      // GroupBox containing Labels and TextBoxes to choose
      // the dimensions of a shape
      private System.Windows.Forms.GroupBox fraSettings;
      private System.Windows.Forms.Label lblX;
      private System.Windows.Forms.TextBox txtXPosition;
      private System.Windows.Forms.Label lblY;
      private System.Windows.Forms.TextBox txtYPosition;
      private System.Windows.Forms.Label lblWidth;
      private System.Windows.Forms.TextBox txtWidth;
      private System.Windows.Forms.Label lblHeight;
      private System.Windows.Forms.TextBox txtHeight;

      // GroupBox containing a ComboBox to choose the color
      // of the shape
      private System.Windows.Forms.GroupBox fraColor;
      private System.Windows.Forms.ComboBox cboColor;

      // Button to add a shape to the logo
      private System.Windows.Forms.Button btnAdd;

      // Button to clear the company logo
      private System.Windows.Forms.Button btnClear;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmCompanyLogo()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.picImage = new System.Windows.Forms.PictureBox();
         this.fraShape = new System.Windows.Forms.GroupBox();
         this.lblY2 = new System.Windows.Forms.Label();
         this.txtY2 = new System.Windows.Forms.TextBox();
         this.lblX2 = new System.Windows.Forms.Label();
         this.txtX2 = new System.Windows.Forms.TextBox();
         this.lblY1 = new System.Windows.Forms.Label();
         this.txtY1 = new System.Windows.Forms.TextBox();
         this.radFilledRectangle = new System.Windows.Forms.RadioButton();
         this.radLine = new System.Windows.Forms.RadioButton();
         this.radEllipse = new System.Windows.Forms.RadioButton();
         this.radRectangle = new System.Windows.Forms.RadioButton();
         this.radFilledEllipse = new System.Windows.Forms.RadioButton();
         this.lblX1 = new System.Windows.Forms.Label();
         this.txtX1 = new System.Windows.Forms.TextBox();
         this.fraSettings = new System.Windows.Forms.GroupBox();
         this.txtYPosition = new System.Windows.Forms.TextBox();
         this.lblY = new System.Windows.Forms.Label();
         this.txtXPosition = new System.Windows.Forms.TextBox();
         this.lblX = new System.Windows.Forms.Label();
         this.txtWidth = new System.Windows.Forms.TextBox();
         this.lblWidth = new System.Windows.Forms.Label();
         this.lblHeight = new System.Windows.Forms.Label();
         this.txtHeight = new System.Windows.Forms.TextBox();
         this.fraColor = new System.Windows.Forms.GroupBox();
         this.cboColor = new System.Windows.Forms.ComboBox();
         this.btnAdd = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.fraShape.SuspendLayout();
         this.fraSettings.SuspendLayout();
         this.fraColor.SuspendLayout();
         this.SuspendLayout();
         // 
         // picImage
         // 
         this.picImage.BackColor = System.Drawing.Color.White;
         this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.picImage.Location = new System.Drawing.Point(16, 16);
         this.picImage.Name = "picImage";
         this.picImage.Size = new System.Drawing.Size(456, 168);
         this.picImage.TabIndex = 1;
         this.picImage.TabStop = false;
         // 
         // fraShape
         // 
         this.fraShape.Controls.Add(this.lblY2);
         this.fraShape.Controls.Add(this.txtY2);
         this.fraShape.Controls.Add(this.lblX2);
         this.fraShape.Controls.Add(this.txtX2);
         this.fraShape.Controls.Add(this.lblY1);
         this.fraShape.Controls.Add(this.txtY1);
         this.fraShape.Controls.Add(this.radFilledRectangle);
         this.fraShape.Controls.Add(this.radLine);
         this.fraShape.Controls.Add(this.radEllipse);
         this.fraShape.Controls.Add(this.radRectangle);
         this.fraShape.Controls.Add(this.radFilledEllipse);
         this.fraShape.Controls.Add(this.lblX1);
         this.fraShape.Controls.Add(this.txtX1);
         this.fraShape.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.fraShape.Location = new System.Drawing.Point(8, 200);
         this.fraShape.Name = "fraShape";
         this.fraShape.Size = new System.Drawing.Size(352, 120);
         this.fraShape.TabIndex = 2;
         this.fraShape.TabStop = false;
         this.fraShape.Text = "Shape";
         // 
         // lblY2
         // 
         this.lblY2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblY2.Location = new System.Drawing.Point(280, 96);
         this.lblY2.Name = "lblY2";
         this.lblY2.Size = new System.Drawing.Size(24, 16);
         this.lblY2.TabIndex = 11;
         this.lblY2.Text = "Y2:";
         // 
         // txtY2
         // 
         this.txtY2.Location = new System.Drawing.Point(304, 96);
         this.txtY2.Name = "txtY2";
         this.txtY2.Size = new System.Drawing.Size(32, 21);
         this.txtY2.TabIndex = 10;
         this.txtY2.Text = "";
         // 
         // lblX2
         // 
         this.lblX2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblX2.Location = new System.Drawing.Point(216, 96);
         this.lblX2.Name = "lblX2";
         this.lblX2.Size = new System.Drawing.Size(24, 16);
         this.lblX2.TabIndex = 9;
         this.lblX2.Text = "X2:";
         // 
         // txtX2
         // 
         this.txtX2.Location = new System.Drawing.Point(240, 96);
         this.txtX2.Name = "txtX2";
         this.txtX2.Size = new System.Drawing.Size(32, 21);
         this.txtX2.TabIndex = 8;
         this.txtX2.Text = "";
         // 
         // lblY1
         // 
         this.lblY1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblY1.Location = new System.Drawing.Point(152, 96);
         this.lblY1.Name = "lblY1";
         this.lblY1.Size = new System.Drawing.Size(24, 16);
         this.lblY1.TabIndex = 7;
         this.lblY1.Text = "Y1:";
         // 
         // txtY1
         // 
         this.txtY1.Location = new System.Drawing.Point(176, 96);
         this.txtY1.Name = "txtY1";
         this.txtY1.Size = new System.Drawing.Size(32, 21);
         this.txtY1.TabIndex = 6;
         this.txtY1.Text = "";
         // 
         // radFilledRectangle
         // 
         this.radFilledRectangle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.radFilledRectangle.Location = new System.Drawing.Point(104, 24);
         this.radFilledRectangle.Name = "radFilledRectangle";
         this.radFilledRectangle.TabIndex = 3;
         this.radFilledRectangle.Text = "Filled Rectangle";
         // 
         // radLine
         // 
         this.radLine.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.radLine.Location = new System.Drawing.Point(16, 88);
         this.radLine.Name = "radLine";
         this.radLine.Size = new System.Drawing.Size(48, 24);
         this.radLine.TabIndex = 2;
         this.radLine.Text = "Line";
         // 
         // radEllipse
         // 
         this.radEllipse.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.radEllipse.Location = new System.Drawing.Point(16, 56);
         this.radEllipse.Name = "radEllipse";
         this.radEllipse.Size = new System.Drawing.Size(56, 24);
         this.radEllipse.TabIndex = 1;
         this.radEllipse.Text = "Ellipse";
         // 
         // radRectangle
         // 
         this.radRectangle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.radRectangle.Location = new System.Drawing.Point(16, 24);
         this.radRectangle.Name = "radRectangle";
         this.radRectangle.Size = new System.Drawing.Size(80, 24);
         this.radRectangle.TabIndex = 0;
         this.radRectangle.Text = "Rectangle";
         // 
         // radFilledEllipse
         // 
         this.radFilledEllipse.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.radFilledEllipse.Location = new System.Drawing.Point(104, 56);
         this.radFilledEllipse.Name = "radFilledEllipse";
         this.radFilledEllipse.TabIndex = 3;
         this.radFilledEllipse.Text = "Filled Ellipse";
         // 
         // lblX1
         // 
         this.lblX1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblX1.Location = new System.Drawing.Point(88, 96);
         this.lblX1.Name = "lblX1";
         this.lblX1.Size = new System.Drawing.Size(24, 16);
         this.lblX1.TabIndex = 5;
         this.lblX1.Text = "X1:";
         // 
         // txtX1
         // 
         this.txtX1.Location = new System.Drawing.Point(112, 96);
         this.txtX1.Name = "txtX1";
         this.txtX1.Size = new System.Drawing.Size(32, 21);
         this.txtX1.TabIndex = 4;
         this.txtX1.Text = "";
         // 
         // fraSettings
         // 
         this.fraSettings.Controls.Add(this.txtYPosition);
         this.fraSettings.Controls.Add(this.lblY);
         this.fraSettings.Controls.Add(this.txtXPosition);
         this.fraSettings.Controls.Add(this.lblX);
         this.fraSettings.Controls.Add(this.txtWidth);
         this.fraSettings.Controls.Add(this.lblWidth);
         this.fraSettings.Controls.Add(this.lblHeight);
         this.fraSettings.Controls.Add(this.txtHeight);
         this.fraSettings.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.fraSettings.Location = new System.Drawing.Point(8, 328);
         this.fraSettings.Name = "fraSettings";
         this.fraSettings.Size = new System.Drawing.Size(352, 64);
         this.fraSettings.TabIndex = 3;
         this.fraSettings.TabStop = false;
         this.fraSettings.Text = "Settings";
         // 
         // txtYPosition
         // 
         this.txtYPosition.Location = new System.Drawing.Point(104, 24);
         this.txtYPosition.Name = "txtYPosition";
         this.txtYPosition.Size = new System.Drawing.Size(40, 21);
         this.txtYPosition.TabIndex = 5;
         this.txtYPosition.Text = "";
         // 
         // lblY
         // 
         this.lblY.Location = new System.Drawing.Point(80, 24);
         this.lblY.Name = "lblY";
         this.lblY.Size = new System.Drawing.Size(24, 16);
         this.lblY.TabIndex = 4;
         this.lblY.Text = "Y:";
         // 
         // txtXPosition
         // 
         this.txtXPosition.Location = new System.Drawing.Point(32, 24);
         this.txtXPosition.Name = "txtXPosition";
         this.txtXPosition.Size = new System.Drawing.Size(40, 21);
         this.txtXPosition.TabIndex = 0;
         this.txtXPosition.Text = "";
         // 
         // lblX
         // 
         this.lblX.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblX.Location = new System.Drawing.Point(8, 24);
         this.lblX.Name = "lblX";
         this.lblX.Size = new System.Drawing.Size(24, 16);
         this.lblX.TabIndex = 3;
         this.lblX.Text = "X:";
         // 
         // txtWidth
         // 
         this.txtWidth.Location = new System.Drawing.Point(192, 24);
         this.txtWidth.Name = "txtWidth";
         this.txtWidth.Size = new System.Drawing.Size(40, 21);
         this.txtWidth.TabIndex = 4;
         this.txtWidth.Text = "";
         // 
         // lblWidth
         // 
         this.lblWidth.Location = new System.Drawing.Point(152, 24);
         this.lblWidth.Name = "lblWidth";
         this.lblWidth.Size = new System.Drawing.Size(40, 16);
         this.lblWidth.TabIndex = 5;
         this.lblWidth.Text = "Width:";
         // 
         // lblHeight
         // 
         this.lblHeight.Location = new System.Drawing.Point(240, 24);
         this.lblHeight.Name = "lblHeight";
         this.lblHeight.Size = new System.Drawing.Size(40, 16);
         this.lblHeight.TabIndex = 7;
         this.lblHeight.Text = "Height:";
         // 
         // txtHeight
         // 
         this.txtHeight.Location = new System.Drawing.Point(280, 24);
         this.txtHeight.Name = "txtHeight";
         this.txtHeight.Size = new System.Drawing.Size(40, 21);
         this.txtHeight.TabIndex = 6;
         this.txtHeight.Text = "";
         // 
         // fraColor
         // 
         this.fraColor.Controls.Add(this.cboColor);
         this.fraColor.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.fraColor.Location = new System.Drawing.Point(368, 200);
         this.fraColor.Name = "fraColor";
         this.fraColor.Size = new System.Drawing.Size(112, 80);
         this.fraColor.TabIndex = 4;
         this.fraColor.TabStop = false;
         this.fraColor.Text = "Color";
         // 
         // cboColor
         // 
         this.cboColor.Items.AddRange(new object[] {
                                                      "Black",
                                                      "Blue",
                                                      "Purple",
                                                      "Green",
                                                      "Red",
                                                      "Orange",
                                                      "Yellow"});
         this.cboColor.Location = new System.Drawing.Point(8, 32);
         this.cboColor.Name = "cboColor";
         this.cboColor.Size = new System.Drawing.Size(96, 21);
         this.cboColor.TabIndex = 12;
         // 
         // btnAdd
         // 
         this.btnAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnAdd.Location = new System.Drawing.Point(392, 320);
         this.btnAdd.Name = "btnAdd";
         this.btnAdd.TabIndex = 5;
         this.btnAdd.Text = "Add";
         // 
         // btnClear
         // 
         this.btnClear.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnClear.Location = new System.Drawing.Point(392, 352);
         this.btnClear.Name = "btnClear";
         this.btnClear.TabIndex = 6;
         this.btnClear.Text = "Clear";
         // 
         // FrmCompanyLogo
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(488, 397);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.btnAdd);
         this.Controls.Add(this.fraColor);
         this.Controls.Add(this.fraSettings);
         this.Controls.Add(this.fraShape);
         this.Controls.Add(this.picImage);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCompanyLogo";
         this.Text = "Company Logo";
         this.fraShape.ResumeLayout(false);
         this.fraSettings.ResumeLayout(false);
         this.fraColor.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCompanyLogo() );
      }

   } // end class FrmCompanyLogo
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/