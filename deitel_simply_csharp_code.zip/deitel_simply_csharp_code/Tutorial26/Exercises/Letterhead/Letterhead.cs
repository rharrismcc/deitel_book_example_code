using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Letterhead
{
   /// <summary>
   /// Summary description for FrmLetterHead.
   /// </summary>
   public class FrmLetterHead : System.Windows.Forms.Form
   {
      // PictureBox to display the letterhead
      private System.Windows.Forms.PictureBox picImage;

      // TextBox to input letterhead text
      private System.Windows.Forms.TextBox txtInformation;

      // Label and TextBox to input image location
      private System.Windows.Forms.Label lblImage;
      private System.Windows.Forms.TextBox txtImage;

      // Button to add the image
      private System.Windows.Forms.Button btnAdd;

      // Button to preview the letterhead
      private System.Windows.Forms.Button btnPreview;

      // Button to print the letterhead
      private System.Windows.Forms.Button btnPrint;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // create font object
      Font objFont;

      public FrmLetterHead()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.picImage = new System.Windows.Forms.PictureBox();
         this.txtInformation = new System.Windows.Forms.TextBox();
         this.lblImage = new System.Windows.Forms.Label();
         this.txtImage = new System.Windows.Forms.TextBox();
         this.btnAdd = new System.Windows.Forms.Button();
         this.btnPreview = new System.Windows.Forms.Button();
         this.btnPrint = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // picImage
         // 
         this.picImage.BackColor = System.Drawing.Color.White;
         this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.picImage.Location = new System.Drawing.Point(34, 8);
         this.picImage.Name = "picImage";
         this.picImage.Size = new System.Drawing.Size(555, 56);
         this.picImage.TabIndex = 1;
         this.picImage.TabStop = false;
         // 
         // txtInformation
         // 
         this.txtInformation.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtInformation.Location = new System.Drawing.Point(216, 72);
         this.txtInformation.Multiline = true;
         this.txtInformation.Name = "txtInformation";
         this.txtInformation.Size = new System.Drawing.Size(192, 40);
         this.txtInformation.TabIndex = 6;
         this.txtInformation.Text = "";
         // 
         // lblImage
         // 
         this.lblImage.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblImage.Location = new System.Drawing.Point(24, 216);
         this.lblImage.Name = "lblImage";
         this.lblImage.Size = new System.Drawing.Size(88, 16);
         this.lblImage.TabIndex = 7;
         this.lblImage.Text = "Image Location:";
         // 
         // txtImage
         // 
         this.txtImage.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.txtImage.Location = new System.Drawing.Point(112, 216);
         this.txtImage.Name = "txtImage";
         this.txtImage.Size = new System.Drawing.Size(320, 21);
         this.txtImage.TabIndex = 8;
         this.txtImage.Text = "";
         // 
         // btnAdd
         // 
         this.btnAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnAdd.Location = new System.Drawing.Point(24, 240);
         this.btnAdd.Name = "btnAdd";
         this.btnAdd.TabIndex = 9;
         this.btnAdd.Text = "Add";
         // 
         // btnPreview
         // 
         this.btnPreview.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnPreview.Location = new System.Drawing.Point(448, 216);
         this.btnPreview.Name = "btnPreview";
         this.btnPreview.TabIndex = 10;
         this.btnPreview.Text = "Preview";
         // 
         // btnPrint
         // 
         this.btnPrint.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnPrint.Location = new System.Drawing.Point(536, 216);
         this.btnPrint.Name = "btnPrint";
         this.btnPrint.TabIndex = 11;
         this.btnPrint.Text = "Print";
         // 
         // FrmLetterHead
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(622, 273);
         this.Controls.Add(this.btnPrint);
         this.Controls.Add(this.btnPreview);
         this.Controls.Add(this.btnAdd);
         this.Controls.Add(this.txtImage);
         this.Controls.Add(this.lblImage);
         this.Controls.Add(this.txtInformation);
         this.Controls.Add(this.picImage);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmLetterHead";
         this.Text = "Letterhead";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmLetterHead() );
      }

   } // end class FrmLetterHead
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/