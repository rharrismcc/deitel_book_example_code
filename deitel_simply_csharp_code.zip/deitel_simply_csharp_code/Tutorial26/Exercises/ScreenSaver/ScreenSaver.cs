using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ScreenSaver
{
   /// <summary>
   /// Summary description for FrmShapeChanger.
   /// </summary>
   public class FrmShapeChanger : System.Windows.Forms.Form
   {
      // Timer to update screen saver at intervals
      private System.Windows.Forms.Timer tmrScreenSaver;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components;

      private double m_dblCount = 0.0;

      public FrmShapeChanger()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.tmrScreenSaver = new System.Windows.Forms.Timer(this.components);
         // 
         // tmrScreenSaver
         // 
         this.tmrScreenSaver.Tick += new System.EventHandler(this.tmrScreenSaver_Tick);
         // 
         // FrmShapeChanger
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.BackColor = System.Drawing.Color.Black;
         this.ClientSize = new System.Drawing.Size(442, 323);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmShapeChanger";
         this.Text = "Screen Saver";

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmShapeChanger() );
      }

      // create a specified graphic on the form
      private void DisplayShape()
      {

         // ******** Add your code here ********



      } // end method DisplayShape

      // invoked each time tmrScreenSaver ticks
      private void tmrScreenSaver_Tick( 
         object sender, System.EventArgs e )
      {
         m_dblCount += 0.25;

         // draw shape every half second 
         if ( m_dblCount % 2.5 == 0 )
         {
            DisplayShape(); // draws another shape 
         }
      
      } // end method tmrScreenSaver_Tick

   } // end class FrmShapeChanger
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/