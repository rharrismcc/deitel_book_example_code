using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PhoneBook
{
   /// <summary>
   /// Summary description for FrmPhoneBook.
   /// </summary>
   public class FrmPhoneBook : System.Windows.Forms.Form
   {
      // Label displays instructions
      private System.Windows.Forms.Label lblInstructions;

      // Button calls Peedy
      private System.Windows.Forms.Button btnCall;

      // ComboBox to select name to call
      private System.Windows.Forms.ComboBox cboName;

      // MSAgent to use the Peedy agent
      private AxAgentObjects.AxAgent objMainAgent;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      private AgentObjects.IAgentCtlCharacter m_objMSpeaker;

      // fill array with people's names
      private string[] m_strNameList =
         { "John", "Jennifer", "Howard" };

      // fill array with people's phone numbers
      private string[] m_strNumberList =
         { "(555) 555-9876", "(555) 555-1234", "(555) 555-4567" };

      public FrmPhoneBook()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FrmPhoneBook));
         this.lblInstructions = new System.Windows.Forms.Label();
         this.btnCall = new System.Windows.Forms.Button();
         this.cboName = new System.Windows.Forms.ComboBox();
         this.objMainAgent = new AxAgentObjects.AxAgent();
         ((System.ComponentModel.ISupportInitialize)(this.objMainAgent)).BeginInit();
         this.SuspendLayout();
         // 
         // lblInstructions
         // 
         this.lblInstructions.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblInstructions.Location = new System.Drawing.Point(16, 8);
         this.lblInstructions.Name = "lblInstructions";
         this.lblInstructions.Size = new System.Drawing.Size(264, 23);
         this.lblInstructions.TabIndex = 0;
         this.lblInstructions.Text = "Click the button to call Peedy";
         // 
         // btnCall
         // 
         this.btnCall.Location = new System.Drawing.Point(56, 56);
         this.btnCall.Name = "btnCall";
         this.btnCall.TabIndex = 1;
         this.btnCall.Text = "Call Peedy";
         this.btnCall.Click += new System.EventHandler(this.btnCall_Click);
         // 
         // cboName
         // 
         this.cboName.Enabled = false;
         this.cboName.Location = new System.Drawing.Point(160, 56);
         this.cboName.Name = "cboName";
         this.cboName.TabIndex = 2;
         this.cboName.SelectedIndexChanged += new System.EventHandler(this.cboName_SelectedIndexChanged);
         // 
         // objMainAgent
         // 
         this.objMainAgent.Enabled = true;
         this.objMainAgent.Location = new System.Drawing.Point(16, 48);
         this.objMainAgent.Name = "objMainAgent";
         this.objMainAgent.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("objMainAgent.OcxState")));
         this.objMainAgent.Size = new System.Drawing.Size(32, 32);
         this.objMainAgent.TabIndex = 3;
         this.objMainAgent.Command += new AxAgentObjects._AgentEvents_CommandEventHandler(this.objMainAgent_Command);
         this.objMainAgent.HideEvent += new AxAgentObjects._AgentEvents_HideEventHandler(this.objMainAgent_HideEvent);
         // 
         // FrmPhoneBook
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(292, 123);
         this.Controls.Add(this.objMainAgent);
         this.Controls.Add(this.cboName);
         this.Controls.Add(this.btnCall);
         this.Controls.Add(this.lblInstructions);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmPhoneBook";
         this.Text = "Phone Book";
         this.Load += new System.EventHandler(this.FrmPhoneBook_Load);
         ((System.ComponentModel.ISupportInitialize)(this.objMainAgent)).EndInit();
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmPhoneBook() );
      }

      // called when Form is loaded
      private void FrmPhoneBook_Load( 
         object sender, System.EventArgs e )
      {
         // fill ComboBox with names from objNamelist array
         int intCounter;

         for ( intCounter = 0; intCounter < m_strNameList.Length;
            intCounter++ )
         {
            cboName.Items.Add( m_strNameList[ intCounter ] );
         }

         // load Peedy character into agent object
         objMainAgent.Characters.Load( "Peedy", "Peedy.acs" );

         m_objMSpeaker = objMainAgent.Characters[ "Peedy" ];

         // add names from m_strNameList as enabled commands
         for ( intCounter = 0; intCounter < m_strNameList.Length;
            intCounter++ )
         {
            m_objMSpeaker.Commands.Add(
               m_strNameList[ intCounter ],
               m_strNameList[ intCounter ],
               m_strNameList[ intCounter ], true, true );
         }

      } // end method FrmPhoneBook_Load

      // handles Call Button Click event
      private void btnCall_Click( 
         object sender, System.EventArgs e )
      {
         m_objMSpeaker.Show( 0 );

         // move Peedy to a specified location
         m_objMSpeaker.MoveTo( 
            Convert.ToInt16( Cursor.Position.X - 100 ),
            Convert.ToInt16( Cursor.Position.Y + 130 ), 1 );

         m_objMSpeaker.Play( "Wave" );

         // tell Peedy what to say
         m_objMSpeaker.Speak( "Hello, I'm Peedy. Please say or "
            + "select the name of the person whose phone number you "
            + "would like to find.", "" );

         m_objMSpeaker.Speak( "If you wish to say the name, press "
            + "the Scroll Lock key then speak the name.", "" );

         m_objMSpeaker.Play( "RestPose" );

         cboName.Enabled = true;
         btnCall.Enabled = false;
      
      } // end method btnCall_Click

      // called when user gives Peedy a command
      private void objMainAgent_Command( object sender, 
         AxAgentObjects._AgentEvents_CommandEvent e )
      {
         // get UserInput object
         AgentObjects.IAgentCtlUserInput objCommand =
            ( AgentObjects.IAgentCtlUserInput ) e.userInput;

         int intCounter;

         // search m_strNameList array for command given by user
         // when command is found, Peedy gets corresponding 
         // index from m_strNumberList array
         for ( intCounter = 0; intCounter < m_strNameList.Length;
            intCounter++ )
         {
            if ( objCommand.Name == m_strNameList[ intCounter ] )
            {
               m_objMSpeaker.Play( "Think" );
               m_objMSpeaker.Speak( m_strNameList[ intCounter ]
                  + "'s phone number is "
                  + m_strNumberList[ intCounter ] + ".", "" );

               m_objMSpeaker.Play( "Pleased" );
            }
         }
      
      } // end method objMainAgent_Command

      // called when selection is made in ComboBox
      private void cboName_SelectedIndexChanged( 
         object sender, System.EventArgs e )
      {
         int intCounter;

         // search m_strNameList array for selected ComboBox item and
         // return number
         for ( intCounter = 0; intCounter < m_strNameList.Length;
            intCounter++ )
         {
            if ( Convert.ToString( cboName.SelectedItem ) ==
               m_strNameList[ intCounter ] )
            {
               m_objMSpeaker.Play( "Think" );
               m_objMSpeaker.Speak( m_strNameList[ intCounter ]
                  + "'s phone number is "
                  + m_strNumberList[ intCounter ] + ".", "" );

               m_objMSpeaker.Play( "Pleased" );
            }
         }

      } // end method cboName_SelectedIndexChanged

      // called when user hides Peedy
      private void objMainAgent_HideEvent( 
         object sender, AxAgentObjects._AgentEvents_HideEvent e )
      {
         btnCall.Enabled = true;
         cboName.Enabled = false;

      } // end method objMainAgent_HideEvent

   } // end class FrmPhoneBook
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
