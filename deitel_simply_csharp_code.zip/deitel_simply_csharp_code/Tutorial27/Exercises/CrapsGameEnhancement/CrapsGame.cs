using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace CrapsGame
{
   /// <summary>
   /// Summary description for FrmCrapsGame.
   /// </summary>
   public class FrmCrapsGame : System.Windows.Forms.Form
   {
      // GroupBox to display point dice
      private System.Windows.Forms.GroupBox fraPointDiceGroup;

      // PictureBoxes of point dice
      private System.Windows.Forms.PictureBox picPointDie1;
      private System.Windows.Forms.PictureBox picPointDie2;

      // PictureBoxes of current dice
      private System.Windows.Forms.PictureBox picDie1;
      private System.Windows.Forms.PictureBox picDie2;

      // Button to make Genie say the instructions
      private System.Windows.Forms.Button btnInstructions;

      // Button to play a game
      private System.Windows.Forms.Button btnPlay;

      // Button to roll the dice
      private System.Windows.Forms.Button btnRoll;

      // Label to display status of the game
      private System.Windows.Forms.Label lblStatus;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      // die-roll constants
      enum DiceNames
      {
         SNAKE_EYES = 2,
         TREY = 3,
         CRAPS = 7,
         LUCKY_SEVEN = 7,
         YO_LEVEN = 11,
         BOX_CARS = 12,
      }

      // file name and directory constants
      const string m_strFILE_PREFIX = "/images/die";
      const string m_strFILE_SUFFIX = ".png";

      // instance variables
      private int m_intMyPoint = 0;
      private int m_intMyDie1;
      private int m_intMyDie2;
      private Random m_objRandom = new Random();

      public FrmCrapsGame()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.btnPlay = new System.Windows.Forms.Button();
         this.btnRoll = new System.Windows.Forms.Button();
         this.fraPointDiceGroup = new System.Windows.Forms.GroupBox();
         this.picPointDie1 = new System.Windows.Forms.PictureBox();
         this.picPointDie2 = new System.Windows.Forms.PictureBox();
         this.picDie1 = new System.Windows.Forms.PictureBox();
         this.picDie2 = new System.Windows.Forms.PictureBox();
         this.btnInstructions = new System.Windows.Forms.Button();
         this.lblStatus = new System.Windows.Forms.Label();
         this.fraPointDiceGroup.SuspendLayout();
         this.SuspendLayout();
         // 
         // btnPlay
         // 
         this.btnPlay.Location = new System.Drawing.Point(248, 64);
         this.btnPlay.Name = "btnPlay";
         this.btnPlay.Size = new System.Drawing.Size(104, 23);
         this.btnPlay.TabIndex = 0;
         this.btnPlay.Text = "Play";
         this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
         // 
         // btnRoll
         // 
         this.btnRoll.Location = new System.Drawing.Point(248, 104);
         this.btnRoll.Name = "btnRoll";
         this.btnRoll.Size = new System.Drawing.Size(104, 23);
         this.btnRoll.TabIndex = 1;
         this.btnRoll.Text = "Roll";
         this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
         // 
         // fraPointDiceGroup
         // 
         this.fraPointDiceGroup.Controls.Add(this.picPointDie1);
         this.fraPointDiceGroup.Controls.Add(this.picPointDie2);
         this.fraPointDiceGroup.Location = new System.Drawing.Point(16, 16);
         this.fraPointDiceGroup.Name = "fraPointDiceGroup";
         this.fraPointDiceGroup.Size = new System.Drawing.Size(200, 120);
         this.fraPointDiceGroup.TabIndex = 4;
         this.fraPointDiceGroup.TabStop = false;
         this.fraPointDiceGroup.Text = "Point";
         // 
         // picPointDie1
         // 
         this.picPointDie1.Location = new System.Drawing.Point(24, 40);
         this.picPointDie1.Name = "picPointDie1";
         this.picPointDie1.Size = new System.Drawing.Size(64, 56);
         this.picPointDie1.TabIndex = 0;
         this.picPointDie1.TabStop = false;
         // 
         // picPointDie2
         // 
         this.picPointDie2.Location = new System.Drawing.Point(120, 40);
         this.picPointDie2.Name = "picPointDie2";
         this.picPointDie2.Size = new System.Drawing.Size(64, 56);
         this.picPointDie2.TabIndex = 1;
         this.picPointDie2.TabStop = false;
         // 
         // picDie1
         // 
         this.picDie1.Location = new System.Drawing.Point(40, 152);
         this.picDie1.Name = "picDie1";
         this.picDie1.Size = new System.Drawing.Size(64, 64);
         this.picDie1.TabIndex = 5;
         this.picDie1.TabStop = false;
         // 
         // picDie2
         // 
         this.picDie2.Location = new System.Drawing.Point(136, 152);
         this.picDie2.Name = "picDie2";
         this.picDie2.Size = new System.Drawing.Size(64, 64);
         this.picDie2.TabIndex = 6;
         this.picDie2.TabStop = false;
         // 
         // btnInstructions
         // 
         this.btnInstructions.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.btnInstructions.Location = new System.Drawing.Point(248, 24);
         this.btnInstructions.Name = "btnInstructions";
         this.btnInstructions.Size = new System.Drawing.Size(104, 24);
         this.btnInstructions.TabIndex = 7;
         this.btnInstructions.Text = "Instructions";
         // 
         // lblStatus
         // 
         this.lblStatus.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblStatus.Location = new System.Drawing.Point(248, 160);
         this.lblStatus.Name = "lblStatus";
         this.lblStatus.Size = new System.Drawing.Size(104, 48);
         this.lblStatus.TabIndex = 8;
         // 
         // FrmCrapsGame
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(368, 229);
         this.Controls.Add(this.lblStatus);
         this.Controls.Add(this.btnInstructions);
         this.Controls.Add(this.picDie2);
         this.Controls.Add(this.picDie1);
         this.Controls.Add(this.fraPointDiceGroup);
         this.Controls.Add(this.btnRoll);
         this.Controls.Add(this.btnPlay);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmCrapsGame";
         this.Text = "Craps Game";
         this.fraPointDiceGroup.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmCrapsGame() );
      }

      // begin new game and determine point
      private void btnPlay_Click( 
         object sender, System.EventArgs e )
      {
         // initialize variables for new game
         m_intMyPoint = 0;
         fraPointDiceGroup.Text = "Point";
         lblStatus.Text = "";

         // remove point-die images
         picPointDie1.Image = null;
         picPointDie2.Image = null;

         int intSum = RollDice(); // roll dice

         // check die roll
         switch ( intSum )
         {
            // win on first roll
            case ( int ) DiceNames.LUCKY_SEVEN:
            case ( int ) DiceNames.YO_LEVEN:

               btnRoll.Enabled = false; // disable Roll Button
               lblStatus.Text = "You win!!!";
               break;

            // lose on first roll
            case ( int ) DiceNames.SNAKE_EYES:
            case ( int ) DiceNames.TREY:
            case ( int ) DiceNames.BOX_CARS:

               btnRoll.Enabled = false;
               lblStatus.Text = "Sorry, you lose.";
               break;

            // player must match point
            default:

               m_intMyPoint = intSum;
               fraPointDiceGroup.Text = "Point is " + intSum;
               lblStatus.Text = "Roll again!";
               DisplayDie( picPointDie1, m_intMyDie1 );
               DisplayDie( picPointDie2, m_intMyDie2 );
               btnPlay.Enabled = false; // disable Play Button
               btnRoll.Enabled = true;  // enable Roll Button
               break;

         } // end switch

      } // end method btnPlay_Click

      // determine outcome of next roll
      private void btnRoll_Click( 
         object sender, System.EventArgs e )
      {
         int intSum = RollDice();

         // determine outcome of roll 
         if ( intSum == m_intMyPoint ) // player matches point
         {
            lblStatus.Text = "You win!!!";
            btnRoll.Enabled = false;
            btnPlay.Enabled = true;
         }
         else if ( intSum == ( int ) DiceNames.CRAPS )
         {
            // player loses
            lblStatus.Text = "Sorry, you lose.";
            btnRoll.Enabled = false;
            btnPlay.Enabled = true;
         }
      
      } // end method btnRoll_Click

      // display die image
      private void DisplayDie( PictureBox picDie, int intFace )
      {
         // assign die images to PictureBox
         picDie.Image = 
            Image.FromFile( Directory.GetCurrentDirectory() +
            m_strFILE_PREFIX + intFace + m_strFILE_SUFFIX );

      } // end method DisplayDie

      // generate random die rolls
      private int RollDice()
      {
         // roll the dice
         int intDie1 = m_objRandom.Next( 1, 7 );
         int intDie2 = m_objRandom.Next( 1, 7 );

         // display image corresponding to each die
         DisplayDie( picDie1, intDie1 );
         DisplayDie( picDie2, intDie2 );

         // set values
         m_intMyDie1 = intDie1;
         m_intMyDie2 = intDie2;

         return ( intDie1 + intDie2 ); // return sum of dice values

      } // end method RollDice

   } // end class FrmCrapsGame
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/