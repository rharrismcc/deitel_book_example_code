using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SecurityPanel
{
   /// <summary>
   /// Summary description for FrmSecurityPanel.
   /// </summary>
   public class FrmSecurityPanel : System.Windows.Forms.Form
   {
      // TextBox to display security code
      private System.Windows.Forms.TextBox txtSecurityCode;

      // Buttons to input security code
      private System.Windows.Forms.Button btnOne;
      private System.Windows.Forms.Button btnTwo;
      private System.Windows.Forms.Button btnThree;
      private System.Windows.Forms.Button btnFour;
      private System.Windows.Forms.Button btnFive;
      private System.Windows.Forms.Button btnSix;
      private System.Windows.Forms.Button btnSeven;
      private System.Windows.Forms.Button btnEight;
      private System.Windows.Forms.Button btnNine;
      private System.Windows.Forms.Button btnZero;
      private System.Windows.Forms.Button btnClear;
      private System.Windows.Forms.Button btnEnter;

      // ListBox to display access log
      private System.Windows.Forms.ListBox lstLogEntry;
      
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmSecurityPanel()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.txtSecurityCode = new System.Windows.Forms.TextBox();
         this.lstLogEntry = new System.Windows.Forms.ListBox();
         this.btnOne = new System.Windows.Forms.Button();
         this.btnTwo = new System.Windows.Forms.Button();
         this.btnThree = new System.Windows.Forms.Button();
         this.btnFour = new System.Windows.Forms.Button();
         this.btnFive = new System.Windows.Forms.Button();
         this.btnSix = new System.Windows.Forms.Button();
         this.btnSeven = new System.Windows.Forms.Button();
         this.btnEight = new System.Windows.Forms.Button();
         this.btnNine = new System.Windows.Forms.Button();
         this.btnZero = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.btnEnter = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // txtSecurityCode
         // 
         this.txtSecurityCode.Enabled = false;
         this.txtSecurityCode.Location = new System.Drawing.Point(16, 16);
         this.txtSecurityCode.Name = "txtSecurityCode";
         this.txtSecurityCode.PasswordChar = '*';
         this.txtSecurityCode.Size = new System.Drawing.Size(232, 21);
         this.txtSecurityCode.TabIndex = 1;
         this.txtSecurityCode.Text = "";
         // 
         // lstLogEntry
         // 
         this.lstLogEntry.Location = new System.Drawing.Point(16, 208);
         this.lstLogEntry.Name = "lstLogEntry";
         this.lstLogEntry.Size = new System.Drawing.Size(232, 95);
         this.lstLogEntry.TabIndex = 3;
         // 
         // btnOne
         // 
         this.btnOne.Location = new System.Drawing.Point(96, 64);
         this.btnOne.Name = "btnOne";
         this.btnOne.Size = new System.Drawing.Size(24, 24);
         this.btnOne.TabIndex = 4;
         this.btnOne.Text = "1";
         this.btnOne.Click += new System.EventHandler(this.btnOne_Click);
         // 
         // btnTwo
         // 
         this.btnTwo.Location = new System.Drawing.Point(120, 64);
         this.btnTwo.Name = "btnTwo";
         this.btnTwo.Size = new System.Drawing.Size(24, 24);
         this.btnTwo.TabIndex = 5;
         this.btnTwo.Text = "2";
         this.btnTwo.Click += new System.EventHandler(this.btnTwo_Click);
         // 
         // btnThree
         // 
         this.btnThree.Location = new System.Drawing.Point(144, 64);
         this.btnThree.Name = "btnThree";
         this.btnThree.Size = new System.Drawing.Size(24, 24);
         this.btnThree.TabIndex = 6;
         this.btnThree.Text = "3";
         this.btnThree.Click += new System.EventHandler(this.btnThree_Click);
         // 
         // btnFour
         // 
         this.btnFour.Location = new System.Drawing.Point(96, 88);
         this.btnFour.Name = "btnFour";
         this.btnFour.Size = new System.Drawing.Size(24, 24);
         this.btnFour.TabIndex = 7;
         this.btnFour.Text = "4";
         this.btnFour.Click += new System.EventHandler(this.btnFour_Click);
         // 
         // btnFive
         // 
         this.btnFive.Location = new System.Drawing.Point(120, 88);
         this.btnFive.Name = "btnFive";
         this.btnFive.Size = new System.Drawing.Size(24, 24);
         this.btnFive.TabIndex = 8;
         this.btnFive.Text = "5";
         this.btnFive.Click += new System.EventHandler(this.btnFive_Click);
         // 
         // btnSix
         // 
         this.btnSix.Location = new System.Drawing.Point(144, 88);
         this.btnSix.Name = "btnSix";
         this.btnSix.Size = new System.Drawing.Size(24, 24);
         this.btnSix.TabIndex = 9;
         this.btnSix.Text = "6";
         this.btnSix.Click += new System.EventHandler(this.btnSix_Click);
         // 
         // btnSeven
         // 
         this.btnSeven.Location = new System.Drawing.Point(96, 112);
         this.btnSeven.Name = "btnSeven";
         this.btnSeven.Size = new System.Drawing.Size(24, 24);
         this.btnSeven.TabIndex = 10;
         this.btnSeven.Text = "7";
         this.btnSeven.Click += new System.EventHandler(this.btnSeven_Click);
         // 
         // btnEight
         // 
         this.btnEight.Location = new System.Drawing.Point(120, 112);
         this.btnEight.Name = "btnEight";
         this.btnEight.Size = new System.Drawing.Size(24, 24);
         this.btnEight.TabIndex = 11;
         this.btnEight.Text = "8";
         this.btnEight.Click += new System.EventHandler(this.btnEight_Click);
         // 
         // btnNine
         // 
         this.btnNine.Location = new System.Drawing.Point(144, 112);
         this.btnNine.Name = "btnNine";
         this.btnNine.Size = new System.Drawing.Size(24, 24);
         this.btnNine.TabIndex = 12;
         this.btnNine.Text = "9";
         this.btnNine.Click += new System.EventHandler(this.btnNine_Click);
         // 
         // btnZero
         // 
         this.btnZero.Location = new System.Drawing.Point(120, 136);
         this.btnZero.Name = "btnZero";
         this.btnZero.Size = new System.Drawing.Size(24, 24);
         this.btnZero.TabIndex = 13;
         this.btnZero.Text = "0";
         this.btnZero.Click += new System.EventHandler(this.btnZero_Click);
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(64, 144);
         this.btnClear.Name = "btnClear";
         this.btnClear.Size = new System.Drawing.Size(48, 24);
         this.btnClear.TabIndex = 14;
         this.btnClear.Text = "Clear";
         this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
         // 
         // btnEnter
         // 
         this.btnEnter.Location = new System.Drawing.Point(152, 144);
         this.btnEnter.Name = "btnEnter";
         this.btnEnter.Size = new System.Drawing.Size(48, 24);
         this.btnEnter.TabIndex = 15;
         this.btnEnter.Text = "Enter";
         this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
         // 
         // FrmSecurityPanel
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(264, 317);
         this.Controls.Add(this.btnEnter);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.btnZero);
         this.Controls.Add(this.btnNine);
         this.Controls.Add(this.btnEight);
         this.Controls.Add(this.btnSeven);
         this.Controls.Add(this.btnSix);
         this.Controls.Add(this.btnFive);
         this.Controls.Add(this.btnFour);
         this.Controls.Add(this.btnThree);
         this.Controls.Add(this.btnTwo);
         this.Controls.Add(this.btnOne);
         this.Controls.Add(this.lstLogEntry);
         this.Controls.Add(this.txtSecurityCode);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmSecurityPanel";
         this.Text = "Security Panel";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmSecurityPanel() );
      }

      // handles Enter button's Click event
      private void btnEnter_Click(
         object sender, System.EventArgs e )
      {
         int intAccessCode;  // stores access code entered
         string strMessage;  // displays access status of users

         intAccessCode = Int32.Parse( txtSecurityCode.Text );
         txtSecurityCode.Clear();

         switch ( intAccessCode )  // check access code input
         {
            // access code less than 10
            case 0: 
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
               strMessage = "Restricted Access";
               break;

            // access code equal to 1645 or 1689
            case 1645:
            case 1689:
               strMessage = "Technicians";
               break;

            // access code equal to 8345
            case 8345:
               strMessage = "Custodians";
               break;

            // access code equal to 9998 or between
            // 1006 and 1008, inclusive
            case 9998:
            case 1006:
            case 1007:
            case 1008:
               strMessage = "Scientists";
               break;

            // if no other case is true
            default:
               strMessage = "Access Denied";
               break;

         } // end switch

         // display time and message in ListBox
         lstLogEntry.Items.Add( 
            DateTime.Now + "   " + strMessage );

      } // end method btnEnter_Click

      private void btnZero_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "0"; // concatenate "0" to display

      } // end method btnZero_Click

      private void btnOne_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "1";  // concatenate "1" to display

      } // end method btnOne_Click

      private void btnTwo_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "2";  // concatenate "2" to display

      } // end method btnTwo_Click

      private void btnThree_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "3";  // concatenate "3" to display

      } // end method btnThree_Click

      private void btnFour_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "4";  // concatenate "4" to display

      } // end method btnFour_Click

      private void btnFive_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "5";  // concatenate "5" to display

      } // end method btnFive_Click

      private void btnSix_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "6";  // concatenate "6" to display

      } // end method btnSix_Click

      private void btnSeven_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "7";  // concatenate "7" to display

      } // end method btnSeven_Click

      private void btnEight_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "8";  // concatenate "8" to display

      } // end method btnEight_Click

      private void btnNine_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Text += "9";  // concatenate "9" to display

      } // end method btnNine_Click

      private void btnClear_Click( 
         object sender, System.EventArgs e )
      {
         txtSecurityCode.Clear();  // clear text from TextBox

      } // end method btnClear_Click

   } // end class FrmSecurityPanel
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/