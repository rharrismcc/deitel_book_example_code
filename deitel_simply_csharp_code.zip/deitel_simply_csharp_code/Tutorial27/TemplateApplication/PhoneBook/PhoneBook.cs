using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PhoneBook
{
   /// <summary>
   /// Summary description for FrmPhoneBook.
   /// </summary>
   public class FrmPhoneBook : System.Windows.Forms.Form
   {
      // Label displays instructions
      private System.Windows.Forms.Label lblInstructions;

      // Button calls Peedy
      private System.Windows.Forms.Button btnCall;

      // ComboBox to select name to call
      private System.Windows.Forms.ComboBox cboName;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmPhoneBook()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblInstructions = new System.Windows.Forms.Label();
         this.btnCall = new System.Windows.Forms.Button();
         this.cboName = new System.Windows.Forms.ComboBox();
         this.SuspendLayout();
         // 
         // lblInstructions
         // 
         this.lblInstructions.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.lblInstructions.Location = new System.Drawing.Point(16, 8);
         this.lblInstructions.Name = "lblInstructions";
         this.lblInstructions.Size = new System.Drawing.Size(264, 23);
         this.lblInstructions.TabIndex = 0;
         this.lblInstructions.Text = "Click the button to call Peedy";
         // 
         // btnCall
         // 
         this.btnCall.Location = new System.Drawing.Point(56, 56);
         this.btnCall.Name = "btnCall";
         this.btnCall.TabIndex = 1;
         this.btnCall.Text = "Call Peedy";
         // 
         // cboName
         // 
         this.cboName.Enabled = false;
         this.cboName.Location = new System.Drawing.Point(160, 56);
         this.cboName.Name = "cboName";
         this.cboName.TabIndex = 2;
         // 
         // FrmPhoneBook
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(292, 123);
         this.Controls.Add(this.cboName);
         this.Controls.Add(this.btnCall);
         this.Controls.Add(this.lblInstructions);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmPhoneBook";
         this.Text = "Phone Book";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmPhoneBook() );
      }

   } // end class FrmPhoneBook
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
