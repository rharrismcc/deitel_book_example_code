using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace Bookstore
{
   /// <summary>
   /// Summary description for BookInformation.
   /// </summary>
   public class BookInformation : System.Web.UI.Page
   {
      // Label to display title of page
      protected System.Web.UI.WebControls.Label lblBookTitle;

      // Label to display the authors' names
      protected System.Web.UI.WebControls.Label lblAuthors;

      // Image to display book cover
      protected System.Web.UI.WebControls.Image imgBook;

      // Button to return to Books.aspx
      protected System.Web.UI.WebControls.Button btnBookList;

      // Table to display the book information
      protected System.Web.UI.WebControls.Table tblBook;

      // OleDbConnection to connect to book database
      protected System.Data.OleDb.OleDbConnection objOleDbConnection;

      // OleDbCommand is used to retrieve book information
      // from the database
      protected System.Data.OleDb.OleDbCommand objSelectBookData;
   
      private void Page_Load( object sender, System.EventArgs e )
      {
         // display name of selected book
         lblBookTitle.Text = 
            Convert.ToString( Session[ "strTitle" ] );

         // set value of title parameter to the selected book title
         objSelectBookData.Parameters[ "title" ].Value =
            lblBookTitle.Text;

         objOleDbConnection.Open(); // open database connection

         // create data reader
         OleDbDataReader objReader = 
            objSelectBookData.ExecuteReader();

         objReader.Read(); // start data reader

         // display authors of the selected book
         lblAuthors.Text = 
            Convert.ToString( objReader[ "authors" ] );

         // display coverart for selected book
         imgBook.ImageUrl = 
            Convert.ToString( objReader[ "coverart" ] );

         // display price in Table
         tblBook.Rows[ 0 ].Cells[ 1 ].Text =
            "$" + Convert.ToString( objReader[ "price" ] );

         // display ISBN number in Table
         tblBook.Rows[ 1 ].Cells[ 1 ].Text =
            Convert.ToString( objReader[ "isbn" ] );

         // display edition number in Table
         tblBook.Rows[ 2 ].Cells[ 1 ].Text =
            Convert.ToString( objReader[ "edition" ] );

         // display copyright date in Table
         tblBook.Rows[ 3 ].Cells[ 1 ].Text =
            Convert.ToString( objReader[ "copyrightDate" ] );

         // display description in Table
         tblBook.Rows[ 4 ].Cells[ 1 ].Text =
            Convert.ToString( objReader[ "description" ] );

         objReader.Close();          // close data reader
         objOleDbConnection.Close(); // close database connection

      } // end method Page_Load

      #region Web Form Designer generated code
      override protected void OnInit(EventArgs e)
      {
         //
         // CODEGEN: This call is required by the ASP.NET Web Form Designer.
         //
         InitializeComponent();
         base.OnInit(e);
      }
		
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {    
         this.objOleDbConnection = new System.Data.OleDb.OleDbConnection();
         this.objSelectBookData = new System.Data.OleDb.OleDbCommand();
         this.btnBookList.Click += new System.EventHandler(this.btnBookList_Click);
         // 
         // objOleDbConnection
         // 
         this.objOleDbConnection.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Database Password=;Data Source=""C:\Inetpub\wwwroot\Databases\db_bookstore.mdb"";Password=;Jet OLEDB:Engine Type=5;Jet OLEDB:Global Bulk Transactions=1;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:New Database Password=;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Encrypt Database=False";
         // 
         // objSelectBookData
         // 
         this.objSelectBookData.CommandText = "SELECT authors, coverart, description, edition, isbn, price, copyrightDate FROM P" +
            "roducts WHERE (title = ?)";
         this.objSelectBookData.Connection = this.objOleDbConnection;
         this.objSelectBookData.Parameters.Add(new System.Data.OleDb.OleDbParameter("title", System.Data.OleDb.OleDbType.VarWChar, 150, "title"));
         this.Load += new System.EventHandler(this.Page_Load);

      }
      #endregion

      // invoked when Book List Button is clicked
      private void btnBookList_Click( 
         object sender, System.EventArgs e )
      {
         // redirects to Books.aspx page
         Response.Redirect( "Books.aspx" );

      } // end method btnBookList_Click

   } // end class BookInformation
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
