using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI; 
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace Bookstore
{
   /// <summary>
   /// Summary description for Books.
   /// </summary>
   public class Books : System.Web.UI.Page
   {
      // Label to display title of page
      protected System.Web.UI.WebControls.Label lblAvailable;

      // Label to display the instructions
      protected System.Web.UI.WebControls.Label lblInstructions;

      // ListBox to display the book titles
      protected System.Web.UI.WebControls.ListBox lstBookTitles;

      // Button to select a book
      protected System.Web.UI.WebControls.Button btnInformation;

      // OleDbConnection to connect to book database
      protected System.Data.OleDb.OleDbConnection objOleDbConnection;

      // OleDbCommand is used to retrieve book titles 
      // from the database
      protected System.Data.OleDb.OleDbCommand objSelectTitles;
   
      private void Page_Load( object sender, System.EventArgs e )
      {
         objOleDbConnection.Open(); // open database connection

         // create data reader
         OleDbDataReader objReader = objSelectTitles.ExecuteReader();

         // loop while data reader is reading
         while ( objReader.Read() )
         {
            // add titles to ListBox while reader is reading
            lstBookTitles.Items.Add(
               Convert.ToString( objReader[ "title" ] ) );
         }

         objOleDbConnection.Close(); // close database connection

      } // end method Page_Load

      #region Web Form Designer generated code
      override protected void OnInit(EventArgs e)
      {
         //
         // CODEGEN: This call is required by the ASP.NET Web Form Designer.
         //
         InitializeComponent();
         base.OnInit(e);
      }
		
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {    
         this.objOleDbConnection = new System.Data.OleDb.OleDbConnection();
         this.objSelectTitles = new System.Data.OleDb.OleDbCommand();
         this.btnInformation.Click += new System.EventHandler(this.btnInformation_Click);
         // 
         // objOleDbConnection
         // 
         this.objOleDbConnection.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Databases\db_bookstore.mdb"";Jet OLEDB:Engine Type=5;Jet OLEDB:Global Bulk Transactions=1;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:New Database Password=;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Encrypt Database=False";
         // 
         // objSelectTitles
         // 
         this.objSelectTitles.CommandText = "SELECT title FROM Products";
         this.objSelectTitles.Connection = this.objOleDbConnection;
         this.Load += new System.EventHandler(this.Page_Load);

      }
      #endregion

      // invoked when Button is clicked
      private void btnInformation_Click( 
         object sender, System.EventArgs e )
      {
         // determine if user selected book title
         if ( lstBookTitles.SelectedItem == null )
         {
            lstBookTitles.SelectedIndex = 0;
         }

         // create Session item named strTitle
         Session[ "strTitle" ] =
            lstBookTitles.SelectedItem.Text;

         // redirect to BookInformation.aspx page
         Response.Redirect( "BookInformation.aspx" );

      } // end method btnInformation_Click

   } // end class Books
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
