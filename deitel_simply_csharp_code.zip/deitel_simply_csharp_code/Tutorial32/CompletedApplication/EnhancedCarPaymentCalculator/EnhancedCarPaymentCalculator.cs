using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace EnhancedCarPaymentCalculator
{
   /// <summary>
   /// Summary description for FrmEnhancedCarPayment.
   /// </summary>
   public class FrmEnhancedCarPayment : System.Windows.Forms.Form
   {
      // Label and TextBox for sticker price
      private System.Windows.Forms.Label lblStickerPrice;
      private System.Windows.Forms.TextBox txtStickerPrice;

      // Label and TextBox for down payment
      private System.Windows.Forms.Label lblDownPayment;
      private System.Windows.Forms.TextBox txtDownPayment;

      // Label and textbox for interest rate
      private System.Windows.Forms.TextBox txtInterest;
      private System.Windows.Forms.Label lblInterest;

      // Button to calculate total cost
      private System.Windows.Forms.Button btnCalculate;

      // ListBox to display total cost
      private System.Windows.Forms.ListBox lstPayments;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmEnhancedCarPayment()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblStickerPrice = new System.Windows.Forms.Label();
         this.lblDownPayment = new System.Windows.Forms.Label();
         this.lblInterest = new System.Windows.Forms.Label();
         this.txtStickerPrice = new System.Windows.Forms.TextBox();
         this.txtDownPayment = new System.Windows.Forms.TextBox();
         this.txtInterest = new System.Windows.Forms.TextBox();
         this.btnCalculate = new System.Windows.Forms.Button();
         this.lstPayments = new System.Windows.Forms.ListBox();
         this.SuspendLayout();
         // 
         // lblStickerPrice
         // 
         this.lblStickerPrice.Location = new System.Drawing.Point(40, 24);
         this.lblStickerPrice.Name = "lblStickerPrice";
         this.lblStickerPrice.Size = new System.Drawing.Size(80, 21);
         this.lblStickerPrice.TabIndex = 0;
         this.lblStickerPrice.Text = "Price:";
         this.lblStickerPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblDownPayment
         // 
         this.lblDownPayment.Location = new System.Drawing.Point(40, 56);
         this.lblDownPayment.Name = "lblDownPayment";
         this.lblDownPayment.Size = new System.Drawing.Size(96, 21);
         this.lblDownPayment.TabIndex = 1;
         this.lblDownPayment.Text = "Down payment:";
         this.lblDownPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblInterest
         // 
         this.lblInterest.Location = new System.Drawing.Point(40, 88);
         this.lblInterest.Name = "lblInterest";
         this.lblInterest.Size = new System.Drawing.Size(108, 21);
         this.lblInterest.TabIndex = 2;
         this.lblInterest.Text = "Annual interest rate:";
         this.lblInterest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtStickerPrice
         // 
         this.txtStickerPrice.Location = new System.Drawing.Point(184, 24);
         this.txtStickerPrice.Name = "txtStickerPrice";
         this.txtStickerPrice.Size = new System.Drawing.Size(56, 21);
         this.txtStickerPrice.TabIndex = 3;
         this.txtStickerPrice.Text = "";
         this.txtStickerPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtDownPayment
         // 
         this.txtDownPayment.Location = new System.Drawing.Point(184, 56);
         this.txtDownPayment.Name = "txtDownPayment";
         this.txtDownPayment.Size = new System.Drawing.Size(56, 21);
         this.txtDownPayment.TabIndex = 4;
         this.txtDownPayment.Text = "";
         this.txtDownPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtInterest
         // 
         this.txtInterest.Location = new System.Drawing.Point(184, 88);
         this.txtInterest.Name = "txtInterest";
         this.txtInterest.Size = new System.Drawing.Size(56, 21);
         this.txtInterest.TabIndex = 5;
         this.txtInterest.Text = "";
         this.txtInterest.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // btnCalculate
         // 
         this.btnCalculate.Location = new System.Drawing.Point(112, 128);
         this.btnCalculate.Name = "btnCalculate";
         this.btnCalculate.Size = new System.Drawing.Size(64, 24);
         this.btnCalculate.TabIndex = 6;
         this.btnCalculate.Text = "Calculate";
         this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
         // 
         // lstPayments
         // 
         this.lstPayments.Location = new System.Drawing.Point(28, 168);
         this.lstPayments.Name = "lstPayments";
         this.lstPayments.Size = new System.Drawing.Size(232, 82);
         this.lstPayments.TabIndex = 7;
         // 
         // FrmEnhancedCarPayment
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(292, 273);
         this.Controls.Add(this.lstPayments);
         this.Controls.Add(this.btnCalculate);
         this.Controls.Add(this.txtInterest);
         this.Controls.Add(this.txtDownPayment);
         this.Controls.Add(this.txtStickerPrice);
         this.Controls.Add(this.lblInterest);
         this.Controls.Add(this.lblDownPayment);
         this.Controls.Add(this.lblStickerPrice);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmEnhancedCarPayment";
         this.Text = "Enhanced Car Payment Calculator";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmEnhancedCarPayment() );
      }

      // handles Calculate Button's Click event
      private void btnCalculate_Click(
         object sender, System.EventArgs e )
      {
         int intYears = 2;                // repetition counter
         int intMonths = 0;               // payment period
         int intPrice = 0;                // car price
         int intDownPayment = 0;          // down payment
         double dblInterest = 0;          // interest rate
         decimal decMonthlyPayment = 0;   // monthly payment
         int intLoanAmount = 0;           // cost after down payment
         double dblMonthlyInterest = 0;   // monthly interest rate

         // remove text displayed in ListBox
         lstPayments.Items.Clear();

         // add header to ListBox
         lstPayments.Items.Add( "Months\t\tMonthly Payments" );

         // attempt to retrieve price, down payment and interest
         try
         {
            // retrieve user input and assign values
            // to their respective variables
            intDownPayment = Int32.Parse( txtDownPayment.Text );
            intPrice = Int32.Parse( txtStickerPrice.Text );
            dblInterest = Double.Parse( txtInterest.Text ) / 100;

            // determine amount borrowed and monthly interest rate
            intLoanAmount = intPrice - intDownPayment;
            dblMonthlyInterest = dblInterest / 12;

            // loop four times
            while ( intYears <= 5 ) 
            {
               // calculate payment period
               intMonths = 12 * intYears;

               // calculate monthly payment using FCL Math.Pow
               // method for raising to a power
               decMonthlyPayment = ( decimal ) 
                  ( intLoanAmount * dblMonthlyInterest *
                  Math.Pow( 1 + dblMonthlyInterest, intMonths ) /
                  ( Math.Pow( 1 + dblMonthlyInterest, intMonths )
                  - 1 ) );

               // display payment value
               lstPayments.Items.Add( intMonths + "\t\t" +
                  String.Format( "{0:C}", decMonthlyPayment ) );

               intYears++;  // increment counter

            } // end while

         } // end try

         // process invalid number format
         catch ( FormatException formatExceptionParameter )
         {
            // tell user data was invalid, and ask for new input
            MessageBox.Show(
               "Please enter two integers for the price and down" +
               "\r\npayment and a decimal number " +
               "for the interest.", "Invalid Number Format",
               MessageBoxButtons.OK, MessageBoxIcon.Error );

         } // end catch

      } // end method btnCalculate_Click

   } // end class FrmEnhancedCarPayment 
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
