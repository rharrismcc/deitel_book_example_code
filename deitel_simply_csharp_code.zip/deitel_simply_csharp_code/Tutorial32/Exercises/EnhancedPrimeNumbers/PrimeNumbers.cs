using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PrimeNumbers
{
   /// <summary>
   /// Summary description for FrmPrimeNumbers.
   /// </summary>
   public class FrmPrimeNumbers : System.Windows.Forms.Form
   {
      // Label and TextBox for lower bound
      private System.Windows.Forms.Label lblLowerBound;
      private System.Windows.Forms.TextBox txtLowerBound;

      // Label and TextBox for upper bound      
      private System.Windows.Forms.Label lblUpperBound;
      private System.Windows.Forms.TextBox txtUpperBound;

      // Label and TextBox for outputting prime numbers
      private System.Windows.Forms.Label lblPrimeNumbers;           
      private System.Windows.Forms.TextBox txtPrimeNumbers;

      // Button to trigger calculation
      private System.Windows.Forms.Button btnCalculatePrimes;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public FrmPrimeNumbers()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblLowerBound = new System.Windows.Forms.Label();
         this.lblUpperBound = new System.Windows.Forms.Label();
         this.lblPrimeNumbers = new System.Windows.Forms.Label();
         this.txtLowerBound = new System.Windows.Forms.TextBox();
         this.txtUpperBound = new System.Windows.Forms.TextBox();
         this.txtPrimeNumbers = new System.Windows.Forms.TextBox();
         this.btnCalculatePrimes = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblLowerBound
         // 
         this.lblLowerBound.Location = new System.Drawing.Point(16, 16);
         this.lblLowerBound.Name = "lblLowerBound";
         this.lblLowerBound.Size = new System.Drawing.Size(80, 21);
         this.lblLowerBound.TabIndex = 0;
         this.lblLowerBound.Text = "Lower bound:";
         this.lblLowerBound.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblUpperBound
         // 
         this.lblUpperBound.Location = new System.Drawing.Point(16, 56);
         this.lblUpperBound.Name = "lblUpperBound";
         this.lblUpperBound.Size = new System.Drawing.Size(80, 21);
         this.lblUpperBound.TabIndex = 1;
         this.lblUpperBound.Text = "Upper bound:";
         this.lblUpperBound.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // lblPrimeNumbers
         // 
         this.lblPrimeNumbers.Location = new System.Drawing.Point(16, 104);
         this.lblPrimeNumbers.Name = "lblPrimeNumbers";
         this.lblPrimeNumbers.Size = new System.Drawing.Size(88, 16);
         this.lblPrimeNumbers.TabIndex = 2;
         this.lblPrimeNumbers.Text = "Prime numbers:";
         this.lblPrimeNumbers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtLowerBound
         // 
         this.txtLowerBound.Location = new System.Drawing.Point(104, 16);
         this.txtLowerBound.Name = "txtLowerBound";
         this.txtLowerBound.Size = new System.Drawing.Size(56, 21);
         this.txtLowerBound.TabIndex = 3;
         this.txtLowerBound.Text = "";
         this.txtLowerBound.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtUpperBound
         // 
         this.txtUpperBound.Location = new System.Drawing.Point(104, 56);
         this.txtUpperBound.Name = "txtUpperBound";
         this.txtUpperBound.Size = new System.Drawing.Size(56, 21);
         this.txtUpperBound.TabIndex = 4;
         this.txtUpperBound.Text = "";
         this.txtUpperBound.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // txtPrimeNumbers
         // 
         this.txtPrimeNumbers.Location = new System.Drawing.Point(16, 120);
         this.txtPrimeNumbers.Multiline = true;
         this.txtPrimeNumbers.Name = "txtPrimeNumbers";
         this.txtPrimeNumbers.ScrollBars = System.Windows.Forms.ScrollBars.Both;
         this.txtPrimeNumbers.Size = new System.Drawing.Size(144, 96);
         this.txtPrimeNumbers.TabIndex = 5;
         this.txtPrimeNumbers.Text = "";
         // 
         // btnCalculatePrimes
         // 
         this.btnCalculatePrimes.Location = new System.Drawing.Point(56, 232);
         this.btnCalculatePrimes.Name = "btnCalculatePrimes";
         this.btnCalculatePrimes.Size = new System.Drawing.Size(104, 23);
         this.btnCalculatePrimes.TabIndex = 7;
         this.btnCalculatePrimes.Text = "Calculate Primes";
         this.btnCalculatePrimes.Click += new System.EventHandler(this.btnCalculatePrimes_Click);
         // 
         // FrmPrimeNumbers
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(176, 269);
         this.Controls.Add(this.btnCalculatePrimes);
         this.Controls.Add(this.txtPrimeNumbers);
         this.Controls.Add(this.txtUpperBound);
         this.Controls.Add(this.txtLowerBound);
         this.Controls.Add(this.lblPrimeNumbers);
         this.Controls.Add(this.lblUpperBound);
         this.Controls.Add(this.lblLowerBound);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmPrimeNumbers";
         this.Text = "Prime Numbers";
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmPrimeNumbers() );
      }

      // determine if number is prime
      private bool Prime( int intNumber )
      {
         int intCount; // declare counter

         // set square root of intNumber as limit
         int intLimit = ( int ) Math.Sqrt( intNumber );

         // loop until intCount reaches square root of intNumber
         for ( intCount = 2; intCount <= intLimit; intCount++ )
         {
            if ( intNumber % intCount == 0 )
            {
               return false; // number is not prime
            }
         }

         return true; // number is prime

      } // end method Prime
      
      // handles Calculate Primes Button's Click event
      private void btnCalculatePrimes_Click(
         object sender, System.EventArgs e )
      {   
         // declare variables
         int intLowerBound;
         int intUpperBound;
         int intCounter;
         string strOutput = "";
         
         intLowerBound = Int32.Parse( txtLowerBound.Text );
         intUpperBound = Int32.Parse( txtUpperBound.Text );

         if ( intLowerBound <= 1 || intUpperBound <= 1 )
         {
            MessageBox.Show( "Bounds must be greater than 1",
               "Invalid Bounds", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         }
         else if ( intUpperBound < intLowerBound )
         {
            MessageBox.Show( "Upper bound cannot be less than " +
               "lower bound", "Invalid Bounds",
               MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
         }
         else
         {
            // loop from lower bound to upper bound
            for ( intCounter = intLowerBound; 
               intCounter <= intUpperBound; intCounter++ )
            {
               // if prime number, display in TextBox
               if ( Prime( intCounter ) == true )
               {
                  strOutput += ( intCounter + "\r\n" );
               }
            }
         }   
      
         txtPrimeNumbers.Text = strOutput;
      
      } // end method btnCalculatePrimes_Click

   } // end class FrmPrimeNumbers
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/