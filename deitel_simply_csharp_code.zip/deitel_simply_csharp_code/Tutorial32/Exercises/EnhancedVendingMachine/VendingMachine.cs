using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace VendingMachine
{
   /// <summary>
   /// Summary description for FrmVendingMachine.
   /// </summary>
   public class FrmVendingMachine : System.Windows.Forms.Form
   {
      // Panel enclosing snack choices
      private System.Windows.Forms.Panel windowPanel;

      // Labels and PictureBoxes for each snack            
      private System.Windows.Forms.Label lbl0;
      private System.Windows.Forms.Label lbl1;
      private System.Windows.Forms.Label lbl2;
      private System.Windows.Forms.Label lbl3;
      private System.Windows.Forms.Label lbl4;
      private System.Windows.Forms.Label lbl5;
      private System.Windows.Forms.Label lbl6;
      private System.Windows.Forms.Label lbl7;
      private System.Windows.Forms.PictureBox picItem0;
      private System.Windows.Forms.PictureBox picItem1;
      private System.Windows.Forms.PictureBox picItem2;
      private System.Windows.Forms.PictureBox picItem3;
      private System.Windows.Forms.PictureBox picItem4;
      private System.Windows.Forms.PictureBox picItem5;
      private System.Windows.Forms.PictureBox picItem6;
      private System.Windows.Forms.PictureBox picItem7;      
      
      // Label for the output
      private System.Windows.Forms.Label lblOutput;

      // Label and TextBox for the user's selection
      private System.Windows.Forms.Label lblSelection;
      private System.Windows.Forms.TextBox txtSelection;

      // Button to dispense the snack
      private System.Windows.Forms.Button btnDispense;      

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;      
      
      // declare an array of snack names
      string[] strSnacks = { 
         "Chocolate Chip Cookie", "Bubble Gum",
         "Plain Pretzel", "Soda",
         "Salted Pretzel", "Oatmeal Cookie",
         "Diet Soda", "Sugar-free Gum" };

      public FrmVendingMachine()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing )
      {
         if( disposing )
         {
            if (components != null) 
            {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FrmVendingMachine));
         this.windowPanel = new System.Windows.Forms.Panel();
         this.lbl7 = new System.Windows.Forms.Label();
         this.lbl6 = new System.Windows.Forms.Label();
         this.lbl5 = new System.Windows.Forms.Label();
         this.lbl4 = new System.Windows.Forms.Label();
         this.lbl3 = new System.Windows.Forms.Label();
         this.lbl2 = new System.Windows.Forms.Label();
         this.lbl1 = new System.Windows.Forms.Label();
         this.lbl0 = new System.Windows.Forms.Label();
         this.picItem5 = new System.Windows.Forms.PictureBox();
         this.picItem4 = new System.Windows.Forms.PictureBox();
         this.picItem6 = new System.Windows.Forms.PictureBox();
         this.picItem7 = new System.Windows.Forms.PictureBox();
         this.picItem3 = new System.Windows.Forms.PictureBox();
         this.picItem2 = new System.Windows.Forms.PictureBox();
         this.picItem1 = new System.Windows.Forms.PictureBox();
         this.picItem0 = new System.Windows.Forms.PictureBox();
         this.lblOutput = new System.Windows.Forms.Label();
         this.lblSelection = new System.Windows.Forms.Label();
         this.txtSelection = new System.Windows.Forms.TextBox();
         this.btnDispense = new System.Windows.Forms.Button();
         this.windowPanel.SuspendLayout();
         this.SuspendLayout();
         // 
         // windowPanel
         // 
         this.windowPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.windowPanel.Controls.Add(this.lbl7);
         this.windowPanel.Controls.Add(this.lbl6);
         this.windowPanel.Controls.Add(this.lbl5);
         this.windowPanel.Controls.Add(this.lbl4);
         this.windowPanel.Controls.Add(this.lbl3);
         this.windowPanel.Controls.Add(this.lbl2);
         this.windowPanel.Controls.Add(this.lbl1);
         this.windowPanel.Controls.Add(this.lbl0);
         this.windowPanel.Controls.Add(this.picItem5);
         this.windowPanel.Controls.Add(this.picItem4);
         this.windowPanel.Controls.Add(this.picItem6);
         this.windowPanel.Controls.Add(this.picItem7);
         this.windowPanel.Controls.Add(this.picItem3);
         this.windowPanel.Controls.Add(this.picItem2);
         this.windowPanel.Controls.Add(this.picItem1);
         this.windowPanel.Controls.Add(this.picItem0);
         this.windowPanel.Location = new System.Drawing.Point(16, 16);
         this.windowPanel.Name = "windowPanel";
         this.windowPanel.Size = new System.Drawing.Size(304, 232);
         this.windowPanel.TabIndex = 0;
         // 
         // lbl7
         // 
         this.lbl7.Location = new System.Drawing.Point(232, 200);
         this.lbl7.Name = "lbl7";
         this.lbl7.Size = new System.Drawing.Size(56, 16);
         this.lbl7.TabIndex = 19;
         this.lbl7.Text = "7";
         this.lbl7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // lbl6
         // 
         this.lbl6.Location = new System.Drawing.Point(160, 200);
         this.lbl6.Name = "lbl6";
         this.lbl6.Size = new System.Drawing.Size(56, 16);
         this.lbl6.TabIndex = 18;
         this.lbl6.Text = "6";
         this.lbl6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // lbl5
         // 
         this.lbl5.Location = new System.Drawing.Point(88, 200);
         this.lbl5.Name = "lbl5";
         this.lbl5.Size = new System.Drawing.Size(56, 16);
         this.lbl5.TabIndex = 17;
         this.lbl5.Text = "5";
         this.lbl5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // lbl4
         // 
         this.lbl4.Location = new System.Drawing.Point(16, 200);
         this.lbl4.Name = "lbl4";
         this.lbl4.Size = new System.Drawing.Size(56, 16);
         this.lbl4.TabIndex = 16;
         this.lbl4.Text = "4";
         this.lbl4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // lbl3
         // 
         this.lbl3.Location = new System.Drawing.Point(232, 96);
         this.lbl3.Name = "lbl3";
         this.lbl3.Size = new System.Drawing.Size(56, 16);
         this.lbl3.TabIndex = 15;
         this.lbl3.Text = "3";
         this.lbl3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // lbl2
         // 
         this.lbl2.Location = new System.Drawing.Point(160, 96);
         this.lbl2.Name = "lbl2";
         this.lbl2.Size = new System.Drawing.Size(56, 16);
         this.lbl2.TabIndex = 14;
         this.lbl2.Text = "2";
         this.lbl2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // lbl1
         // 
         this.lbl1.Location = new System.Drawing.Point(88, 96);
         this.lbl1.Name = "lbl1";
         this.lbl1.Size = new System.Drawing.Size(56, 16);
         this.lbl1.TabIndex = 13;
         this.lbl1.Text = "1";
         this.lbl1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // lbl0
         // 
         this.lbl0.Location = new System.Drawing.Point(16, 96);
         this.lbl0.Name = "lbl0";
         this.lbl0.Size = new System.Drawing.Size(56, 16);
         this.lbl0.TabIndex = 12;
         this.lbl0.Text = "0";
         this.lbl0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // picItem5
         // 
         this.picItem5.Image = ((System.Drawing.Image)(resources.GetObject("picItem5.Image")));
         this.picItem5.Location = new System.Drawing.Point(88, 128);
         this.picItem5.Name = "picItem5";
         this.picItem5.Size = new System.Drawing.Size(50, 50);
         this.picItem5.TabIndex = 11;
         this.picItem5.TabStop = false;
         // 
         // picItem4
         // 
         this.picItem4.Image = ((System.Drawing.Image)(resources.GetObject("picItem4.Image")));
         this.picItem4.Location = new System.Drawing.Point(16, 128);
         this.picItem4.Name = "picItem4";
         this.picItem4.Size = new System.Drawing.Size(50, 50);
         this.picItem4.TabIndex = 10;
         this.picItem4.TabStop = false;
         // 
         // picItem6
         // 
         this.picItem6.Image = ((System.Drawing.Image)(resources.GetObject("picItem6.Image")));
         this.picItem6.Location = new System.Drawing.Point(160, 128);
         this.picItem6.Name = "picItem6";
         this.picItem6.Size = new System.Drawing.Size(50, 50);
         this.picItem6.TabIndex = 9;
         this.picItem6.TabStop = false;
         // 
         // picItem7
         // 
         this.picItem7.Image = ((System.Drawing.Image)(resources.GetObject("picItem7.Image")));
         this.picItem7.Location = new System.Drawing.Point(232, 128);
         this.picItem7.Name = "picItem7";
         this.picItem7.Size = new System.Drawing.Size(50, 50);
         this.picItem7.TabIndex = 8;
         this.picItem7.TabStop = false;
         // 
         // picItem3
         // 
         this.picItem3.Image = ((System.Drawing.Image)(resources.GetObject("picItem3.Image")));
         this.picItem3.Location = new System.Drawing.Point(232, 24);
         this.picItem3.Name = "picItem3";
         this.picItem3.Size = new System.Drawing.Size(50, 50);
         this.picItem3.TabIndex = 3;
         this.picItem3.TabStop = false;
         // 
         // picItem2
         // 
         this.picItem2.Image = ((System.Drawing.Image)(resources.GetObject("picItem2.Image")));
         this.picItem2.Location = new System.Drawing.Point(160, 24);
         this.picItem2.Name = "picItem2";
         this.picItem2.Size = new System.Drawing.Size(50, 50);
         this.picItem2.TabIndex = 2;
         this.picItem2.TabStop = false;
         // 
         // picItem1
         // 
         this.picItem1.Image = ((System.Drawing.Image)(resources.GetObject("picItem1.Image")));
         this.picItem1.Location = new System.Drawing.Point(88, 24);
         this.picItem1.Name = "picItem1";
         this.picItem1.Size = new System.Drawing.Size(50, 50);
         this.picItem1.TabIndex = 1;
         this.picItem1.TabStop = false;
         // 
         // picItem0
         // 
         this.picItem0.Image = ((System.Drawing.Image)(resources.GetObject("picItem0.Image")));
         this.picItem0.Location = new System.Drawing.Point(16, 24);
         this.picItem0.Name = "picItem0";
         this.picItem0.Size = new System.Drawing.Size(50, 50);
         this.picItem0.TabIndex = 0;
         this.picItem0.TabStop = false;
         // 
         // lblOutput
         // 
         this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.lblOutput.Location = new System.Drawing.Point(16, 264);
         this.lblOutput.Name = "lblOutput";
         this.lblOutput.Size = new System.Drawing.Size(304, 23);
         this.lblOutput.TabIndex = 1;
         this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // lblSelection
         // 
         this.lblSelection.Location = new System.Drawing.Point(336, 16);
         this.lblSelection.Name = "lblSelection";
         this.lblSelection.Size = new System.Drawing.Size(160, 21);
         this.lblSelection.TabIndex = 20;
         this.lblSelection.Text = "Please make a selection:";
         // 
         // txtSelection
         // 
         this.txtSelection.Location = new System.Drawing.Point(336, 48);
         this.txtSelection.Name = "txtSelection";
         this.txtSelection.Size = new System.Drawing.Size(160, 21);
         this.txtSelection.TabIndex = 21;
         this.txtSelection.Text = "";
         // 
         // btnDispense
         // 
         this.btnDispense.Location = new System.Drawing.Point(336, 88);
         this.btnDispense.Name = "btnDispense";
         this.btnDispense.Size = new System.Drawing.Size(160, 21);
         this.btnDispense.TabIndex = 22;
         this.btnDispense.Text = "Dispense Snack";
         this.btnDispense.Click += new System.EventHandler(this.btnDispense_Click);
         // 
         // FrmVendingMachine
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
         this.ClientSize = new System.Drawing.Size(520, 301);
         this.Controls.Add(this.btnDispense);
         this.Controls.Add(this.txtSelection);
         this.Controls.Add(this.lblOutput);
         this.Controls.Add(this.windowPanel);
         this.Controls.Add(this.lblSelection);
         this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
         this.Name = "FrmVendingMachine";
         this.Text = "Vending Machine";
         this.windowPanel.ResumeLayout(false);
         this.ResumeLayout(false);

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main() 
      {
         Application.Run( new FrmVendingMachine() );
      }

      // method to dispense snack
      private void btnDispense_Click(
         object sender, System.EventArgs e )
      {         
         // get user input
         int intSelection = Int32.Parse( txtSelection.Text );
            
         lblOutput.Text = 
            Convert.ToString( strSnacks[ intSelection ] ) +
            " has been dispensed";
      
      } // end method btnDispense_Click
 
   } // end class FrmVendingMachine
}

/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/